<?php
namespace App\Modules\Customers\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Modules\Customers\Models\Customer;
use App\Services\AuditService;

/**
 * Customers Management Controller
 */
class CustomerController extends Controller
{
    private Customer $customerModel;

    public function __construct()
    {
        $this->customerModel = new Customer();
    }

    public function index(): void
    {
        $businessId = $this->businessId();
        $search = $_GET['search'] ?? null;
        $customers = $this->customerModel->getAll($businessId, $search);

        $this->view('customers.index', [
            'title'     => 'Customer Management — Kaanti Manager',
            'customers' => $customers,
            'search'    => $search
        ], 'app');
    }

    public function create(): void
    {
        $this->view('customers.create', [
            'title' => 'Add New Customer — Kaanti Manager'
        ], 'app');
    }

    public function store(): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $businessId = $this->businessId();
        $userId     = $this->userId();

        $data = $this->validate($_POST, [
            'name'  => 'required|string|min:2|max:200',
            'phone' => 'nullable|phone',
            'email' => 'nullable|email',
        ]);

        $data['business_name'] = $_POST['business_name'] ?? null;
        $data['address']       = $_POST['address'] ?? null;
        $data['notes']         = $_POST['notes'] ?? null;

        try {
            $customerId = $this->customerModel->create($businessId, $data);
            AuditService::log($userId, $businessId, 'customer_created', 'customers', $customerId, null, ['name' => $data['name']]);
            Session::flash('success', 'Customer ' . htmlspecialchars($data['name']) . ' has been added.');
            $this->redirect('customers/' . $customerId);
        } catch (\Throwable $e) {
            error_log('Add customer error: ' . $e->getMessage());
            Session::flash('error', 'Unable to add customer. Please try again.');
            $this->back();
        }
    }

    public function show(string $id): void
    {
        $businessId = $this->businessId();
        $customer = $this->customerModel->findById($businessId, $id);

        if (!$customer) {
            Session::flash('error', 'Customer not found.');
            $this->redirect('customers');
            return;
        }

        $transactions = $this->customerModel->getTransactions($businessId, $id);

        $this->view('customers.show', [
            'title'        => e($customer['name']) . ' — Customer Profile',
            'customer'     => $customer,
            'transactions' => $transactions
        ], 'app');
    }

    public function edit(string $id): void
    {
        $businessId = $this->businessId();
        $customer = $this->customerModel->findById($businessId, $id);

        if (!$customer) {
            Session::flash('error', 'Customer not found.');
            $this->redirect('customers');
            return;
        }

        $this->view('customers.edit', [
            'title'    => 'Edit Customer: ' . e($customer['name']),
            'customer' => $customer
        ], 'app');
    }

    public function update(string $id): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $businessId = $this->businessId();
        $userId     = $this->userId();

        $data = $this->validate($_POST, [
            'name'  => 'required|string|min:2|max:200',
            'phone' => 'nullable|phone',
            'email' => 'nullable|email',
        ]);

        $data['business_name'] = $_POST['business_name'] ?? null;
        $data['address']       = $_POST['address'] ?? null;
        $data['notes']         = $_POST['notes'] ?? null;

        try {
            $this->customerModel->update($businessId, $id, $data);
            AuditService::log($userId, $businessId, 'customer_updated', 'customers', $id, null, ['name' => $data['name']]);
            Session::flash('success', 'Customer details updated successfully.');
            $this->redirect('customers/' . $id);
        } catch (\Throwable $e) {
            error_log('Update customer error: ' . $e->getMessage());
            Session::flash('error', 'Unable to update customer.');
            $this->back();
        }
    }
}
