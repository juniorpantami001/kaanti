<?php
namespace App\Modules\Customers\Models;

use App\Core\Database;

/**
 * Customer Model
 * Multi-tenant customer profiles and debt/transaction history.
 */
class Customer
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function getAll(string $businessId, ?string $search = null): array
    {
        $sql = "SELECT * FROM customers WHERE business_id = ?";
        $params = [$businessId];

        if (!empty($search)) {
            $sql .= " AND (LOWER(name) LIKE LOWER(?) OR LOWER(business_name) LIKE LOWER(?) OR LOWER(phone) LIKE LOWER(?) OR LOWER(email) LIKE LOWER(?))";
            $term = '%' . trim($search) . '%';
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        $sql .= " ORDER BY name ASC";
        return $this->db->fetchAll($sql, $params);
    }

    public function findById(string $businessId, string $id): ?array
    {
        $sql = "SELECT * FROM customers WHERE business_id = ? AND id = ? LIMIT 1";
        $row = $this->db->fetch($sql, [$businessId, $id]);
        return $row ?: null;
    }

    public function create(string $businessId, array $data): string
    {
        $id = Database::generateUuid();
        $sql = "INSERT INTO customers (id, business_id, name, business_name, phone, email, address, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        $this->db->query($sql, [
            $id,
            $businessId,
            trim($data['name']),
            !empty($data['business_name']) ? trim($data['business_name']) : null,
            !empty($data['phone']) ? trim($data['phone']) : null,
            !empty($data['email']) ? trim($data['email']) : null,
            !empty($data['address']) ? trim($data['address']) : null,
            !empty($data['notes']) ? trim($data['notes']) : null,
        ]);

        return $id;
    }

    public function update(string $businessId, string $id, array $data): bool
    {
        $sql = "UPDATE customers 
                SET name = ?, business_name = ?, phone = ?, email = ?, address = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
                WHERE business_id = ? AND id = ?";

        return $this->db->query($sql, [
            trim($data['name']),
            !empty($data['business_name']) ? trim($data['business_name']) : null,
            !empty($data['phone']) ? trim($data['phone']) : null,
            !empty($data['email']) ? trim($data['email']) : null,
            !empty($data['address']) ? trim($data['address']) : null,
            !empty($data['notes']) ? trim($data['notes']) : null,
            $businessId,
            $id
        ])->rowCount() > 0;
    }

    public function incrementSpending(string $businessId, string $customerId, float $amount): void
    {
        $sql = "UPDATE customers 
                SET total_transactions = total_transactions + 1,
                    total_spent = total_spent + ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE business_id = ? AND id = ?";
        $this->db->query($sql, [$amount, $businessId, $customerId]);
    }

    public function getTransactions(string $businessId, string $customerId): array
    {
        $sql = "SELECT * FROM transactions 
                WHERE business_id = ? AND customer_id = ? 
                ORDER BY transaction_date DESC, created_at DESC";
        return $this->db->fetchAll($sql, [$businessId, $customerId]);
    }
}
