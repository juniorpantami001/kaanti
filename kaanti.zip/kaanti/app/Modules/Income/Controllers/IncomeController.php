<?php
namespace App\Modules\Income\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Modules\Transactions\Models\Transaction;
use App\Modules\Customers\Models\Customer;
use App\Services\AuditService;

/**
 * Income Management Controller
 */
class IncomeController extends Controller
{
    private Transaction $transactionModel;
    private Customer $customerModel;

    public function __construct()
    {
        $this->transactionModel = new Transaction();
        $this->customerModel    = new Customer();
    }

    public function create(): void
    {
        $businessId = $this->businessId();
        $categories = $this->transactionModel->getCategories($businessId, 'income');
        $customers  = $this->customerModel->getAll($businessId);

        $this->view('transactions.income-create', [
            'title'      => 'Record Income — Kaanti Manager',
            'categories' => $categories,
            'customers'  => $customers,
        ], 'app');
    }

    public function store(): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $businessId = $this->businessId();
        $userId     = $this->userId();

        $data = $this->validate($_POST, [
            'amount'           => 'required|numeric',
            'description'      => 'required|string|min:2|max:300',
            'transaction_date' => 'required|date',
            'payment_method'   => 'required|string',
            'category_name'    => 'required|string',
        ]);

        $data['type']       = 'income';
        $data['created_by'] = $userId;
        $data['customer_id'] = !empty($_POST['customer_id']) ? $_POST['customer_id'] : null;

        try {
            $txId = $this->transactionModel->create($businessId, $data);

            // If customer was selected, update customer total stats
            if (!empty($data['customer_id'])) {
                $this->customerModel->incrementSpending($businessId, $data['customer_id'], (float) $data['amount']);
            }

            AuditService::log($userId, $businessId, 'income_recorded', 'transactions', $txId, null, [
                'amount'      => $data['amount'],
                'description' => $data['description']
            ]);

            Session::flash('success', 'Income of ' . format_naira($data['amount']) . ' logged successfully.');
            $this->redirect('transactions');
        } catch (\Throwable $e) {
            error_log('Record income error: ' . $e->getMessage());
            Session::flash('error', 'Unable to record income. Please try again.');
            $this->back();
        }
    }
}
