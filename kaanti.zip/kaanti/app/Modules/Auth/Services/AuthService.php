<?php
namespace App\Modules\Auth\Services;

use App\Core\Database;
use App\Core\Session;
use App\Modules\Auth\Models\User;
use App\Services\AuditService;

/**
 * Authentication Service
 * Handles user authentication, registration, rate limiting, and session security.
 */
class AuthService
{
    private ?User $userModel = null;
    private ?Database $db = null;

    private function getUserModel(): User
    {
        if ($this->userModel === null) {
            $this->userModel = new User();
        }
        return $this->userModel;
    }

    private function getDb(): Database
    {
        if ($this->db === null) {
            $this->db = Database::getInstance();
        }
        return $this->db;
    }

    /**
     * Check if client is rate-limited on login (5 failed attempts within 15 minutes)
     */
    public function isRateLimited(string $email, string $ip): bool
    {
        $sql = "SELECT COUNT(*) FROM login_attempts 
                WHERE (LOWER(email) = LOWER(?) OR ip_address = ?) 
                  AND successful = FALSE 
                  AND attempted_at >= (CURRENT_TIMESTAMP - INTERVAL 15 MINUTE)";

        $attempts = (int) $this->getDb()->fetchColumn($sql, [trim($email), $ip]);
        return $attempts >= 5;
    }

    /**
     * Record a login attempt
     */
    public function recordLoginAttempt(string $email, string $ip, bool $successful): void
    {
        $sql = "INSERT INTO login_attempts (id, email, ip_address, successful, attempted_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)";
        $this->getDb()->query($sql, [Database::generateUuid(), trim($email), $ip, $successful]);
    }

    /**
     * Authenticate user credentials
     */
    public function login(string $email, string $password): array|false
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

        if ($this->isRateLimited($email, $ip)) {
            return false;
        }

        $user = $this->getUserModel()->findByEmail($email);

        if (!$user) {
            $this->recordLoginAttempt($email, $ip, false);
            return false;
        }

        if ($user['status'] !== 'active') {
            return false;
        }

        if (!password_verify($password, $user['password_hash'])) {
            $this->recordLoginAttempt($email, $ip, false);
            return false;
        }

        // Check if password needs rehash with modern options
        if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
            $newHash = password_hash($password, PASSWORD_DEFAULT);
            $this->getUserModel()->updatePassword($user['id'], $newHash);
        }

        // Login successful
        $this->recordLoginAttempt($email, $ip, true);

        // Regenerate session ID to prevent session fixation attacks
        Session::regenerate();

        // Set session variables
        Session::set('user_id', $user['id']);
        Session::set('user_name', $user['first_name'] . ' ' . $user['last_name']);
        Session::set('user_email', $user['email']);
        Session::set('is_super_admin', (bool) $user['is_super_admin']);
        Session::set('user_language', $user['language'] ?? 'en');

        // Audit log
        AuditService::log($user['id'], null, 'user_login', 'users', $user['id']);

        return $user;
    }

    /**
     * Register a new user
     */
    public function register(array $data): string
    {
        $hashed = password_hash($data['password'], PASSWORD_DEFAULT);

        $userId = $this->getUserModel()->create([
            'email'         => $data['email'],
            'phone'         => $data['phone'] ?? null,
            'password_hash' => $hashed,
            'first_name'    => $data['first_name'],
            'last_name'     => $data['last_name'],
            'language'      => $data['language'] ?? 'en',
        ]);

        // Auto login newly registered user
        Session::regenerate();
        Session::set('user_id', $userId);
        Session::set('user_name', trim($data['first_name']) . ' ' . trim($data['last_name']));
        Session::set('user_email', strtolower(trim($data['email'])));
        Session::set('is_super_admin', false);
        Session::set('user_language', $data['language'] ?? 'en');

        AuditService::log($userId, null, 'user_registered', 'users', $userId);

        return $userId;
    }

    /**
     * Terminate user session
     */
    public function logout(): void
    {
        $userId = Session::get('user_id');
        if ($userId) {
            AuditService::log($userId, Session::get('business_id'), 'user_logout', 'users', $userId);
        }
        Session::destroy();
    }

    /**
     * Generate password reset token
     */
    public function forgotPassword(string $email): ?string
    {
        $user = $this->getUserModel()->findByEmail($email);
        if (!$user) {
            return null; // Return cleanly to prevent email enumeration
        }

        $token = bin2hex(random_bytes(32));
        $sql = "INSERT INTO password_reset_tokens (id, user_id, token, expires_at) 
                VALUES (?, ?, ?, CURRENT_TIMESTAMP + INTERVAL 1 HOUR)";
        $this->getDb()->query($sql, [Database::generateUuid(), $user['id'], $token]);

        AuditService::log($user['id'], null, 'password_reset_requested', 'users', $user['id']);

        return $token;
    }

    /**
     * Reset password using token
     */
    public function resetPassword(string $token, string $newPassword): bool
    {
        $sql = "SELECT user_id FROM password_reset_tokens 
                WHERE token = ? AND used_at IS NULL AND expires_at > CURRENT_TIMESTAMP 
                LIMIT 1";

        $record = $this->getDb()->fetch($sql, [$token]);
        if (!$record) {
            return false;
        }

        $userId = $record['user_id'];
        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);

        $db = $this->getDb();
        $db->beginTransaction();
        try {
            $this->getUserModel()->updatePassword($userId, $hashed);

            // Mark token as used
            $db->query("UPDATE password_reset_tokens SET used_at = CURRENT_TIMESTAMP WHERE token = ?", [$token]);

            $db->commit();
            AuditService::log($userId, null, 'password_reset_completed', 'users', $userId);
            return true;
        } catch (\Throwable $e) {
            $db->rollback();
            throw $e;
        }
    }
}
