<?php
namespace App\Modules\Auth\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Modules\Auth\Services\AuthService;

/**
 * Authentication Controller
 */
class AuthController extends Controller
{
    private AuthService $authService;

    public function __construct()
    {
        $this->authService = new AuthService();
    }

    public function index(): void
    {
        if (Session::has('user_id')) {
            $this->redirect(Session::get('is_super_admin') ? 'admin' : 'dashboard');
        } else {
            $this->redirect('login');
        }
    }

    public function showLogin(): void
    {
        $this->view('auth.login', [
            'title' => 'Sign In — Kaanti Manager'
        ], 'auth');
    }

    public function login(): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($this->authService->isRateLimited($email, $ip)) {
            Session::flash('error', 'Too many failed login attempts. Please wait 15 minutes before trying again.');
            $this->back();
            return;
        }

        $this->validate($_POST, [
            'email'    => 'required|email',
            'password' => 'required',
        ]);

        $user = $this->authService->login($email, $password);

        if (!$user) {
            Session::flash('error', 'Invalid email address or password.');
            Session::setOldInput(['email' => $email]);
            $this->back();
            return;
        }

        Session::flash('success', 'Welcome back, ' . htmlspecialchars($user['first_name']) . '!');

        if (Session::get('is_super_admin')) {
            $this->redirect('admin');
            return;
        }

        $this->redirect('dashboard');
    }

    public function showRegister(): void
    {
        $this->view('auth.register', [
            'title' => 'Create Account — Kaanti Manager'
        ], 'auth');
    }

    public function register(): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $data = $this->validate($_POST, [
            'first_name' => 'required|string|min:2|max:50',
            'last_name'  => 'required|string|min:2|max:50',
            'email'      => 'required|email|unique:users,email',
            'phone'      => 'required|phone',
            'password'   => 'required|min:8|confirmed',
        ]);

        try {
            $userId = $this->authService->register($data);
            Session::flash('success', 'Your account has been created successfully! Let\'s set up your business.');
            $this->redirect('onboarding');
        } catch (\Throwable $e) {
            error_log('Registration error: ' . $e->getMessage());
            Session::flash('error', 'Unable to create account. Please verify your details or try again later.');
            $this->back();
        }
    }

    public function showForgotPassword(): void
    {
        $this->view('auth.forgot-password', [
            'title' => 'Forgot Password — Kaanti Manager'
        ], 'auth');
    }

    public function forgotPassword(): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $data = $this->validate($_POST, [
            'email' => 'required|email',
        ]);

        $token = $this->authService->forgotPassword($data['email']);

        // In a real environment, send email with reset link. In dev/demo, we provide the link.
        if ($token && env('APP_DEBUG')) {
            $resetUrl = url('reset-password/' . $token);
            Session::flash('info', 'Demo Link: You can reset password here: <a href="' . $resetUrl . '" class="underline font-bold">Reset Password Now</a>');
        } else {
            Session::flash('success', 'If an account exists with that email, a password reset link has been dispatched.');
        }

        $this->back();
    }

    public function showResetPassword(string $token): void
    {
        $this->view('auth.reset-password', [
            'title' => 'Reset Password — Kaanti Manager',
            'token' => $token
        ], 'auth');
    }

    public function resetPassword(): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $data = $this->validate($_POST, [
            'token'    => 'required',
            'password' => 'required|min:8|confirmed',
        ]);

        $success = $this->authService->resetPassword($data['token'], $data['password']);

        if (!$success) {
            Session::flash('error', 'This password reset link is invalid or has expired.');
            $this->redirect('forgot-password');
            return;
        }

        Session::flash('success', 'Your password has been successfully reset. You can now sign in.');
        $this->redirect('login');
    }

    public function logout(): void
    {
        $this->authService->logout();
        Session::flash('info', 'You have been signed out safely.');
        $this->redirect('login');
    }
}
