<?php
namespace App\Modules\Auth\Models;

use App\Core\Database;

/**
 * User Model
 */
class User
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function findByEmail(string $email): ?array
    {
        $sql = "SELECT * FROM users WHERE LOWER(email) = LOWER(?) LIMIT 1";
        $user = $this->db->fetch($sql, [trim($email)]);
        return $user ?: null;
    }

    public function findById(string $id): ?array
    {
        $sql = "SELECT id, email, phone, first_name, last_name, is_super_admin, email_verified_at, status, language, created_at 
                FROM users WHERE id = ? LIMIT 1";
        $user = $this->db->fetch($sql, [$id]);
        return $user ?: null;
    }

    public function create(array $data): string
    {
        $id = Database::generateUuid();
        $sql = "INSERT INTO users (id, email, phone, password_hash, first_name, last_name, language, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 'active')";

        $this->db->query($sql, [
            $id,
            strtolower(trim($data['email'])),
            $data['phone'] ?? null,
            $data['password_hash'],
            trim($data['first_name']),
            trim($data['last_name']),
            $data['language'] ?? 'en'
        ]);

        return $id;
    }

    public function update(string $id, array $data): bool
    {
        $fields = [];
        $params = [];

        foreach ($data as $key => $value) {
            $fields[] = "{$key} = ?";
            $params[] = $value;
        }

        $fields[] = "updated_at = CURRENT_TIMESTAMP";
        $params[] = $id;

        $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?";
        return $this->db->query($sql, $params)->rowCount() > 0;
    }

    public function updatePassword(string $id, string $hashedPassword): bool
    {
        $sql = "UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?";
        return $this->db->query($sql, [$hashedPassword, $id])->rowCount() > 0;
    }
}
