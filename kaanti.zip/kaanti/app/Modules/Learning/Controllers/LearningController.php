<?php
namespace App\Modules\Learning\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Session;

/**
 * Kaanti Learn Controller
 * Educational articles and business literacy guides in English and Hausa.
 */
class LearningController extends Controller
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index(): void
    {
        $lang     = Session::get('user_language', 'en');
        $category = $_GET['category'] ?? '';
        $search   = $_GET['search'] ?? '';

        // Categories
        $sqlCat = "SELECT * FROM learning_categories ORDER BY sort_order ASC";
        $categories = $this->db->fetchAll($sqlCat);

        // Articles Query
        $sql = "SELECT a.*, c.name AS category_name, c.name_ha AS category_name_ha, c.slug AS category_slug
                FROM learning_articles a
                INNER JOIN learning_categories c ON a.category_id = c.id
                WHERE a.status = 'published'";
        $params = [];

        if (!empty($category)) {
            $sql .= " AND c.slug = ?";
            $params[] = $category;
        }

        if (!empty($search)) {
            $sql .= " AND (LOWER(a.title) LIKE LOWER(?) OR LOWER(a.title_ha) LIKE LOWER(?) OR LOWER(a.content) LIKE LOWER(?) OR LOWER(a.content_ha) LIKE LOWER(?))";
            $term = '%' . trim($search) . '%';
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        $sql .= " ORDER BY a.created_at DESC";

        $articles = $this->db->fetchAll($sql, $params);

        $this->view('learning.index', [
            'title'            => 'Kaanti Learn — Business Education',
            'categories'       => $categories,
            'articles'         => $articles,
            'selectedCategory' => $category,
            'search'           => $search,
            'lang'             => $lang,
        ], 'app');
    }

    public function show(string $slug): void
    {
        $lang = Session::get('user_language', 'en');

        $sql = "SELECT a.*, c.name AS category_name, c.name_ha AS category_name_ha, c.slug AS category_slug
                FROM learning_articles a
                INNER JOIN learning_categories c ON a.category_id = c.id
                WHERE a.slug = ? AND a.status = 'published' LIMIT 1";

        $article = $this->db->fetch($sql, [$slug]);

        if (!$article) {
            $this->redirect('learning');
            return;
        }

        // Related articles in same category
        $sqlRelated = "SELECT a.title, a.title_ha, a.slug, a.read_time_minutes 
                       FROM learning_articles a 
                       WHERE a.category_id = ? AND a.id != ? AND a.status = 'published' 
                       LIMIT 3";
        $related = $this->db->fetchAll($sqlRelated, [$article['category_id'], $article['id']]);

        $this->view('learning.show', [
            'title'   => ($lang === 'ha' ? $article['title_ha'] : $article['title']) . ' — Kaanti Learn',
            'article' => $article,
            'related' => $related,
            'lang'    => $lang,
        ], 'app');
    }
}
