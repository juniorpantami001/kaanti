<?php
namespace App\Modules\Dashboard\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Session;
use App\Modules\Sales\Models\Sale;

/**
 * Dashboard Controller
 * Computes live, tenant-scoped metrics, cash flow statistics, and business summaries.
 */
class DashboardController extends Controller
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index(): void
    {
        $businessId = $this->businessId();
        $saleSummary = (new Sale())->getSummary($businessId);

        // 1. Total Income
        $sqlIncome = "SELECT COALESCE(SUM(amount), 0.00) FROM transactions 
                      WHERE business_id = ? AND type = 'income' AND status = 'active'";
        $totalIncome = (float) $this->db->fetchColumn($sqlIncome, [$businessId]);

        // 2. Total Expenses
        $sqlExpense = "SELECT COALESCE(SUM(amount), 0.00) FROM transactions 
                       WHERE business_id = ? AND type = 'expense' AND status = 'active'";
        $totalExpenses = (float) $this->db->fetchColumn($sqlExpense, [$businessId]);

        // 3. Net Cash Flow
        $netCashFlow = $totalIncome - $totalExpenses;

        // 4. Total Active Transactions Count
        $sqlTxCount = "SELECT COUNT(*) FROM transactions WHERE business_id = ? AND status = 'active'";
        $txCount = (int) $this->db->fetchColumn($sqlTxCount, [$businessId]);

        // 5. Total Products in Inventory
        $sqlProducts = "SELECT COUNT(*) FROM inventory WHERE business_id = ? AND status = 'active'";
        $totalProducts = (int) $this->db->fetchColumn($sqlProducts, [$businessId]);

        // 6. Low Stock Products Count
        $sqlLowStock = "SELECT COUNT(*) FROM inventory 
                        WHERE business_id = ? AND status = 'active' AND quantity <= min_stock_level";
        $lowStockCount = (int) $this->db->fetchColumn($sqlLowStock, [$businessId]);

        // 7. Total Customers
        $sqlCustomers = "SELECT COUNT(*) FROM customers WHERE business_id = ?";
        $totalCustomers = (int) $this->db->fetchColumn($sqlCustomers, [$businessId]);

        // 8. Recent 5 Transactions
        $sqlRecent = "SELECT id, type, amount, description, category_name, transaction_date, payment_method, status
                      FROM transactions 
                      WHERE business_id = ? 
                      ORDER BY transaction_date DESC, created_at DESC 
                      LIMIT 5";
        $recentTransactions = $this->db->fetchAll($sqlRecent, [$businessId]);

        // 9. Monthly Cash Flow (Last 6 Months) for Charts
        $sqlMonthly = "SELECT 
                         DATE_FORMAT(transaction_date, '%b') AS month_label,
                         DATE_FORMAT(transaction_date, '%Y-%m-01') AS month_date,
                         SUM(CASE WHEN type = 'income' AND status = 'active' THEN amount ELSE 0 END) AS monthly_income,
                         SUM(CASE WHEN type = 'expense' AND status = 'active' THEN amount ELSE 0 END) AS monthly_expense
                       FROM transactions
                       WHERE business_id = ? 
                         AND transaction_date >= (CURRENT_DATE - INTERVAL 6 MONTH)
                       GROUP BY DATE_FORMAT(transaction_date, '%Y-%m-01'), DATE_FORMAT(transaction_date, '%b')
                       ORDER BY month_date ASC";
        $monthlyStats = $this->db->fetchAll($sqlMonthly, [$businessId]);

        // 10. Expense Category Breakdown for Pie Chart
        $sqlExpenseCat = "SELECT 
                            COALESCE(category_name, 'General Expense') AS category,
                            SUM(amount) AS total
                          FROM transactions
                          WHERE business_id = ? AND type = 'expense' AND status = 'active'
                          GROUP BY category_name
                          ORDER BY total DESC
                          LIMIT 5";
        $expenseCategories = $this->db->fetchAll($sqlExpenseCat, [$businessId]);

        $this->view('dashboard.index', [
            'title'              => 'Dashboard Overview — Kaanti Manager',
            'businessName'       => Session::get('business_name', 'My Business'),
            'businessRole'       => Session::get('business_role', 'owner'),
            'totalIncome'        => $totalIncome,
            'totalExpenses'      => $totalExpenses,
            'netCashFlow'        => $netCashFlow,
            'txCount'            => $txCount,
            'totalProducts'      => $totalProducts,
            'lowStockCount'      => $lowStockCount,
            'totalCustomers'     => $totalCustomers,
            'grossSalesProfit'   => $saleSummary['gross_profit'],
            'recentTransactions' => $recentTransactions,
            'monthlyStats'       => $monthlyStats,
            'expenseCategories'  => $expenseCategories
        ], 'app');
    }
}
