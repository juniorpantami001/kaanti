<?php
namespace App\Modules\Investments\Controllers;

use App\Core\Controller;
use App\Core\Database;

/**
 * Investment Discovery Controller
 * Educational showcase of Shariah-compliant and ethical investments (Sukuk, ethical funds).
 */
class InvestmentController extends Controller
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index(): void
    {
        $type = $_GET['type'] ?? '';

        $sql = "SELECT i.*, p.name AS partner_name 
                FROM investment_products i
                LEFT JOIN partner_institutions p ON i.partner_id = p.id
                WHERE i.status = 'active'";
        $params = [];

        if (!empty($type)) {
            $sql .= " AND i.type = ?";
            $params[] = $type;
        }

        $sql .= " ORDER BY i.is_verified DESC, i.created_at DESC";

        $investments = $this->db->fetchAll($sql, $params);

        $this->view('investments.index', [
            'title'        => 'Ethical Investment Discovery — Kaanti Manager',
            'investments'  => $investments,
            'selectedType' => $type,
        ], 'app');
    }
}
