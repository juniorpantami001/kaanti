<?php
namespace App\Modules\Subscription\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Services\SubscriptionService;

class SubscriptionController extends Controller
{
    private SubscriptionService $subscriptions;

    public function __construct()
    {
        $this->subscriptions = new SubscriptionService();
    }

    public function index(): void
    {
        $userId = $this->userId();
        $businessId = Session::get('business_id');
        $businessOwner = $businessId ? $this->subscriptions->ownerForBusiness($businessId) : false;

        if (!$businessOwner) {
            $this->redirect('onboarding');
            return;
        }

        $ownerUserId = (string) $businessOwner['id'];
        $isOwner = $ownerUserId === $userId;
        $subscription = $this->subscriptions->refreshForOwner($ownerUserId);

        $this->view('subscription.index', [
            'title'        => 'Subscription — Kaanti Manager',
            'subscription' => $subscription,
            'isOwner'      => $isOwner,
        ], 'app');
    }

    public function checkout(): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $userId = $this->userId();
        $businessId = Session::get('business_id');
        $businessOwner = $businessId ? $this->subscriptions->ownerForBusiness($businessId) : false;

        if (!$businessOwner || $businessOwner['id'] !== $userId) {
            Session::flash('error', 'Only the business owner can manage its subscription.');
            $this->redirect('subscription');
            return;
        }

        try {
            $subscription = $this->subscriptions->refreshForOwner($userId);
            if ($subscription && $subscription['status'] === 'active' && $this->subscriptions->hasAccess($userId)) {
                Session::flash('success', 'Your subscription is active.');
                $this->redirect('subscription');
                return;
            }

            $authorizationUrl = $this->subscriptions->startCheckout(
                $userId,
                (string) Session::get('user_email', '')
            );
            header('Location: ' . $authorizationUrl, true, 303);
            exit;
        } catch (\Throwable $e) {
            error_log('Subscription checkout error: ' . $e->getMessage());
            Session::flash('error', 'Could not start subscription checkout. Please try again later.');
            $this->redirect('subscription');
        }
    }

    public function callback(): void
    {
        $reference = $_GET['reference'] ?? $_GET['trxref'] ?? '';
        if (!is_string($reference) || $reference === '') {
            Session::flash('error', 'Payment reference was not provided.');
            $this->redirect('subscription');
            return;
        }

        try {
            $this->subscriptions->verifyAndApply($reference);
            Session::flash('success', 'Payment verified. Your subscription is active.');
        } catch (\Throwable $e) {
            error_log('Subscription callback verification error: ' . $e->getMessage());
            Session::flash('error', 'We could not confirm this payment yet. If you were charged, please contact support.');
        }

        $this->redirect('subscription');
    }

    public function webhook(): void
    {
        $payload = file_get_contents('php://input');
        $signature = $_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '';
        if (!is_string($payload) || !is_string($signature)) {
            http_response_code(400);
            exit;
        }

        try {
            if (!$this->subscriptions->hasValidWebhookSignature($payload, $signature)) {
                http_response_code(401);
                exit;
            }
        } catch (\Throwable $e) {
            error_log('Paystack webhook signature validation error: ' . $e->getMessage());
            http_response_code(500);
            exit;
        }

        try {
            $event = json_decode($payload, true, 512, JSON_THROW_ON_ERROR);
            if (!is_array($event)) {
                http_response_code(400);
                exit;
            }

            $this->subscriptions->handleWebhook($event);
            $this->json(['status' => 'ok']);
        } catch (\Throwable $e) {
            error_log('Paystack webhook processing error: ' . $e->getMessage());
            $this->json(['status' => 'error'], 500);
        }
    }
}
