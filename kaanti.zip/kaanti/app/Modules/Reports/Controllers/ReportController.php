<?php
namespace App\Modules\Reports\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Session;

/**
 * Financial Reports Controller
 * Compiles bookkeeping summaries, monthly aggregations, and printable PDF reports.
 */
class ReportController extends Controller
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index(): void
    {
        $businessId = $this->businessId();

        // Default to current month if no dates provided
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate   = $_GET['end_date'] ?? date('Y-m-t');

        // 1. Total Income in Period
        $sqlIncome = "SELECT COALESCE(SUM(amount), 0.00) FROM transactions 
                      WHERE business_id = ? AND type = 'income' AND status = 'active'
                        AND transaction_date >= ? AND transaction_date <= ?";
        $totalIncome = (float) $this->db->fetchColumn($sqlIncome, [$businessId, $startDate, $endDate]);

        // 2. Total Expenses in Period
        $sqlExpense = "SELECT COALESCE(SUM(amount), 0.00) FROM transactions 
                       WHERE business_id = ? AND type = 'expense' AND status = 'active'
                         AND transaction_date >= ? AND transaction_date <= ?";
        $totalExpenses = (float) $this->db->fetchColumn($sqlExpense, [$businessId, $startDate, $endDate]);

        $netCashFlow = $totalIncome - $totalExpenses;

        // 3. Inflow Breakdown by Category
        $sqlIncomeBreakdown = "SELECT category_name, COUNT(*) AS count, SUM(amount) AS total 
                               FROM transactions 
                               WHERE business_id = ? AND type = 'income' AND status = 'active'
                                 AND transaction_date >= ? AND transaction_date <= ?
                               GROUP BY category_name ORDER BY total DESC";
        $incomeBreakdown = $this->db->fetchAll($sqlIncomeBreakdown, [$businessId, $startDate, $endDate]);

        // 4. Outflow Breakdown by Category
        $sqlExpenseBreakdown = "SELECT category_name, COUNT(*) AS count, SUM(amount) AS total 
                                FROM transactions 
                                WHERE business_id = ? AND type = 'expense' AND status = 'active'
                                  AND transaction_date >= ? AND transaction_date <= ?
                                GROUP BY category_name ORDER BY total DESC";
        $expenseBreakdown = $this->db->fetchAll($sqlExpenseBreakdown, [$businessId, $startDate, $endDate]);

        // 5. Detailed Transactions in Period
        $sqlTx = "SELECT * FROM transactions 
                  WHERE business_id = ? AND status = 'active'
                    AND transaction_date >= ? AND transaction_date <= ?
                  ORDER BY transaction_date ASC, created_at ASC";
        $transactions = $this->db->fetchAll($sqlTx, [$businessId, $startDate, $endDate]);

        $this->view('reports.index', [
            'title'            => 'Financial Reports — Kaanti Manager',
            'businessName'     => Session::get('business_name', 'My Business'),
            'startDate'        => $startDate,
            'endDate'          => $endDate,
            'totalIncome'      => $totalIncome,
            'totalExpenses'    => $totalExpenses,
            'netCashFlow'      => $netCashFlow,
            'incomeBreakdown'  => $incomeBreakdown,
            'expenseBreakdown' => $expenseBreakdown,
            'transactions'     => $transactions,
        ], 'app');
    }

    public function downloadPdf(): void
    {
        $businessId = $this->businessId();
        $startDate  = $_GET['start_date'] ?? date('Y-m-01');
        $endDate    = $_GET['end_date'] ?? date('Y-m-t');

        // Compile same metrics
        $sqlIncome = "SELECT COALESCE(SUM(amount), 0.00) FROM transactions 
                      WHERE business_id = ? AND type = 'income' AND status = 'active'
                        AND transaction_date >= ? AND transaction_date <= ?";
        $totalIncome = (float) $this->db->fetchColumn($sqlIncome, [$businessId, $startDate, $endDate]);

        $sqlExpense = "SELECT COALESCE(SUM(amount), 0.00) FROM transactions 
                       WHERE business_id = ? AND type = 'expense' AND status = 'active'
                         AND transaction_date >= ? AND transaction_date <= ?";
        $totalExpenses = (float) $this->db->fetchColumn($sqlExpense, [$businessId, $startDate, $endDate]);

        $netCashFlow = $totalIncome - $totalExpenses;

        $sqlTx = "SELECT * FROM transactions 
                  WHERE business_id = ? AND status = 'active'
                    AND transaction_date >= ? AND transaction_date <= ?
                  ORDER BY transaction_date ASC, created_at ASC";
        $transactions = $this->db->fetchAll($sqlTx, [$businessId, $startDate, $endDate]);

        // Render printable / PDF view
        $this->view('reports.pdf', [
            'title'         => 'Financial Statement Voucher',
            'businessName'  => Session::get('business_name', 'My Business'),
            'startDate'     => $startDate,
            'endDate'       => $endDate,
            'totalIncome'   => $totalIncome,
            'totalExpenses' => $totalExpenses,
            'netCashFlow'   => $netCashFlow,
            'transactions'  => $transactions,
        ], 'print');
    }
}
