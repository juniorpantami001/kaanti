<?php
namespace App\Modules\Sales\Models;

use App\Core\Database;

class Sale
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function create(
        string $businessId,
        string $userId,
        array $items,
        ?string $customerId,
        string $transactionDate,
        string $paymentMethod
    ): array {
        $items = $this->normalizeItems($items);
        $allowedMethods = ['Cash', 'Bank Transfer', 'POS', 'Mobile Money', 'Cheque'];
        if (!in_array($paymentMethod, $allowedMethods, true)) {
            throw new \InvalidArgumentException('Choose a valid payment method.');
        }

        $this->db->beginTransaction();
        try {
            if ($customerId !== null && !$this->db->fetchColumn(
                'SELECT id FROM customers WHERE business_id = ? AND id = ? LIMIT 1',
                [$businessId, $customerId]
            )) {
                throw new \InvalidArgumentException('The selected customer does not belong to this business.');
            }

            $products = [];
            foreach ($items as $productId => $item) {
                $product = $this->db->fetch(
                    "SELECT id, name, sku, quantity, cost_price
                     FROM inventory
                     WHERE business_id = ? AND id = ? AND status = 'active'
                     LIMIT 1 FOR UPDATE",
                    [$businessId, $productId]
                );
                if (!$product) {
                    throw new \InvalidArgumentException('A selected product is no longer available.');
                }
                if ($item['quantity'] > (int) $product['quantity']) {
                    throw new \InvalidArgumentException(
                        'Not enough stock for ' . $product['name'] . '. Available quantity: ' . $product['quantity'] . '.'
                    );
                }
                $item['line_total'] = $this->multiplyMoney($item['unit_price'], $item['quantity']);
                $item['line_cost'] = $this->multiplyMoney((string) $product['cost_price'], $item['quantity']);
                $totalAmount = isset($totalAmount)
                    ? $this->addMoney($totalAmount, $item['line_total'])
                    : $item['line_total'];
                if ($this->exceedsMoneyLimit($totalAmount)) {
                    throw new \InvalidArgumentException('The sale total exceeds the maximum supported amount.');
                }
                $items[$productId] = $item;
                $products[$productId] = $product;
            }

            $transactionId = Database::generateUuid();
            $reference = 'SAL-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(4)));
            $descriptionParts = [];
            foreach ($items as $productId => $item) {
                $descriptionParts[] = $item['quantity'] . ' x ' . $products[$productId]['name'];
            }
            $description = 'Product sale: ' . implode(', ', $descriptionParts);

            $this->db->query(
                "INSERT INTO transactions
                    (id, business_id, customer_id, category_name, type, amount, description,
                     reference_number, transaction_date, payment_method, status, created_by)
                 VALUES (?, ?, ?, 'Product Sale', 'income', 0, ?, ?, ?, ?, 'active', ?)",
                [
                    $transactionId,
                    $businessId,
                    $customerId,
                    $description,
                    $reference,
                    $transactionDate,
                    $paymentMethod,
                    $userId,
                ]
            );

            foreach ($items as $productId => $item) {
                $product = $products[$productId];
                $previousQuantity = (int) $product['quantity'];
                $newQuantity = $previousQuantity - $item['quantity'];
                $unitCost = (string) $product['cost_price'];

                $this->db->query(
                    "INSERT INTO transaction_items
                        (id, transaction_id, business_id, inventory_id, product_name, sku, quantity,
                         unit_price, unit_cost, line_total, line_cost, line_profit)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ROUND(? - ?, 2))",
                    [
                        Database::generateUuid(),
                        $transactionId,
                        $businessId,
                        $productId,
                        $product['name'],
                        $product['sku'],
                        $item['quantity'],
                        $item['unit_price'],
                        $unitCost,
                        $item['line_total'],
                        $item['line_cost'],
                        $item['line_total'],
                        $item['line_cost'],
                    ]
                );

                $updated = $this->db->query(
                    "UPDATE inventory
                     SET quantity = ?, updated_at = CURRENT_TIMESTAMP
                     WHERE business_id = ? AND id = ? AND status = 'active' AND quantity >= ?",
                    [$newQuantity, $businessId, $productId, $item['quantity']]
                );
                if ($updated->rowCount() !== 1) {
                    throw new \RuntimeException('Stock changed while recording the sale. Please try again.');
                }

                $this->db->query(
                    "INSERT INTO inventory_movements
                        (id, business_id, inventory_id, type, quantity, previous_quantity,
                         new_quantity, reason, created_by)
                     VALUES (?, ?, ?, 'sale', ?, ?, ?, ?, ?)",
                    [
                        Database::generateUuid(),
                        $businessId,
                        $productId,
                        $item['quantity'],
                        $previousQuantity,
                        $newQuantity,
                        'Sale ' . $reference,
                        $userId,
                    ]
                );
            }

            $this->db->query(
                "UPDATE transactions
                 SET amount = ?
                 WHERE id = ? AND business_id = ?",
                [$totalAmount, $transactionId, $businessId]
            );

            if ($customerId !== null) {
                $this->db->query(
                    "UPDATE customers
                     SET total_transactions = total_transactions + 1,
                         total_spent = total_spent + (
                             SELECT amount FROM transactions WHERE id = ? AND business_id = ?
                         ),
                         updated_at = CURRENT_TIMESTAMP
                     WHERE business_id = ? AND id = ?",
                    [$transactionId, $businessId, $businessId, $customerId]
                );
            }

            $totals = $this->db->fetch(
                "SELECT t.amount, COALESCE(SUM(ti.line_profit), 0) AS gross_profit
                 FROM transactions t
                 INNER JOIN transaction_items ti ON ti.transaction_id = t.id AND ti.business_id = t.business_id
                 WHERE t.id = ? AND t.business_id = ?
                 GROUP BY t.id",
                [$transactionId, $businessId]
            );
            $this->db->commit();

            return [
                'id' => $transactionId,
                'reference' => $reference,
                'amount' => (string) $totals['amount'],
                'gross_profit' => (string) $totals['gross_profit'],
            ];
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    public function getSummary(string $businessId): array
    {
        return $this->db->fetch(
            "SELECT COUNT(*) AS sale_count,
                    COALESCE(SUM(t.amount), 0) AS revenue,
                    COALESCE(SUM(items.gross_profit), 0) AS gross_profit,
                    COALESCE(SUM(items.units_sold), 0) AS units_sold
             FROM transactions t
             INNER JOIN (
                 SELECT transaction_id, business_id,
                        SUM(line_profit) AS gross_profit,
                        SUM(quantity) AS units_sold
                 FROM transaction_items
                 GROUP BY transaction_id, business_id
             ) items ON items.transaction_id = t.id AND items.business_id = t.business_id
             WHERE t.business_id = ? AND t.status = 'active'",
            [$businessId]
        ) ?: ['sale_count' => 0, 'revenue' => 0, 'gross_profit' => 0, 'units_sold' => 0];
    }

    public function getTopProducts(string $businessId): array
    {
        return $this->db->fetchAll(
            "SELECT inventory_id, product_name, sku,
                    SUM(quantity) AS units_sold,
                    SUM(line_total) AS revenue,
                    SUM(line_profit) AS gross_profit
             FROM transaction_items ti
             INNER JOIN transactions t ON t.id = ti.transaction_id AND t.business_id = ti.business_id
             WHERE ti.business_id = ? AND t.status = 'active'
             GROUP BY inventory_id, product_name, sku
             ORDER BY units_sold DESC, gross_profit DESC, product_name ASC
             LIMIT 10",
            [$businessId]
        );
    }

    public function getRecentSales(string $businessId): array
    {
        return $this->db->fetchAll(
            "SELECT t.id, t.reference_number, t.transaction_date, t.description, t.amount,
                    t.payment_method, t.status, c.name AS customer_name,
                    items.gross_profit, items.units_sold
             FROM transactions t
             INNER JOIN (
                 SELECT transaction_id, business_id,
                        SUM(line_profit) AS gross_profit,
                        SUM(quantity) AS units_sold
                 FROM transaction_items
                 GROUP BY transaction_id, business_id
             ) items ON items.transaction_id = t.id AND items.business_id = t.business_id
             LEFT JOIN customers c ON c.id = t.customer_id
             WHERE t.business_id = ?
             ORDER BY t.transaction_date DESC, t.created_at DESC
             LIMIT 20",
            [$businessId]
        );
    }

    public function getItems(string $businessId, string $transactionId): array
    {
        return $this->db->fetchAll(
            "SELECT id, product_name, sku, quantity, unit_price, unit_cost,
                    line_total, line_cost, line_profit
             FROM transaction_items
             WHERE business_id = ? AND transaction_id = ?
             ORDER BY created_at ASC",
            [$businessId, $transactionId]
        );
    }

    public function getGrossProfit(string $businessId, string $transactionId): string
    {
        return (string) $this->db->fetchColumn(
            "SELECT COALESCE(SUM(line_profit), 0)
             FROM transaction_items
             WHERE business_id = ? AND transaction_id = ?",
            [$businessId, $transactionId]
        );
    }

    private function normalizeItems(array $items): array
    {
        if (count($items) < 1 || count($items) > 50) {
            throw new \InvalidArgumentException('Add between 1 and 50 product lines to a sale.');
        }

        $normalized = [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                throw new \InvalidArgumentException('A sale line is invalid. Please review the sale items.');
            }

            $productValue = $item['product_id'] ?? null;
            $quantityInput = $item['quantity'] ?? null;
            $unitPriceValue = $item['unit_price'] ?? null;
            if (!is_scalar($productValue) || !is_scalar($quantityInput) || !is_scalar($unitPriceValue)) {
                throw new \InvalidArgumentException('A sale line is incomplete. Please review the sale items.');
            }

            $productId = trim((string) $productValue);
            $quantityValue = (string) $quantityInput;
            $unitPrice = trim((string) $unitPriceValue);

            if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iD', $productId)
                || !preg_match('/^[0-9]+$/D', $quantityValue)) {
                throw new \InvalidArgumentException('Choose a product and enter a whole-number quantity.');
            }
            if (isset($normalized[$productId])) {
                throw new \InvalidArgumentException('Each product can only appear once per sale. Combine its quantity on one line.');
            }

            $quantity = filter_var($quantityValue, FILTER_VALIDATE_INT, [
                'options' => ['min_range' => 1, 'max_range' => 2147483647],
            ]);
            if ($quantity === false) {
                throw new \InvalidArgumentException('Product quantity must be a positive whole number.');
            }
            if (!preg_match('/^[0-9]{1,13}(?:\\.[0-9]{1,2})?$/D', $unitPrice)) {
                throw new \InvalidArgumentException('Enter a valid selling price with no more than two decimal places.');
            }

            $normalized[$productId] = [
                'quantity' => $quantity,
                'unit_price' => $unitPrice,
            ];
        }

        ksort($normalized, SORT_STRING);
        return $normalized;
    }

    private function multiplyMoney(string $amount, int $quantity): string
    {
        [$whole, $fraction] = array_pad(explode('.', $amount, 2), 2, '');
        $cents = ltrim($whole . str_pad($fraction, 2, '0'), '0');
        $cents = $cents === '' ? '0' : $cents;
        $carry = 0;
        $result = '';

        for ($index = strlen($cents) - 1; $index >= 0; $index--) {
            $product = ((int) $cents[$index] * $quantity) + $carry;
            $result = (string) ($product % 10) . $result;
            $carry = intdiv($product, 10);
        }
        while ($carry > 0) {
            $result = (string) ($carry % 10) . $result;
            $carry = intdiv($carry, 10);
        }

        $result = ltrim($result, '0');
        $result = $result === '' ? '0' : $result;
        if (strlen($result) > 15) {
            throw new \InvalidArgumentException('A sale line exceeds the maximum supported amount.');
        }
        $result = str_pad($result, 3, '0', STR_PAD_LEFT);
        return substr($result, 0, -2) . '.' . substr($result, -2);
    }

    private function addMoney(string $first, string $second): string
    {
        $firstCents = str_replace('.', '', $first);
        $secondCents = str_replace('.', '', $second);
        $firstCents = str_pad($firstCents, max(strlen($firstCents), strlen($secondCents)), '0', STR_PAD_LEFT);
        $secondCents = str_pad($secondCents, strlen($firstCents), '0', STR_PAD_LEFT);
        $carry = 0;
        $result = '';

        for ($index = strlen($firstCents) - 1; $index >= 0; $index--) {
            $sum = (int) $firstCents[$index] + (int) $secondCents[$index] + $carry;
            $result = (string) ($sum % 10) . $result;
            $carry = intdiv($sum, 10);
        }
        if ($carry > 0) {
            $result = (string) $carry . $result;
        }

        $result = str_pad($result, 3, '0', STR_PAD_LEFT);
        return substr($result, 0, -2) . '.' . substr($result, -2);
    }

    private function exceedsMoneyLimit(string $amount): bool
    {
        [$whole] = explode('.', $amount, 2);
        $whole = ltrim($whole, '0');
        $whole = $whole === '' ? '0' : $whole;
        return strlen($whole) > 13 || (strlen($whole) === 13 && strcmp($whole, '9999999999999') > 0);
    }
}
