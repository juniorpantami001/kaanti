<?php
namespace App\Modules\Sales\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Modules\Customers\Models\Customer;
use App\Modules\Inventory\Models\Inventory;
use App\Modules\Sales\Models\Sale;
use App\Services\AuditService;

class SaleController extends Controller
{
    private Sale $saleModel;
    private Inventory $inventoryModel;
    private Customer $customerModel;

    public function __construct()
    {
        $this->saleModel = new Sale();
        $this->inventoryModel = new Inventory();
        $this->customerModel = new Customer();
    }

    public function index(): void
    {
        $businessId = $this->businessId();

        $this->view('sales.index', [
            'title' => 'Sales & Product Performance — Kaanti Manager',
            'summary' => $this->saleModel->getSummary($businessId),
            'topProducts' => $this->saleModel->getTopProducts($businessId),
            'recentSales' => $this->saleModel->getRecentSales($businessId),
        ], 'app');
    }

    public function create(): void
    {
        $businessId = $this->businessId();
        $products = $this->inventoryModel->getAll($businessId, ['status' => 'active']);
        $products = array_values(array_filter($products, static function (array $product): bool {
            return (int) $product['quantity'] > 0;
        }));

        $this->view('sales.create', [
            'title' => 'Record a Sale — Kaanti Manager',
            'products' => $products,
            'customers' => $this->customerModel->getAll($businessId),
        ], 'app');
    }

    public function store(): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        foreach (['transaction_date', 'payment_method'] as $field) {
            if (isset($_POST[$field]) && !is_string($_POST[$field])) {
                Session::flash('error', 'Sale date and payment method must be valid selections.');
                $this->back();
                return;
            }
        }

        $data = $this->validate($_POST, [
            'transaction_date' => 'required|date',
            'payment_method' => 'required|in:Cash,Bank Transfer,POS,Mobile Money,Cheque',
        ]);
        $items = $_POST['items'] ?? null;
        if (!is_array($items)) {
            Session::flash('error', 'Add at least one product to the sale.');
            $this->back();
            return;
        }

        $businessId = $this->businessId();
        $userId = $this->userId();
        $customerValue = $_POST['customer_id'] ?? '';
        if (!is_string($customerValue)) {
            Session::flash('error', 'Choose a valid customer or leave the customer field blank.');
            $this->back();
            return;
        }
        $customerId = trim((string) $customerValue) ?: null;

        try {
            $sale = $this->saleModel->create(
                $businessId,
                $userId,
                $items,
                $customerId,
                $data['transaction_date'],
                $data['payment_method']
            );

            AuditService::log($userId, $businessId, 'sale_recorded', 'transactions', $sale['id'], null, [
                'reference' => $sale['reference'],
                'amount' => $sale['amount'],
                'gross_profit' => $sale['gross_profit'],
            ]);

            Session::flash('success', 'Sale recorded. Gross profit: ' . format_naira($sale['gross_profit']) . '.');
            $this->redirect('transactions/' . $sale['id']);
        } catch (\InvalidArgumentException $e) {
            Session::flash('error', $e->getMessage());
            $this->back();
        } catch (\Throwable $e) {
            error_log('Record sale error: ' . $e->getMessage());
            Session::flash('error', 'Unable to record the sale. Please try again.');
            $this->back();
        }
    }
}
