<?php
namespace App\Modules\Business\Models;

use App\Core\Database;

/**
 * Business (Tenant) Model
 */
class Business
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function findById(string $id): ?array
    {
        $sql = "SELECT * FROM businesses WHERE id = ? LIMIT 1";
        $row = $this->db->fetch($sql, [$id]);
        return $row ?: null;
    }

    public function findBySlug(string $slug): ?array
    {
        $sql = "SELECT * FROM businesses WHERE slug = ? LIMIT 1";
        $row = $this->db->fetch($sql, [$slug]);
        return $row ?: null;
    }

    public function getByUserId(string $userId): array
    {
        $sql = "SELECT b.*, bm.role, bm.joined_at 
                FROM businesses b
                INNER JOIN business_members bm ON b.id = bm.business_id
                WHERE bm.user_id = ? AND b.status = 'active'
                ORDER BY bm.joined_at ASC";
        return $this->db->fetchAll($sql, [$userId]);
    }

    public function create(array $data): string
    {
        $id = Database::generateUuid();
        $sql = "INSERT INTO businesses 
                (id, name, slug, type, category, location, state, phone, email, currency, language, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')";

        $this->db->query($sql, [
            $id,
            trim($data['name']),
            $data['slug'],
            $data['type'],
            $data['category'] ?? null,
            $data['location'] ?? null,
            $data['state'] ?? null,
            $data['phone'] ?? null,
            $data['email'] ?? null,
            $data['currency'] ?? 'NGN',
            $data['language'] ?? 'en',
        ]);

        return $id;
    }

    public function addMember(string $businessId, string $userId, string $role = 'owner'): bool
    {
        $sql = "INSERT INTO business_members (id, business_id, user_id, role, status, joined_at) 
                VALUES (?, ?, ?, ?, 'active', CURRENT_TIMESTAMP)
                ON DUPLICATE KEY UPDATE role = VALUES(role), status = 'active'";

        return $this->db->query($sql, [Database::generateUuid(), $businessId, $userId, $role])->rowCount() > 0;
    }

    /**
     * Copy platform default categories into business specific tenant categories
     */
    public function seedDefaultCategories(string $businessId): void
    {
        // Income categories
        $incomeSql = "INSERT INTO income_categories (id, business_id, name, description, icon, is_default)
                      SELECT UUID(), ?, name, description, icon, FALSE 
                      FROM income_categories WHERE business_id IS NULL";
        $this->db->query($incomeSql, [$businessId]);

        // Expense categories
        $expenseSql = "INSERT INTO expense_categories (id, business_id, name, description, icon, is_default)
                       SELECT UUID(), ?, name, description, icon, FALSE 
                       FROM expense_categories WHERE business_id IS NULL";
        $this->db->query($expenseSql, [$businessId]);
    }
}
