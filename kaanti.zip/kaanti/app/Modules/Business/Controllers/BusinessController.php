<?php
namespace App\Modules\Business\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Modules\Business\Models\Business;
use App\Services\AuditService;
use App\Services\SubscriptionService;

/**
 * Business Onboarding & Management Controller
 */
class BusinessController extends Controller
{
    private Business $businessModel;

    public function __construct()
    {
        $this->businessModel = new Business();
    }

    public function showOnboarding(): void
    {
        $userId = $this->userId();
        // If user already has a business, allow them to view or select it, or create another
        $existing = $this->businessModel->getByUserId($userId);

        $this->view('business.onboarding', [
            'title'    => 'Business Setup — Kaanti Manager',
            'existing' => $existing
        ], 'auth');
    }

    public function createBusiness(): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $userId = $this->userId();

        $data = $this->validate($_POST, [
            'name'     => 'required|string|min:2|max:200',
            'type'     => 'required|string',
            'location' => 'required|string',
            'state'    => 'required|string',
            'phone'    => 'required|phone',
            'currency' => 'required|string',
            'language' => 'required|in:en,ha',
        ]);

        // Generate clean unique slug
        $baseSlug = slugify($data['name']);
        $slug = $baseSlug;
        $counter = 1;

        while ($this->businessModel->findBySlug($slug)) {
            $slug = $baseSlug . '-' . $counter;
            $counter++;
        }

        $data['slug'] = $slug;
        $data['category'] = trim($_POST['category'] ?? '');

        try {
            $businessId = $this->businessModel->create($data);

            // Automatically associate user as OWNER
            $this->businessModel->addMember($businessId, $userId, 'owner');
            (new SubscriptionService())->startForNewOwner($userId);

            // Seed business default categories
            $this->businessModel->seedDefaultCategories($businessId);

            // Set session context for tenant
            Session::set('business_id', $businessId);
            Session::set('business_name', $data['name']);
            Session::set('business_role', 'owner');
            Session::set('currency', $data['currency']);
            Session::set('user_language', $data['language']);

            AuditService::log($userId, $businessId, 'business_created', 'businesses', $businessId, null, [
                'name' => $data['name'],
                'type' => $data['type']
            ]);

            Session::flash('success', 'Masha Allah! ' . htmlspecialchars($data['name']) . ' has been set up successfully. Welcome to your dashboard!');
            $this->redirect('dashboard');
        } catch (\Throwable $e) {
            error_log('Business setup error: ' . $e->getMessage());
            Session::flash('error', 'Could not complete business setup. ' . (env('APP_DEBUG') ? $e->getMessage() : 'Please check your information.'));
            $this->back();
        }
    }
}
