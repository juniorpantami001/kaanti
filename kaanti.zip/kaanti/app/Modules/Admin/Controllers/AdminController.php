<?php
namespace App\Modules\Admin\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Session;
use App\Services\AuditService;

/**
 * Super Administrator Controller
 */
class AdminController extends Controller
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index(): void
    {
        // Platform wide counts
        $totalUsers      = (int) $this->db->fetchColumn("SELECT COUNT(*) FROM users");
        $totalBusinesses = (int) $this->db->fetchColumn("SELECT COUNT(*) FROM businesses");
        $activeBusinesses = (int) $this->db->fetchColumn("SELECT COUNT(*) FROM businesses WHERE status = 'active'");
        $suspendedBusinesses = (int) $this->db->fetchColumn("SELECT COUNT(*) FROM businesses WHERE status = 'suspended'");
        $activeSubscriptions = (int) $this->db->fetchColumn("SELECT COUNT(*) FROM owner_subscriptions WHERE status = 'active'");
        $subscriptionsNeedingAttention = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM owner_subscriptions WHERE status IN ('pending', 'past_due', 'suspended')"
        );
        $subscriptionCollections = $this->db->fetch(
            "SELECT COALESCE(SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END), 0) AS lifetime_revenue,
                    COALESCE(SUM(
                        CASE
                            WHEN status = 'paid'
                             AND paid_at >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')
                             AND paid_at < DATE_ADD(DATE_FORMAT(CURRENT_DATE, '%Y-%m-01'), INTERVAL 1 MONTH)
                            THEN amount
                            ELSE 0
                        END
                    ), 0) AS monthly_revenue,
                    COUNT(CASE WHEN status = 'paid' THEN 1 END) AS successful_payments
             FROM subscription_payments"
        );
        $totalTx         = (int) $this->db->fetchColumn("SELECT COUNT(*) FROM transactions");
        $totalVolume     = (float) $this->db->fetchColumn("SELECT COALESCE(SUM(amount), 0.00) FROM transactions WHERE status = 'active'");
        $totalFinancing  = (int) $this->db->fetchColumn("SELECT COUNT(*) FROM financing_products");
        $totalPartners   = (int) $this->db->fetchColumn("SELECT COUNT(*) FROM partner_institutions");

        // Recent Audit Activity
        $sqlAudit = "SELECT a.*, u.email, u.first_name, u.last_name, b.name AS business_name
                     FROM audit_logs a
                     LEFT JOIN users u ON a.user_id = u.id
                     LEFT JOIN businesses b ON a.business_id = b.id
                     ORDER BY a.created_at DESC LIMIT 10";
        $recentAudit = $this->db->fetchAll($sqlAudit);

        $recentBusinesses = $this->db->fetchAll(
            "SELECT b.id, b.name, b.type, b.status, b.created_at,
                    (SELECT u.email
                     FROM business_members owner_member
                     INNER JOIN users u ON u.id = owner_member.user_id
                     WHERE owner_member.business_id = b.id
                       AND owner_member.role = 'owner' AND owner_member.status = 'active'
                     ORDER BY owner_member.joined_at ASC LIMIT 1) AS owner_email,
                    (SELECT s.status
                     FROM business_members owner_member
                     INNER JOIN owner_subscriptions s ON s.owner_user_id = owner_member.user_id
                     WHERE owner_member.business_id = b.id
                       AND owner_member.role = 'owner' AND owner_member.status = 'active'
                     ORDER BY owner_member.joined_at ASC LIMIT 1) AS subscription_status
             FROM businesses b
             ORDER BY b.created_at DESC
             LIMIT 8"
        );

        $this->view('admin.index', [
            'title'           => 'Platform Super Administration — Kaanti Manager',
            'totalUsers'      => $totalUsers,
            'totalBusinesses' => $totalBusinesses,
            'activeBusinesses' => $activeBusinesses,
            'suspendedBusinesses' => $suspendedBusinesses,
            'activeSubscriptions' => $activeSubscriptions,
            'subscriptionsNeedingAttention' => $subscriptionsNeedingAttention,
            'lifetimeSubscriptionRevenue' => (float) ($subscriptionCollections['lifetime_revenue'] ?? 0),
            'monthlySubscriptionRevenue' => (float) ($subscriptionCollections['monthly_revenue'] ?? 0),
            'successfulSubscriptionPayments' => (int) ($subscriptionCollections['successful_payments'] ?? 0),
            'totalTx'         => $totalTx,
            'totalVolume'     => $totalVolume,
            'totalFinancing'  => $totalFinancing,
            'totalPartners'   => $totalPartners,
            'recentAudit'     => $recentAudit,
            'recentBusinesses' => $recentBusinesses,
        ], 'app');
    }

    public function businesses(): void
    {
        $sql = "SELECT b.*, COUNT(DISTINCT bm.user_id) AS member_count, COUNT(DISTINCT t.id) AS tx_count,
                     (SELECT u.email FROM business_members owner_member
                        INNER JOIN users u ON u.id = owner_member.user_id
                        WHERE owner_member.business_id = b.id
                          AND owner_member.role = 'owner' AND owner_member.status = 'active'
                        ORDER BY owner_member.joined_at ASC LIMIT 1) AS owner_email,
                     (SELECT s.status FROM business_members owner_member
                        INNER JOIN owner_subscriptions s ON s.owner_user_id = owner_member.user_id
                        WHERE owner_member.business_id = b.id
                          AND owner_member.role = 'owner' AND owner_member.status = 'active'
                        ORDER BY owner_member.joined_at ASC LIMIT 1) AS subscription_status,
                     (SELECT s.current_period_end FROM business_members owner_member
                        INNER JOIN owner_subscriptions s ON s.owner_user_id = owner_member.user_id
                        WHERE owner_member.business_id = b.id
                          AND owner_member.role = 'owner' AND owner_member.status = 'active'
                        ORDER BY owner_member.joined_at ASC LIMIT 1) AS subscription_period_end
                FROM businesses b
                LEFT JOIN business_members bm ON b.id = bm.business_id
                LEFT JOIN transactions t ON b.id = t.business_id
                GROUP BY b.id
                ORDER BY b.created_at DESC";
        $businesses = $this->db->fetchAll($sql);

        $this->view('admin.businesses', [
            'title'      => 'Manage Businesses — Kaanti Admin',
            'businesses' => $businesses,
        ], 'app');
    }

    public function toggleBusinessStatus(string $id): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $userId = $this->userId();
        $business = $this->db->fetch("SELECT * FROM businesses WHERE id = ? LIMIT 1", [$id]);

        if (!$business) {
            Session::flash('error', 'Business tenant not found.');
            $this->redirect('admin/businesses');
            return;
        }

        $newStatus = ($business['status'] === 'active') ? 'suspended' : 'active';
        $this->db->query("UPDATE businesses SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", [$newStatus, $id]);

        AuditService::log($userId, $id, 'admin_toggle_business_status', 'businesses', $id, ['status' => $business['status']], ['status' => $newStatus]);
        Session::flash('success', 'Business "' . htmlspecialchars($business['name']) . '" status changed to ' . strtoupper($newStatus) . '.');
        $this->redirect('admin/businesses');
    }

    public function users(): void
    {
        $sql = "SELECT u.*, COUNT(DISTINCT bm.business_id) AS business_count
                FROM users u
                LEFT JOIN business_members bm ON u.id = bm.user_id
                GROUP BY u.id
                ORDER BY u.created_at DESC";
        $users = $this->db->fetchAll($sql);

        $this->view('admin.users', [
            'title' => 'Platform Users Directory — Kaanti Admin',
            'users' => $users,
        ], 'app');
    }

    public function auditLogs(): void
    {
        $sql = "SELECT a.*, u.email, u.first_name, u.last_name, b.name AS business_name
                FROM audit_logs a
                LEFT JOIN users u ON a.user_id = u.id
                LEFT JOIN businesses b ON a.business_id = b.id
                ORDER BY a.created_at DESC LIMIT 100";
        $logs = $this->db->fetchAll($sql);

        $this->view('admin.audit', [
            'title' => 'System Audit Trail — Kaanti Admin',
            'logs'  => $logs,
        ], 'app');
    }
}
