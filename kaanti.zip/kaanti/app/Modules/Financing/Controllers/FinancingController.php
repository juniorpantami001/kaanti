<?php
namespace App\Modules\Financing\Controllers;

use App\Core\Controller;
use App\Core\Database;

/**
 * Financing Discovery Controller
 * Educational non-interest and ethical financing opportunities directory.
 */
class FinancingController extends Controller
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index(): void
    {
        $type = $_GET['type'] ?? '';

        $sql = "SELECT f.*, p.name AS partner_name, p.logo_path AS partner_logo, p.website AS partner_website
                FROM financing_products f
                LEFT JOIN partner_institutions p ON f.partner_id = p.id
                WHERE f.status = 'active'";
        $params = [];

        if (!empty($type)) {
            $sql .= " AND f.type = ?";
            $params[] = $type;
        }

        $sql .= " ORDER BY f.is_verified DESC, f.created_at DESC";

        $products = $this->db->fetchAll($sql, $params);

        $this->view('financing.index', [
            'title'        => 'Financing Discovery Directory — Kaanti Manager',
            'products'     => $products,
            'selectedType' => $type,
        ], 'app');
    }

    public function show(string $id): void
    {
        $sql = "SELECT f.*, p.name AS partner_name, p.logo_path AS partner_logo, p.website AS partner_website, p.contact_email AS partner_email, p.contact_phone AS partner_phone
                FROM financing_products f
                LEFT JOIN partner_institutions p ON f.partner_id = p.id
                WHERE f.id = ? AND f.status = 'active' LIMIT 1";

        $product = $this->db->fetch($sql, [$id]);

        if (!$product) {
            $this->redirect('financing');
            return;
        }

        $this->view('financing.show', [
            'title'   => e($product['name']) . ' — Financing Opportunity',
            'product' => $product,
        ], 'app');
    }
}
