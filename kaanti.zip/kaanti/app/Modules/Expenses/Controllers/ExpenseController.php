<?php
namespace App\Modules\Expenses\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Modules\Transactions\Models\Transaction;
use App\Services\AuditService;

/**
 * Expense Management Controller
 */
class ExpenseController extends Controller
{
    private Transaction $transactionModel;

    public function __construct()
    {
        $this->transactionModel = new Transaction();
    }

    public function create(): void
    {
        $businessId = $this->businessId();
        $categories = $this->transactionModel->getCategories($businessId, 'expense');

        $this->view('transactions.expense-create', [
            'title'      => 'Record Expense — Kaanti Manager',
            'categories' => $categories,
        ], 'app');
    }

    public function store(): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $businessId = $this->businessId();
        $userId     = $this->userId();

        $data = $this->validate($_POST, [
            'amount'           => 'required|numeric',
            'description'      => 'required|string|min:2|max:300',
            'transaction_date' => 'required|date',
            'payment_method'   => 'required|string',
            'category_name'    => 'required|string',
        ]);

        $data['type']       = 'expense';
        $data['created_by'] = $userId;

        try {
            $txId = $this->transactionModel->create($businessId, $data);

            AuditService::log($userId, $businessId, 'expense_recorded', 'transactions', $txId, null, [
                'amount'      => $data['amount'],
                'description' => $data['description']
            ]);

            Session::flash('success', 'Expense of ' . format_naira($data['amount']) . ' logged successfully.');
            $this->redirect('transactions');
        } catch (\Throwable $e) {
            error_log('Record expense error: ' . $e->getMessage());
            Session::flash('error', 'Unable to record expense. Please try again.');
            $this->back();
        }
    }
}
