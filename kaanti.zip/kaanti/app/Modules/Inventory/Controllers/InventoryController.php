<?php
namespace App\Modules\Inventory\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Modules\Inventory\Models\Inventory;
use App\Services\AuditService;

/**
 * Inventory Management Controller
 */
class InventoryController extends Controller
{
    private Inventory $inventoryModel;

    public function __construct()
    {
        $this->inventoryModel = new Inventory();
    }

    public function index(): void
    {
        $businessId = $this->businessId();

        $filters = [
            'search'    => $_GET['search'] ?? '',
            'category'  => $_GET['category'] ?? '',
            'low_stock' => !empty($_GET['low_stock']),
            'status'    => $_GET['status'] ?? 'active',
        ];

        $products = $this->inventoryModel->getAll($businessId, $filters);
        $summary  = $this->inventoryModel->getInventorySummary($businessId);

        $this->view('inventory.index', [
            'title'    => 'Inventory Management — Kaanti Manager',
            'products' => $products,
            'summary'  => $summary,
            'filters'  => $filters,
        ], 'app');
    }

    public function create(): void
    {
        $this->view('inventory.create', [
            'title' => 'Add Product to Inventory — Kaanti Manager'
        ], 'app');
    }

    public function store(): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $businessId = $this->businessId();
        $userId     = $this->userId();

        $data = $this->validate($_POST, [
            'name'            => 'required|string|min:2|max:200',
            'cost_price'      => 'required|numeric',
            'selling_price'   => 'required|numeric',
            'quantity'        => 'required|numeric',
            'min_stock_level' => 'required|numeric',
        ]);

        $data['sku']         = $_POST['sku'] ?? null;
        $data['category']    = $_POST['category'] ?? 'General';
        $data['description'] = $_POST['description'] ?? null;

        try {
            $productId = $this->inventoryModel->create($businessId, $data, $userId);
            AuditService::log($userId, $businessId, 'product_created', 'inventory', $productId, null, ['name' => $data['name']]);
            Session::flash('success', 'Product "' . htmlspecialchars($data['name']) . '" added to inventory.');
            $this->redirect('inventory/' . $productId);
        } catch (\Throwable $e) {
            error_log('Add product error: ' . $e->getMessage());
            Session::flash('error', 'Unable to add product. Please check your information.');
            $this->back();
        }
    }

    public function show(string $id): void
    {
        $businessId = $this->businessId();
        $product = $this->inventoryModel->findById($businessId, $id);

        if (!$product) {
            Session::flash('error', 'Product not found.');
            $this->redirect('inventory');
            return;
        }

        $movements = $this->inventoryModel->getMovements($businessId, $id);

        $this->view('inventory.show', [
            'title'     => e($product['name']) . ' — Product Profile',
            'product'   => $product,
            'movements' => $movements,
        ], 'app');
    }

    public function edit(string $id): void
    {
        $businessId = $this->businessId();
        $product = $this->inventoryModel->findById($businessId, $id);

        if (!$product) {
            Session::flash('error', 'Product not found.');
            $this->redirect('inventory');
            return;
        }

        $this->view('inventory.edit', [
            'title'   => 'Edit Product: ' . e($product['name']),
            'product' => $product,
        ], 'app');
    }

    public function update(string $id): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $businessId = $this->businessId();
        $userId     = $this->userId();

        $data = $this->validate($_POST, [
            'name'            => 'required|string|min:2|max:200',
            'cost_price'      => 'required|numeric',
            'selling_price'   => 'required|numeric',
            'min_stock_level' => 'required|numeric',
        ]);

        $data['sku']         = $_POST['sku'] ?? null;
        $data['category']    = $_POST['category'] ?? 'General';
        $data['description'] = $_POST['description'] ?? null;

        try {
            $this->inventoryModel->update($businessId, $id, $data);
            AuditService::log($userId, $businessId, 'product_updated', 'inventory', $id, null, ['name' => $data['name']]);
            Session::flash('success', 'Product updated successfully.');
            $this->redirect('inventory/' . $id);
        } catch (\Throwable $e) {
            error_log('Update product error: ' . $e->getMessage());
            Session::flash('error', 'Unable to update product.');
            $this->back();
        }
    }

    public function adjustStock(string $id): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $businessId = $this->businessId();
        $userId     = $this->userId();

        $data = $this->validate($_POST, [
            'type'     => 'required|in:addition,removal,adjustment,purchase',
            'quantity' => 'required|numeric',
            'reason'   => 'required|string|min:3|max:200',
        ]);

        $success = $this->inventoryModel->adjustStock(
            $businessId,
            $id,
            $data['type'],
            (int) $data['quantity'],
            $data['reason'],
            $userId
        );

        if ($success) {
            AuditService::log($userId, $businessId, 'stock_adjusted', 'inventory', $id, null, [
                'type'     => $data['type'],
                'quantity' => $data['quantity'],
                'reason'   => $data['reason']
            ]);
            Session::flash('success', 'Stock level adjusted and recorded in inventory movements.');
        } else {
            Session::flash('error', 'Failed to adjust stock level.');
        }

        $this->redirect('inventory/' . $id);
    }

    public function archive(string $id): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $businessId = $this->businessId();
        $userId     = $this->userId();

        $this->inventoryModel->archive($businessId, $id);
        AuditService::log($userId, $businessId, 'product_archived', 'inventory', $id);
        Session::flash('success', 'Product has been archived from active catalogue.');
        $this->redirect('inventory');
    }
}
