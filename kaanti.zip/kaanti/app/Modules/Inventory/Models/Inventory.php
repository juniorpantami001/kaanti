<?php
namespace App\Modules\Inventory\Models;

use App\Core\Database;

/**
 * Inventory Model
 * Manages product catalogue, stock levels, valuations, and stock movement logs.
 */
class Inventory
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function getAll(string $businessId, array $filters = []): array
    {
        $sql = "SELECT * FROM inventory WHERE business_id = ?";
        $params = [$businessId];

        if (!empty($filters['status'])) {
            $sql .= " AND status = ?";
            $params[] = $filters['status'];
        } else {
            $sql .= " AND status = 'active'";
        }

        if (!empty($filters['category'])) {
            $sql .= " AND category = ?";
            $params[] = $filters['category'];
        }

        if (!empty($filters['low_stock'])) {
            $sql .= " AND quantity <= min_stock_level";
        }

        if (!empty($filters['search'])) {
            $sql .= " AND (LOWER(name) LIKE LOWER(?) OR LOWER(sku) LIKE LOWER(?) OR LOWER(category) LIKE LOWER(?))";
            $term = '%' . trim($filters['search']) . '%';
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        $sql .= " ORDER BY name ASC";
        return $this->db->fetchAll($sql, $params);
    }

    public function findById(string $businessId, string $id): ?array
    {
        $sql = "SELECT * FROM inventory WHERE business_id = ? AND id = ? LIMIT 1";
        $row = $this->db->fetch($sql, [$businessId, $id]);
        return $row ?: null;
    }

    public function create(string $businessId, array $data, ?string $userId = null): string
    {
        $productId = Database::generateUuid();
        $sql = "INSERT INTO inventory 
                (id, business_id, name, sku, category, description, quantity, cost_price, selling_price, min_stock_level, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')";

        $sku = !empty($data['sku']) ? trim($data['sku']) : ('PRD-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6)));

        $this->db->query($sql, [
            $productId,
            $businessId,
            trim($data['name']),
            $sku,
            !empty($data['category']) ? trim($data['category']) : 'General',
            !empty($data['description']) ? trim($data['description']) : null,
            (int) ($data['quantity'] ?? 0),
            $data['cost_price'] ?? 0.00,
            $data['selling_price'] ?? 0.00,
            (int) ($data['min_stock_level'] ?? 5),
        ]);

        // If initial quantity > 0, log initial stock movement
        if ((int) ($data['quantity'] ?? 0) > 0) {
            $this->logMovement(
                $businessId,
                $productId,
                'addition',
                (int) $data['quantity'],
                0,
                (int) $data['quantity'],
                'Initial opening stock',
                $userId
            );
        }

        return $productId;
    }

    public function update(string $businessId, string $id, array $data): bool
    {
        $sql = "UPDATE inventory 
                SET name = ?, sku = ?, category = ?, description = ?, cost_price = ?, selling_price = ?, min_stock_level = ?, updated_at = CURRENT_TIMESTAMP
                WHERE business_id = ? AND id = ?";

        return $this->db->query($sql, [
            trim($data['name']),
            !empty($data['sku']) ? trim($data['sku']) : null,
            !empty($data['category']) ? trim($data['category']) : 'General',
            !empty($data['description']) ? trim($data['description']) : null,
            $data['cost_price'] ?? 0.00,
            $data['selling_price'] ?? 0.00,
            (int) ($data['min_stock_level'] ?? 5),
            $businessId,
            $id
        ])->rowCount() > 0;
    }

    public function adjustStock(string $businessId, string $id, string $type, int $qty, string $reason, ?string $userId = null): bool
    {
        $product = $this->findById($businessId, $id);
        if (!$product) return false;

        $previousQty = (int) $product['quantity'];
        $newQty = match ($type) {
            'addition', 'purchase' => $previousQty + $qty,
            'removal', 'sale'      => max(0, $previousQty - $qty),
            'adjustment'           => max(0, $qty), // absolute adjustment
            default                => $previousQty,
        };

        $changeAmount = abs($newQty - $previousQty);

        $this->db->beginTransaction();
        try {
            $updateSql = "UPDATE inventory SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE business_id = ? AND id = ?";
            $this->db->query($updateSql, [$newQty, $businessId, $id]);

            $this->logMovement(
                $businessId,
                $id,
                $type,
                $changeAmount,
                $previousQty,
                $newQty,
                $reason,
                $userId
            );

            $this->db->commit();
            return true;
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    public function logMovement(string $businessId, string $inventoryId, string $type, int $qty, int $prevQty, int $newQty, string $reason, ?string $userId = null): void
    {
        $sql = "INSERT INTO inventory_movements 
                (id, business_id, inventory_id, type, quantity, previous_quantity, new_quantity, reason, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $this->db->query($sql, [
            Database::generateUuid(),
            $businessId,
            $inventoryId,
            $type,
            $qty,
            $prevQty,
            $newQty,
            $reason,
            $userId
        ]);
    }

    public function getMovements(string $businessId, string $inventoryId): array
    {
        $sql = "SELECT im.*, u.first_name, u.last_name 
                FROM inventory_movements im
                LEFT JOIN users u ON im.created_by = u.id
                WHERE im.business_id = ? AND im.inventory_id = ?
                ORDER BY im.created_at DESC";
        return $this->db->fetchAll($sql, [$businessId, $inventoryId]);
    }

    public function archive(string $businessId, string $id): bool
    {
        $sql = "UPDATE inventory SET status = 'archived', updated_at = CURRENT_TIMESTAMP WHERE business_id = ? AND id = ?";
        return $this->db->query($sql, [$businessId, $id])->rowCount() > 0;
    }

    public function getInventorySummary(string $businessId): array
    {
        $sql = "SELECT 
                    COUNT(*) AS total_items,
                    COALESCE(SUM(quantity), 0) AS total_units,
                    COALESCE(SUM(quantity * cost_price), 0.00) AS total_cost_valuation,
                    COALESCE(SUM(quantity * selling_price), 0.00) AS total_retail_valuation,
                    COALESCE(SUM(CASE WHEN quantity <= min_stock_level THEN 1 ELSE 0 END), 0) AS low_stock_count
                FROM inventory 
                WHERE business_id = ? AND status = 'active'";

        return $this->db->fetch($sql, [$businessId]) ?: [
            'total_items'          => 0,
            'total_units'          => 0,
            'total_cost_valuation' => 0.00,
            'total_retail_valuation'=> 0.00,
            'low_stock_count'      => 0
        ];
    }
}
