<?php
namespace App\Modules\Transactions\Models;

use App\Core\Database;

/**
 * Transaction Model
 * Multi-tenant scoped financial records.
 * Uses DECIMAL for exact money calculations.
 */
class Transaction
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function getAll(string $businessId, array $filters = []): array
    {
        $sql = "SELECT t.*, c.name AS customer_name 
                FROM transactions t
                LEFT JOIN customers c ON t.customer_id = c.id
                WHERE t.business_id = ?";
        $params = [$businessId];

        if (!empty($filters['type'])) {
            $sql .= " AND t.type = ?";
            $params[] = $filters['type'];
        }

        if (!empty($filters['category_name'])) {
            $sql .= " AND t.category_name = ?";
            $params[] = $filters['category_name'];
        }

        if (!empty($filters['start_date'])) {
            $sql .= " AND t.transaction_date >= ?";
            $params[] = $filters['start_date'];
        }

        if (!empty($filters['end_date'])) {
            $sql .= " AND t.transaction_date <= ?";
            $params[] = $filters['end_date'];
        }

        if (!empty($filters['status'])) {
            $sql .= " AND t.status = ?";
            $params[] = $filters['status'];
        }

        if (!empty($filters['search'])) {
            $sql .= " AND (LOWER(t.description) LIKE LOWER(?) OR LOWER(t.reference_number) LIKE LOWER(?) OR LOWER(c.name) LIKE LOWER(?))";
            $searchTerm = '%' . trim($filters['search']) . '%';
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }

        $sql .= " ORDER BY t.transaction_date DESC, t.created_at DESC";

        if (!empty($filters['limit'])) {
            $sql .= " LIMIT " . (int) $filters['limit'];
        }

        return $this->db->fetchAll($sql, $params);
    }

    public function findById(string $businessId, string $id): ?array
    {
        $sql = "SELECT t.*, c.name AS customer_name, c.phone AS customer_phone, u.first_name, u.last_name 
                FROM transactions t
                LEFT JOIN customers c ON t.customer_id = c.id
                LEFT JOIN users u ON t.created_by = u.id
                WHERE t.business_id = ? AND t.id = ? LIMIT 1";

        $res = $this->db->fetch($sql, [$businessId, $id]);
        return $res ?: null;
    }

    public function create(string $businessId, array $data): string
    {
        $id = Database::generateUuid();
        $ref = $data['reference_number'] ?? ('TXN-' . strtoupper(bin2hex(random_bytes(4))));

        $sql = "INSERT INTO transactions 
                (id, business_id, customer_id, category_id, category_name, type, amount, description, reference_number, transaction_date, payment_method, status, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)";

        $this->db->query($sql, [
            $id,
            $businessId,
            $data['customer_id'] ?? null,
            $data['category_id'] ?? null,
            $data['category_name'] ?? 'General',
            $data['type'],
            $data['amount'],
            trim($data['description']),
            $ref,
            $data['transaction_date'] ?? date('Y-m-d'),
            $data['payment_method'] ?? 'Cash',
            $data['created_by'] ?? null
        ]);

        return $id;
    }

    public function voidTransaction(string $businessId, string $id, string $userId, string $reason): bool
    {
        $this->db->beginTransaction();
        try {
            $transaction = $this->db->fetch(
                "SELECT id, customer_id, amount, reference_number, status
                 FROM transactions
                 WHERE business_id = ? AND id = ?
                 LIMIT 1 FOR UPDATE",
                [$businessId, $id]
            );
            if (!$transaction || $transaction['status'] !== 'active') {
                $this->db->rollback();
                return false;
            }

            $items = $this->db->fetchAll(
                "SELECT inventory_id, product_name, quantity
                 FROM transaction_items
                 WHERE business_id = ? AND transaction_id = ?
                 ORDER BY inventory_id ASC",
                [$businessId, $id]
            );

            foreach ($items as $item) {
                if (empty($item['inventory_id'])) {
                    continue;
                }

                $product = $this->db->fetch(
                    "SELECT quantity
                     FROM inventory
                     WHERE business_id = ? AND id = ?
                     LIMIT 1 FOR UPDATE",
                    [$businessId, $item['inventory_id']]
                );
                if (!$product) {
                    continue;
                }

                $previousQuantity = (int) $product['quantity'];
                $newQuantity = $previousQuantity + (int) $item['quantity'];
                $this->db->query(
                    "UPDATE inventory
                     SET quantity = ?, updated_at = CURRENT_TIMESTAMP
                     WHERE business_id = ? AND id = ?",
                    [$newQuantity, $businessId, $item['inventory_id']]
                );
                $this->db->query(
                    "INSERT INTO inventory_movements
                        (id, business_id, inventory_id, type, quantity, previous_quantity,
                         new_quantity, reason, created_by)
                     VALUES (?, ?, ?, 'addition', ?, ?, ?, ?, ?)",
                    [
                        Database::generateUuid(),
                        $businessId,
                        $item['inventory_id'],
                        $item['quantity'],
                        $previousQuantity,
                        $newQuantity,
                        'Voided sale ' . ($transaction['reference_number'] ?: $transaction['id']),
                        $userId,
                    ]
                );
            }

            if (!empty($transaction['customer_id']) && !empty($items)) {
                $this->db->query(
                    "UPDATE customers
                     SET total_transactions = GREATEST(0, total_transactions - 1),
                         total_spent = GREATEST(0, total_spent - ?),
                         updated_at = CURRENT_TIMESTAMP
                     WHERE business_id = ? AND id = ?",
                    [$transaction['amount'], $businessId, $transaction['customer_id']]
                );
            }

            $updated = $this->db->query(
                "UPDATE transactions
                 SET status = 'voided', voided_at = CURRENT_TIMESTAMP, voided_by = ?,
                     voided_reason = ?, updated_at = CURRENT_TIMESTAMP
                 WHERE business_id = ? AND id = ? AND status = 'active'",
                [$userId, $reason, $businessId, $id]
            );
            if ($updated->rowCount() !== 1) {
                throw new \RuntimeException('Transaction could not be voided.');
            }

            $this->db->commit();
            return true;
        } catch (\Throwable $e) {
            if ($this->db->getConnection()->inTransaction()) {
                $this->db->rollback();
            }
            throw $e;
        }
    }

    public function getCategories(string $businessId, string $type = 'income'): array
    {
        $table = ($type === 'income') ? 'income_categories' : 'expense_categories';
        $sql = "SELECT id, name, icon FROM {$table} 
                WHERE business_id = ? OR business_id IS NULL 
                ORDER BY name ASC";
        return $this->db->fetchAll($sql, [$businessId]);
    }
}
