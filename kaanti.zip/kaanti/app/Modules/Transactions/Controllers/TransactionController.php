<?php
namespace App\Modules\Transactions\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Modules\Sales\Models\Sale;
use App\Modules\Transactions\Models\Transaction;
use App\Services\AuditService;

/**
 * Transactions Controller
 * Manages tenant financial ledger, searching, filtering, and reversal audit trail.
 */
class TransactionController extends Controller
{
    private Transaction $transactionModel;
    private Sale $saleModel;

    public function __construct()
    {
        $this->transactionModel = new Transaction();
        $this->saleModel = new Sale();
    }

    public function index(): void
    {
        $businessId = $this->businessId();

        $filters = [
            'type'          => $_GET['type'] ?? '',
            'category_name' => $_GET['category'] ?? '',
            'start_date'    => $_GET['start_date'] ?? '',
            'end_date'      => $_GET['end_date'] ?? '',
            'search'        => $_GET['search'] ?? '',
            'status'        => $_GET['status'] ?? '',
        ];

        $transactions = $this->transactionModel->getAll($businessId, $filters);
        $incomeCategories = $this->transactionModel->getCategories($businessId, 'income');
        $expenseCategories = $this->transactionModel->getCategories($businessId, 'expense');

        $this->view('transactions.index', [
            'title'             => 'Transactions Ledger — Kaanti Manager',
            'transactions'      => $transactions,
            'filters'           => $filters,
            'incomeCategories'  => $incomeCategories,
            'expenseCategories' => $expenseCategories,
        ], 'app');
    }

    public function show(string $id): void
    {
        $businessId = $this->businessId();
        $transaction = $this->transactionModel->findById($businessId, $id);

        if (!$transaction) {
            Session::flash('error', 'Transaction not found or unauthorized.');
            $this->redirect('transactions');
            return;
        }

        $this->view('transactions.show', [
            'title'       => 'Transaction Voucher #' . e($transaction['reference_number']),
            'transaction' => $transaction,
            'items'       => $this->saleModel->getItems($businessId, $id),
            'grossProfit' => $this->saleModel->getGrossProfit($businessId, $id),
        ], 'app');
    }

    public function void(string $id): void
    {
        if (!$this->validateCSRF()) {
            return;
        }

        $businessId = $this->businessId();
        $userId     = $this->userId();
        $reason     = trim($_POST['void_reason'] ?? 'Reversed by user request');

        if (empty($reason)) {
            $reason = 'Transaction voided by authorized business member';
        }

        try {
            $success = $this->transactionModel->voidTransaction($businessId, $id, $userId, $reason);
        } catch (\Throwable $e) {
            error_log('Void transaction error: ' . $e->getMessage());
            Session::flash('error', 'Unable to void this transaction. No changes were saved.');
            $this->redirect('transactions/' . $id);
            return;
        }

        if ($success) {
            AuditService::log($userId, $businessId, 'transaction_voided', 'transactions', $id, null, ['reason' => $reason]);
            Session::flash('success', 'Transaction has been successfully voided and removed from active cash flow.');
        } else {
            Session::flash('error', 'Unable to void transaction or already voided.');
        }

        $this->redirect('transactions/' . $id);
    }
}
