<?php
namespace App\Middleware;

use App\Core\Session;

/**
 * Authentication Middleware
 * Ensures user is authenticated before accessing protected routes.
 */
class AuthMiddleware
{
    public function handle(): bool
    {
        if (!Session::has('user_id')) {
            Session::flash('warning', 'Please sign in to access your business account.');
            redirect('login');
            return false;
        }

        return true;
    }
}
