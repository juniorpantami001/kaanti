<?php
namespace App\Middleware;

use App\Core\Session;

/**
 * Guest Middleware
 * Ensures already authenticated users are redirected away from login/register pages.
 */
class GuestMiddleware
{
    public function handle(): bool
    {
        if (Session::has('user_id')) {
            redirect(Session::get('is_super_admin') ? 'admin' : 'dashboard');
            return false;
        }

        return true;
    }
}
