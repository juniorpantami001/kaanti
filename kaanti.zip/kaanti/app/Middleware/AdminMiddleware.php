<?php
namespace App\Middleware;

use App\Core\Session;

/**
 * Super Administrator Middleware
 * Strictly guards administration routes and ensures ordinary business tenants cannot access platform controls.
 */
class AdminMiddleware
{
    public function handle(): bool
    {
        if (!Session::has('user_id')) {
            redirect('login');
            return false;
        }

        if (!Session::get('is_super_admin')) {
            Session::flash('error', 'Unauthorized: Super Administrator privileges required.');
            redirect('dashboard');
            return false;
        }

        return true;
    }
}
