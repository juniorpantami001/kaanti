<?php
namespace App\Middleware;

use App\Core\Session;
use App\Core\Database;
use App\Services\SubscriptionService;

/**
 * Business Tenant Middleware
 * Guarantees every tenant-scoped request has an active, verified business_id.
 * Never trusts business IDs supplied by the browser.
 */
class BusinessMiddleware
{
    public function handle(): bool
    {
        $userId = Session::get('user_id');
        if (!$userId) {
            redirect('login');
            return false;
        }

        $businessId = Session::get('business_id');

        if (!$businessId) {
            // Check if user already owns or belongs to a business
            $db = Database::getInstance();
            $sql = "SELECT b.id, b.name, b.slug, bm.role,
                           (SELECT owner.user_id
                            FROM business_members owner
                            WHERE owner.business_id = b.id
                              AND owner.role = 'owner' AND owner.status = 'active'
                            ORDER BY owner.joined_at ASC LIMIT 1) AS owner_user_id
                    FROM businesses b
                    INNER JOIN business_members bm ON b.id = bm.business_id
                    WHERE bm.user_id = ? AND b.status = 'active'
                    ORDER BY bm.joined_at ASC LIMIT 1";

            $membership = $db->fetch($sql, [$userId]);

            if ($membership) {
                Session::set('business_id', $membership['id']);
                Session::set('business_name', $membership['name']);
                Session::set('business_role', $membership['role']);
                return $this->subscriptionAllowsAccess($membership['owner_user_id']);
            }

            // User has no business yet, redirect to onboarding
            redirect('onboarding');
            return false;
        }

        // Verify active membership in the selected business
        $db = Database::getInstance();
        $sql = "SELECT bm.role, b.name, b.status,
                       (SELECT owner.user_id
                        FROM business_members owner
                        WHERE owner.business_id = b.id
                          AND owner.role = 'owner' AND owner.status = 'active'
                        ORDER BY owner.joined_at ASC LIMIT 1) AS owner_user_id
                FROM business_members bm
                INNER JOIN businesses b ON b.id = bm.business_id
                WHERE bm.business_id = ? AND bm.user_id = ? AND b.status = 'active' LIMIT 1";

        $membership = $db->fetch($sql, [$businessId, $userId]);

        if (!$membership) {
            Session::remove('business_id');
            Session::remove('business_name');
            Session::remove('business_role');
            Session::flash('error', 'Access denied to this business account.');
            redirect('onboarding');
            return false;
        }

        Session::set('business_name', $membership['name']);
        Session::set('business_role', $membership['role']);

        return $this->subscriptionAllowsAccess($membership['owner_user_id']);
    }

    private function subscriptionAllowsAccess(?string $ownerUserId): bool
    {
        if ($ownerUserId && (new SubscriptionService())->hasAccess($ownerUserId)) {
            return true;
        }

        Session::flash('error', 'A current business subscription is required. Please ask the business owner to update billing.');
        redirect('subscription');
        return false;
    }
}
