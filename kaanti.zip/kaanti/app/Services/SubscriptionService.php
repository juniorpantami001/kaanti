<?php
namespace App\Services;

use App\Core\Database;

class SubscriptionService
{
    public const MONTHLY_AMOUNT_NAIRA = 5000;
    private const MONTHLY_AMOUNT_KOBO = 500000;
    private const CURRENCY = 'NGN';

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function startForNewOwner(string $ownerUserId): void
    {
        $this->db->query(
            "INSERT IGNORE INTO owner_subscriptions
                (id, owner_user_id, status, activated_at)
             VALUES (?, ?, 'pending', CURRENT_TIMESTAMP)",
            [Database::generateUuid(), $ownerUserId]
        );
    }

    public function findForOwner(string $ownerUserId): array|false
    {
        return $this->db->fetch(
            "SELECT * FROM owner_subscriptions WHERE owner_user_id = ? LIMIT 1",
            [$ownerUserId]
        );
    }

    public function refreshForOwner(string $ownerUserId): array|false
    {
        $subscription = $this->db->fetch(
            "SELECT *,
                    (current_period_end IS NOT NULL AND current_period_end > CURRENT_TIMESTAMP) AS period_is_current
             FROM owner_subscriptions
             WHERE owner_user_id = ?
             LIMIT 1",
            [$ownerUserId]
        );

        if (!$subscription) {
            return false;
        }

        if ($subscription['status'] === 'active' && !(bool) $subscription['period_is_current']) {
            $this->db->query(
                "UPDATE owner_subscriptions
                 SET status = 'suspended', grace_ends_at = NULL,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE owner_user_id = ?",
                [$ownerUserId]
            );
        } elseif (in_array($subscription['status'], ['trialing', 'pending', 'past_due'], true)) {
            $this->db->query(
                "UPDATE owner_subscriptions
                 SET status = 'suspended', grace_ends_at = NULL, updated_at = CURRENT_TIMESTAMP
                 WHERE owner_user_id = ?",
                [$ownerUserId]
            );
        }

        return $this->findForOwner($ownerUserId);
    }

    public function hasAccess(string $ownerUserId): bool
    {
        $subscription = $this->refreshForOwner($ownerUserId);
        if (!$subscription) {
            return false;
        }

        if (in_array($subscription['status'], ['active', 'cancelled'], true)) {
            return $subscription['current_period_end'] !== null
                && (bool) $this->db->fetchColumn(
                    'SELECT ? > CURRENT_TIMESTAMP',
                    [$subscription['current_period_end']]
                );
        }

        return false;
    }

    public function ownerForBusiness(string $businessId): array|false
    {
        return $this->db->fetch(
            "SELECT u.id, u.email
             FROM business_members bm
             INNER JOIN users u ON u.id = bm.user_id
             WHERE bm.business_id = ? AND bm.role = 'owner' AND bm.status = 'active'
             ORDER BY bm.joined_at ASC
             LIMIT 1",
            [$businessId]
        );
    }

    public function startCheckout(string $ownerUserId, string $email): string
    {
        $this->startForNewOwner($ownerUserId);
        $planCode = $this->paystackPlanCode();
        $callbackUrl = rtrim((string) env('APP_URL', ''), '/') . '/subscription/callback';

        if ($callbackUrl === '/subscription/callback') {
            throw new \RuntimeException('APP_URL must be configured before starting subscription checkout.');
        }

        if (env('APP_ENV') === 'production' && parse_url($callbackUrl, PHP_URL_SCHEME) !== 'https') {
            throw new \RuntimeException('Paystack callbacks require an HTTPS APP_URL in production.');
        }

        $response = $this->paystackRequest('POST', '/transaction/initialize', [
            'email'        => $email,
            'amount'       => self::MONTHLY_AMOUNT_KOBO,
            'currency'     => self::CURRENCY,
            'plan'         => $planCode,
            'callback_url' => $callbackUrl,
            'metadata'     => [
                'owner_user_id' => $ownerUserId,
                'purpose'       => 'business_owner_subscription',
            ],
        ]);

        $authorizationUrl = $response['data']['authorization_url'] ?? '';
        $reference = $response['data']['reference'] ?? '';
        $url = is_string($authorizationUrl) ? parse_url($authorizationUrl) : false;
        $host = is_array($url) ? strtolower($url['host'] ?? '') : '';
        if (
            !is_array($url)
            || ($url['scheme'] ?? '') !== 'https'
            || ($host !== 'paystack.com' && !str_ends_with($host, '.paystack.com'))
            || !is_string($reference)
            || $reference === ''
        ) {
            throw new \RuntimeException('Paystack returned an invalid checkout response.');
        }

        $this->db->query(
            "INSERT INTO subscription_payments
                (id, owner_user_id, reference, amount, currency, status)
             VALUES (?, ?, ?, ?, ?, 'pending')",
            [Database::generateUuid(), $ownerUserId, $reference, self::MONTHLY_AMOUNT_NAIRA, self::CURRENCY]
        );
        $this->db->query(
            "UPDATE owner_subscriptions
             SET paystack_plan_code = ?, updated_at = CURRENT_TIMESTAMP
             WHERE owner_user_id = ?",
            [$planCode, $ownerUserId]
        );

        return $authorizationUrl;
    }

    public function verifyAndApply(string $reference): void
    {
        $payment = $this->db->fetch(
            "SELECT owner_user_id, status FROM subscription_payments WHERE reference = ? LIMIT 1",
            [$reference]
        );
        if (!$payment) {
            throw new \RuntimeException('Subscription payment reference was not found.');
        }
        if ($payment['status'] === 'paid') {
            return;
        }

        $response = $this->paystackRequest('GET', '/transaction/verify/' . rawurlencode($reference));
        $data = $response['data'] ?? null;
        if (!is_array($data)) {
            throw new \RuntimeException('Paystack returned an invalid payment verification response.');
        }

        $this->applySuccessfulPayment($data, (string) $payment['owner_user_id'], $reference);
    }

    public function hasValidWebhookSignature(string $payload, string $signature): bool
    {
        $secret = $this->secretKey();
        return $signature !== ''
            && hash_equals(hash_hmac('sha512', $payload, $secret), $signature);
    }

    public function handleWebhook(array $event): void
    {
        $eventName = $event['event'] ?? '';
        $data = $event['data'] ?? null;
        if (!is_array($data)) {
            throw new \RuntimeException('Paystack webhook payload is invalid.');
        }

        if ($eventName === 'charge.success') {
            $this->handleSuccessfulCharge($data);
        } elseif ($eventName === 'subscription.create') {
            $this->handleSubscriptionCreated($data);
        } elseif ($eventName === 'invoice.payment_failed') {
            $this->handleFailedInvoice($data);
        } elseif ($eventName === 'subscription.disable') {
            $this->handleSubscriptionDisabled($data);
        }
    }

    private function handleSuccessfulCharge(array $data): void
    {
        $reference = $data['reference'] ?? '';
        if (!is_string($reference) || $reference === '') {
            throw new \RuntimeException('Paystack charge webhook has no reference.');
        }

        $payment = $this->db->fetch(
            'SELECT owner_user_id FROM subscription_payments WHERE reference = ? LIMIT 1',
            [$reference]
        );
        $ownerUserId = $payment
            ? (string) $payment['owner_user_id']
            : $this->ownerForPaystackData($data);

        if ($ownerUserId === '') {
            return;
        }

        $this->startForNewOwner($ownerUserId);
        if (!$payment) {
            $this->db->query(
                "INSERT IGNORE INTO subscription_payments
                    (id, owner_user_id, reference, amount, currency, status)
                 VALUES (?, ?, ?, ?, ?, 'pending')",
                [
                    Database::generateUuid(),
                    $ownerUserId,
                    $reference,
                    self::MONTHLY_AMOUNT_NAIRA,
                    self::CURRENCY,
                ]
            );
        }

        $this->applySuccessfulPayment($data, $ownerUserId, $reference);
    }

    private function handleSubscriptionCreated(array $data): void
    {
        $email = $this->customerEmail($data);
        $subscriptionCode = $data['subscription_code'] ?? '';
        $customer = $data['customer'] ?? null;
        $customerCode = is_array($customer) ? ($customer['customer_code'] ?? '') : '';
        $plan = $data['plan'] ?? null;
        $planCode = is_array($plan) ? ($plan['plan_code'] ?? '') : ($data['plan_code'] ?? '');
        if (
            !is_string($email)
            || $email === ''
            || !is_string($subscriptionCode)
            || $subscriptionCode === ''
            || !is_string($planCode)
            || $planCode === ''
        ) {
            return;
        }

        $owner = $this->db->fetch(
            "SELECT s.owner_user_id, s.paystack_plan_code
             FROM owner_subscriptions s
             INNER JOIN users u ON u.id = s.owner_user_id
             WHERE LOWER(u.email) = LOWER(?) LIMIT 1",
            [$email]
        );
        if (!$owner || $owner['paystack_plan_code'] !== $planCode) {
            return;
        }

        $this->db->query(
            "UPDATE owner_subscriptions
             SET paystack_subscription_code = ?, paystack_customer_code = ?,
                 updated_at = CURRENT_TIMESTAMP
             WHERE owner_user_id = ?",
            [
                $subscriptionCode,
                is_string($customerCode) ? $customerCode : null,
                $owner['owner_user_id'],
            ]
        );
    }

    private function handleFailedInvoice(array $data): void
    {
        $ownerUserId = $this->ownerForPaystackData($data);
        if ($ownerUserId === '') {
            return;
        }

        $this->db->query(
            "UPDATE owner_subscriptions
             SET status = 'suspended', grace_ends_at = NULL,
                 updated_at = CURRENT_TIMESTAMP
             WHERE owner_user_id = ? AND status IN ('active', 'past_due')",
            [$ownerUserId]
        );
    }

    private function handleSubscriptionDisabled(array $data): void
    {
        $subscriptionCode = $data['subscription_code'] ?? '';
        if (!is_string($subscriptionCode) || $subscriptionCode === '') {
            return;
        }

        $this->db->query(
            "UPDATE owner_subscriptions
             SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
             WHERE paystack_subscription_code = ? AND status = 'active'",
            [$subscriptionCode]
        );
    }

    private function applySuccessfulPayment(array $data, string $ownerUserId, string $reference): void
    {
        if (
            ($data['status'] ?? '') !== 'success'
            || (int) ($data['amount'] ?? 0) !== self::MONTHLY_AMOUNT_KOBO
            || strtoupper((string) ($data['currency'] ?? '')) !== self::CURRENCY
            || (string) ($data['reference'] ?? '') !== $reference
        ) {
            throw new \RuntimeException('Paystack payment verification did not match the subscription charge.');
        }

        $this->db->beginTransaction();
        try {
            $payment = $this->db->fetch(
                "SELECT owner_user_id, status
                 FROM subscription_payments WHERE reference = ? LIMIT 1 FOR UPDATE",
                [$reference]
            );
            if (!$payment || $payment['owner_user_id'] !== $ownerUserId) {
                throw new \RuntimeException('Subscription payment does not match its owner.');
            }
            if ($payment['status'] === 'paid') {
                $this->db->commit();
                return;
            }

            $subscription = $this->db->fetch(
                "SELECT * FROM owner_subscriptions WHERE owner_user_id = ? LIMIT 1 FOR UPDATE",
                [$ownerUserId]
            );
            if (!$subscription) {
                throw new \RuntimeException('Subscription record was not found for the payment owner.');
            }

            $plan = $data['plan'] ?? null;
            $receivedPlanCode = is_array($plan) ? ($plan['plan_code'] ?? '') : ($data['plan_code'] ?? '');
            if (
                is_string($receivedPlanCode)
                && $receivedPlanCode !== ''
                && !empty($subscription['paystack_plan_code'])
                && $receivedPlanCode !== $subscription['paystack_plan_code']
            ) {
                throw new \RuntimeException('Paystack payment used an unexpected subscription plan.');
            }

            $paidPeriodIsCurrent = $subscription['current_period_end'] !== null
                && (bool) $this->db->fetchColumn(
                    'SELECT ? > CURRENT_TIMESTAMP',
                    [$subscription['current_period_end']]
                );
            if (in_array($subscription['status'], ['pending', 'suspended', 'cancelled', 'trialing'], true)
                || !$paidPeriodIsCurrent) {
                $periodStart = $this->db->fetchColumn('SELECT CURRENT_TIMESTAMP');
                $periodEnd = $this->db->fetchColumn(
                    'SELECT DATE_ADD(?, INTERVAL 1 MONTH)',
                    [$periodStart]
                );
            } else {
                $periodStart = $subscription['current_period_end'];
                $periodEnd = $this->db->fetchColumn(
                    'SELECT DATE_ADD(?, INTERVAL 1 MONTH)',
                    [$periodStart]
                );
            }
            $customer = $data['customer'] ?? null;
            $customerCode = is_array($customer) ? ($customer['customer_code'] ?? null) : null;
            $paystackSubscription = $data['subscription'] ?? null;
            $subscriptionCode = is_array($paystackSubscription)
                ? ($paystackSubscription['subscription_code'] ?? null)
                : ($data['subscription_code'] ?? null);

            $this->db->query(
                "UPDATE subscription_payments
                 SET status = 'paid', paid_at = CURRENT_TIMESTAMP
                 WHERE reference = ? AND status = 'pending'",
                [$reference]
            );
            $this->db->query(
                "UPDATE owner_subscriptions
                 SET status = 'active', current_period_start = ?, current_period_end = ?,
                     grace_ends_at = NULL, paystack_customer_code = COALESCE(?, paystack_customer_code),
                     paystack_subscription_code = COALESCE(?, paystack_subscription_code),
                     updated_at = CURRENT_TIMESTAMP
                 WHERE owner_user_id = ?",
                [
                    $periodStart,
                    $periodEnd,
                    is_string($customerCode) ? $customerCode : null,
                    is_string($subscriptionCode) ? $subscriptionCode : null,
                    $ownerUserId,
                ]
            );
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    private function ownerForPaystackData(array $data): string
    {
        $reference = $data['reference'] ?? '';
        if (is_string($reference) && $reference !== '') {
            $payment = $this->db->fetch(
                'SELECT owner_user_id FROM subscription_payments WHERE reference = ? LIMIT 1',
                [$reference]
            );
            if ($payment) {
                return (string) $payment['owner_user_id'];
            }
        }

        $subscription = $data['subscription'] ?? null;
        $subscriptionCode = is_array($subscription)
            ? ($subscription['subscription_code'] ?? '')
            : ($data['subscription_code'] ?? '');
        if (is_string($subscriptionCode) && $subscriptionCode !== '') {
            $ownerUserId = $this->db->fetchColumn(
                'SELECT owner_user_id FROM owner_subscriptions WHERE paystack_subscription_code = ? LIMIT 1',
                [$subscriptionCode]
            );
            if ($ownerUserId) {
                return (string) $ownerUserId;
            }
        }

        $email = $this->customerEmail($data);
        $plan = $data['plan'] ?? null;
        $planCode = is_array($plan) ? ($plan['plan_code'] ?? '') : ($data['plan_code'] ?? '');
        if (!is_string($email) || $email === '' || !is_string($planCode) || $planCode === '') {
            return '';
        }

        $ownerUserId = $this->db->fetchColumn(
            "SELECT s.owner_user_id
             FROM owner_subscriptions s
             INNER JOIN users u ON u.id = s.owner_user_id
             WHERE LOWER(u.email) = LOWER(?) AND s.paystack_plan_code = ?
             LIMIT 1",
            [$email, $planCode]
        );
        return $ownerUserId ? (string) $ownerUserId : '';
    }

    private function customerEmail(array $data): ?string
    {
        $customer = $data['customer'] ?? null;
        $email = is_array($customer) ? ($customer['email'] ?? $data['email'] ?? null) : ($data['email'] ?? null);
        return is_string($email) ? $email : null;
    }

    private function paystackPlanCode(): string
    {
        $configuredPlanCode = env('PAYSTACK_PLAN_CODE');
        if (is_string($configuredPlanCode) && trim($configuredPlanCode) !== '') {
            return trim($configuredPlanCode);
        }

        $storedPlanCode = $this->db->fetchColumn(
            "SELECT setting_value FROM subscription_settings WHERE setting_key = 'paystack_plan_code'"
        );
        if (is_string($storedPlanCode) && $storedPlanCode !== '') {
            return $storedPlanCode;
        }

        $plan = $this->paystackRequest('POST', '/plan', [
            'name'        => 'Kaanti Business Owner Monthly Subscription',
            'interval'    => 'monthly',
            'amount'      => self::MONTHLY_AMOUNT_KOBO,
            'currency'    => self::CURRENCY,
            'description' => 'Monthly Kaanti business owner subscription',
        ]);
        $planCode = $plan['data']['plan_code'] ?? '';
        if (!is_string($planCode) || $planCode === '') {
            throw new \RuntimeException('Paystack did not return a subscription plan code.');
        }

        $this->db->query(
            "INSERT INTO subscription_settings (setting_key, setting_value)
             VALUES ('paystack_plan_code', ?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)",
            [$planCode]
        );

        return $planCode;
    }

    private function paystackRequest(string $method, string $path, ?array $payload = null): array
    {
        $secret = $this->secretKey();
        $curl = curl_init('https://api.paystack.co' . $path);
        if ($curl === false) {
            throw new \RuntimeException('Could not initialize the Paystack connection.');
        }

        $options = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $secret,
                'Content-Type: application/json',
                'Accept: application/json',
            ],
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => 30,
        ];
        if ($payload !== null) {
            $options[CURLOPT_POSTFIELDS] = json_encode($payload, JSON_THROW_ON_ERROR);
        }
        curl_setopt_array($curl, $options);

        $body = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curlError = curl_error($curl);
        curl_close($curl);

        if ($body === false) {
            throw new \RuntimeException('Paystack request failed: ' . $curlError);
        }

        $response = json_decode($body, true);
        if (!is_array($response) || $status < 200 || $status >= 300 || !($response['status'] ?? false)) {
            $message = is_array($response) && is_string($response['message'] ?? null)
                ? $response['message']
                : 'Unexpected response from Paystack.';
            throw new \RuntimeException('Paystack request failed: ' . $message);
        }

        return $response;
    }

    private function secretKey(): string
    {
        $secret = env('PAYSTACK_SECRET_KEY');
        if (!is_string($secret) || trim($secret) === '') {
            throw new \RuntimeException('PAYSTACK_SECRET_KEY is not configured in .env.');
        }

        return trim($secret);
    }
}
