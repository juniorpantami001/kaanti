<?php
namespace App\Services;

use App\Core\Database;

/**
 * Platform & Financial Audit Service
 * Records audit logs for compliance, security, and tenant tracking.
 */
class AuditService
{
    public static function log(
        ?string $userId,
        ?string $businessId,
        string $action,
        string $entityType,
        ?string $entityId = null,
        ?array $oldValues = null,
        ?array $newValues = null
    ): void {
        try {
            $db = Database::getInstance();

            $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
            $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;

            $sql = "INSERT INTO audit_logs 
                    (id, user_id, business_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";

            $db->query($sql, [
                Database::generateUuid(),
                $userId,
                $businessId,
                $action,
                $entityType,
                $entityId,
                $oldValues ? json_encode($oldValues) : null,
                $newValues ? json_encode($newValues) : null,
                $ipAddress,
                $userAgent ? substr($userAgent, 0, 500) : null
            ]);
        } catch (\Throwable $e) {
            // Fail safely without halting main business execution
            error_log('Audit logging failed: ' . $e->getMessage());
        }
    }
}
