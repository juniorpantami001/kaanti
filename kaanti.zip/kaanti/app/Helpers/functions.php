<?php
/**
 * Kaanti Manager — Global Helper Functions
 */

use App\Core\{Env, Session, CSRF, View};

/**
 * Get environment variable
 */
function env(string $key, mixed $default = null): mixed
{
    return Env::get($key, $default);
}

/**
 * Get config value with dot notation
 */
function config(string $key, mixed $default = null): mixed
{
    static $configs = [];

    $parts = explode('.', $key);
    $file  = $parts[0];

    if (!isset($configs[$file])) {
        $path = ROOT_PATH . '/config/' . $file . '.php';
        $configs[$file] = file_exists($path) ? require $path : [];
    }

    $value = $configs[$file];
    for ($i = 1; $i < count($parts); $i++) {
        $value = $value[$parts[$i]] ?? $default;
    }

    return $value;
}

/**
 * Generate URL for an asset file
 */
function asset(string $path): string
{
    $base = rtrim(env('APP_URL', ''), '/');
    return $base . '/assets/' . ltrim($path, '/');
}

/**
 * Generate full URL for a route path
 */
function url(string $path = ''): string
{
    $base = rtrim(env('APP_URL', ''), '/');
    return $base . '/' . ltrim($path, '/');
}

/**
 * Escape HTML output
 */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Generate CSRF hidden input field
 */
function csrf_field(): string
{
    return CSRF::field();
}

/**
 * Get the current CSRF token
 */
function csrf_token(): string
{
    return CSRF::token();
}

/**
 * Get old form input value
 */
function old(string $field, mixed $default = ''): mixed
{
    return Session::getOldInput($field, $default);
}

/**
 * Set a flash message
 */
function flash(string $type, string $message): void
{
    Session::flash($type, $message);
}

/**
 * Redirect to a URL
 */
function redirect(string $path): void
{
    $base = rtrim(env('APP_URL', ''), '/');
    $url  = $base . '/' . ltrim($path, '/');
    header('Location: ' . $url);
    exit;
}

/**
 * Format amount as Nigerian Naira
 */
function format_naira(string|float|int|null $amount): string
{
    $amount = (float) ($amount ?? 0);
    return '₦' . number_format($amount, 2, '.', ',');
}

/**
 * Human-readable time ago
 */
function time_ago(string $datetime): string
{
    $now  = new DateTime('now', new DateTimeZone('Africa/Lagos'));
    $then = new DateTime($datetime, new DateTimeZone('Africa/Lagos'));
    $diff = $now->diff($then);

    if ($diff->y > 0) return $diff->y . ' year' . ($diff->y > 1 ? 's' : '') . ' ago';
    if ($diff->m > 0) return $diff->m . ' month' . ($diff->m > 1 ? 's' : '') . ' ago';
    if ($diff->d > 0) return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
    if ($diff->h > 0) return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
    if ($diff->i > 0) return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '') . ' ago';

    return 'Just now';
}

/**
 * Check if the current URL path matches a given path (for active nav)
 */
function is_active(string $path): bool
{
    $currentUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $base       = rtrim(parse_url(env('APP_URL', ''), PHP_URL_PATH), '/');
    $current    = str_replace($base, '', $currentUri);
    $current    = '/' . trim($current, '/');
    $path       = '/' . trim($path, '/');

    return str_starts_with($current, $path);
}

/**
 * Get active CSS class if path matches
 */
function active_class(string $path, string $class = 'active'): string
{
    return is_active($path) ? $class : '';
}

/**
 * Get validation errors for a specific field
 */
function field_errors(array $errors, string $field): array
{
    return $errors[$field] ?? [];
}

/**
 * Check if a field has errors
 */
function has_error(array $errors, string $field): bool
{
    return !empty($errors[$field]);
}

/**
 * Generate a URL-friendly slug
 */
function slugify(string $text): string
{
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
    $text = preg_replace('/[\s-]+/', '-', $text);
    return trim($text, '-');
}

/**
 * Format a date nicely
 */
function format_date(?string $date, string $format = 'M j, Y'): string
{
    if (!$date) return '—';
    try {
        return (new DateTime($date))->format($format);
    } catch (Exception) {
        return $date;
    }
}

/**
 * Truncate text to a length
 */
function str_limit(string $text, int $limit = 100, string $end = '...'): string
{
    if (mb_strlen($text) <= $limit) {
        return $text;
    }
    return mb_substr($text, 0, $limit) . $end;
}
