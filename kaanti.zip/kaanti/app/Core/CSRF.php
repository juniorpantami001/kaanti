<?php
namespace App\Core;

/**
 * CSRF protection token management
 */
class CSRF
{
    private const TOKEN_KEY = '_csrf_token';

    /**
     * Generate a new CSRF token
     */
    public static function generate(): string
    {
        $token = bin2hex(random_bytes(32));
        Session::set(self::TOKEN_KEY, $token);
        return $token;
    }

    /**
     * Get current token, or generate one if none exists
     */
    public static function token(): string
    {
        if (!Session::has(self::TOKEN_KEY)) {
            return self::generate();
        }
        return Session::get(self::TOKEN_KEY);
    }

    /**
     * Return an HTML hidden input with the token
     */
    public static function field(): string
    {
        $token = self::token();
        return '<input type="hidden" name="_csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
    }

    /**
     * Validate a submitted token
     */
    public static function validate(?string $submittedToken): bool
    {
        if ($submittedToken === null) {
            return false;
        }

        $storedToken = Session::get(self::TOKEN_KEY);

        if ($storedToken === null) {
            return false;
        }

        $valid = hash_equals($storedToken, $submittedToken);

        // Regenerate token after validation (single-use)
        self::generate();

        return $valid;
    }
}
