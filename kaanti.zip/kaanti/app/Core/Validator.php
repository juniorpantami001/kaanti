<?php
namespace App\Core;

/**
 * Server-side input validator
 */
class Validator
{
    private array $errors = [];
    private array $data;
    private ?Database $db = null;

    public function __construct(array $data)
    {
        $this->data = $data;
    }

    private function getDb(): Database
    {
        if ($this->db === null) {
            $this->db = Database::getInstance();
        }
        return $this->db;
    }

    /**
     * Validate data against rules. Returns array of errors (empty = valid).
     */
    public static function validate(array $data, array $rules): array
    {
        $validator = new self($data);
        $validator->applyRules($rules);
        return $validator->errors;
    }

    private function applyRules(array $rules): void
    {
        foreach ($rules as $field => $ruleString) {
            $fieldRules = is_array($ruleString) ? $ruleString : explode('|', $ruleString);
            $value      = $this->data[$field] ?? null;
            $label      = ucfirst(str_replace('_', ' ', $field));

            // Check if nullable and value is empty
            if (in_array('nullable', $fieldRules, true) && ($value === null || $value === '')) {
                continue;
            }

            foreach ($fieldRules as $rule) {
                if ($rule === 'nullable') continue;

                $params = [];
                if (str_contains($rule, ':')) {
                    [$rule, $paramStr] = explode(':', $rule, 2);
                    $params = explode(',', $paramStr);
                }

                match ($rule) {
                    'required'  => $this->validateRequired($field, $value, $label),
                    'email'     => $this->validateEmail($field, $value, $label),
                    'min'       => $this->validateMin($field, $value, $label, (int) $params[0]),
                    'max'       => $this->validateMax($field, $value, $label, (int) $params[0]),
                    'numeric'   => $this->validateNumeric($field, $value, $label),
                    'string'    => $this->validateString($field, $value, $label),
                    'confirmed' => $this->validateConfirmed($field, $value, $label),
                    'unique'    => $this->validateUnique($field, $value, $label, $params[0], $params[1] ?? $field, $params[2] ?? null),
                    'phone'     => $this->validatePhone($field, $value, $label),
                    'date'      => $this->validateDate($field, $value, $label),
                    'in'        => $this->validateIn($field, $value, $label, $params),
                    default     => null,
                };
            }
        }
    }

    private function validateRequired(string $field, mixed $value, string $label): void
    {
        if ($value === null || $value === '' || $value === []) {
            $this->errors[$field][] = "{$label} is required.";
        }
    }

    private function validateEmail(string $field, mixed $value, string $label): void
    {
        if ($value !== null && $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field][] = "Please enter a valid email address.";
        }
    }

    private function validateMin(string $field, mixed $value, string $label, int $min): void
    {
        if ($value !== null && $value !== '' && strlen((string) $value) < $min) {
            $this->errors[$field][] = "{$label} must be at least {$min} characters.";
        }
    }

    private function validateMax(string $field, mixed $value, string $label, int $max): void
    {
        if ($value !== null && $value !== '' && strlen((string) $value) > $max) {
            $this->errors[$field][] = "{$label} must not exceed {$max} characters.";
        }
    }

    private function validateNumeric(string $field, mixed $value, string $label): void
    {
        if ($value !== null && $value !== '' && !is_numeric($value)) {
            $this->errors[$field][] = "{$label} must be a number.";
        }
    }

    private function validateString(string $field, mixed $value, string $label): void
    {
        if ($value !== null && !is_string($value)) {
            $this->errors[$field][] = "{$label} must be text.";
        }
    }

    private function validateConfirmed(string $field, mixed $value, string $label): void
    {
        $confirmField = $field . '_confirmation';
        $confirmValue = $this->data[$confirmField] ?? null;

        if ($value !== $confirmValue) {
            $this->errors[$field][] = "{$label} confirmation does not match.";
        }
    }

    private function validateUnique(string $field, mixed $value, string $label, string $table, string $column, ?string $exceptId = null): void
    {
        if ($value === null || $value === '') {
            return;
        }

        $sql    = "SELECT COUNT(*) FROM {$table} WHERE {$column} = ?";
        $params = [$value];

        if ($exceptId !== null) {
            $sql     .= ' AND id != ?';
            $params[] = $exceptId;
        }

        $count = $this->getDb()->fetchColumn($sql, $params);

        if ((int) $count > 0) {
            $this->errors[$field][] = "This {$label} is already taken.";
        }
    }

    private function validatePhone(string $field, mixed $value, string $label): void
    {
        if ($value !== null && $value !== '') {
            $cleaned = preg_replace('/[\s\-\(\)\+]/', '', $value);
            if (!preg_match('/^\d{10,15}$/', $cleaned)) {
                $this->errors[$field][] = "Please enter a valid phone number.";
            }
        }
    }

    private function validateDate(string $field, mixed $value, string $label): void
    {
        if ($value !== null && $value !== '') {
            $date = \DateTime::createFromFormat('Y-m-d', $value);
            if (!$date || $date->format('Y-m-d') !== $value) {
                $this->errors[$field][] = "Please enter a valid date.";
            }
        }
    }

    private function validateIn(string $field, mixed $value, string $label, array $allowed): void
    {
        if ($value !== null && $value !== '' && !in_array($value, $allowed, true)) {
            $this->errors[$field][] = "{$label} is not a valid option.";
        }
    }
}
