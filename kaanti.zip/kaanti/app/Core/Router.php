<?php
namespace App\Core;

/**
 * HTTP Router with middleware support
 */
class Router
{
    private array $routes = [];
    private array $groupStack = [];
    private string $basePath;

    public function __construct()
    {
        // Detect the base path from APP_URL
        $appUrl = env('APP_URL', '');
        $parsed = parse_url($appUrl);
        $this->basePath = rtrim($parsed['path'] ?? '', '/');
    }

    /**
     * Register a GET route
     */
    public function get(string $uri, string $action, array $middleware = []): self
    {
        return $this->addRoute('GET', $uri, $action, $middleware);
    }

    /**
     * Register a POST route
     */
    public function post(string $uri, string $action, array $middleware = []): self
    {
        return $this->addRoute('POST', $uri, $action, $middleware);
    }

    /**
     * Register route group with shared attributes
     */
    public function group(array $attributes, callable $callback): void
    {
        $this->groupStack[] = $attributes;
        $callback($this);
        array_pop($this->groupStack);
    }

    private function addRoute(string $method, string $uri, string $action, array $middleware = []): self
    {
        // Apply group prefixes and middleware
        $prefix          = '';
        $groupMiddleware = [];

        foreach ($this->groupStack as $group) {
            if (isset($group['prefix'])) {
                $prefix .= '/' . trim($group['prefix'], '/');
            }
            if (isset($group['middleware'])) {
                $mw = is_array($group['middleware']) ? $group['middleware'] : [$group['middleware']];
                $groupMiddleware = array_merge($groupMiddleware, $mw);
            }
        }

        $fullUri    = rtrim($prefix . '/' . ltrim($uri, '/'), '/') ?: '/';
        $allMiddleware = array_merge($groupMiddleware, $middleware);

        $this->routes[] = [
            'method'     => $method,
            'uri'        => $fullUri,
            'action'     => $action,
            'middleware'  => $allMiddleware,
        ];

        return $this;
    }

    /**
     * Dispatch the current request
     */
    public function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri    = $this->getRequestUri();

        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) {
                continue;
            }

            $params = $this->matchRoute($route['uri'], $uri);

            if ($params !== false) {
                // Run middleware
                foreach ($route['middleware'] as $middlewareClass) {
                    $mw = new $middlewareClass();
                    $result = $mw->handle();
                    if ($result === false) {
                        return; // Middleware halted the request
                    }
                }

                // Parse controller@method
                $this->callAction($route['action'], $params);
                return;
            }
        }

        // No route matched — 404
        $this->notFound();
    }

    /**
     * Get the clean request URI relative to the base path
     */
    private function getRequestUri(): string
    {
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $uri = rawurldecode($uri);

        // Remove base path
        if ($this->basePath && str_starts_with($uri, $this->basePath)) {
            $uri = substr($uri, strlen($this->basePath));
        }

        $uri = '/' . trim($uri, '/');

        return $uri ?: '/';
    }

    /**
     * Match a route pattern against a URI, return params or false
     */
    private function matchRoute(string $pattern, string $uri): array|false
    {
        $pattern = '/' . trim($pattern, '/');
        $uri     = '/' . trim($uri, '/');

        if ($pattern === $uri) {
            return [];
        }

        // Convert {param} to regex capture groups
        $regex = preg_replace('/\{([a-zA-Z_]+)\}/', '(?P<$1>[^/]+)', $pattern);
        $regex = '#^' . $regex . '$#';

        if (preg_match($regex, $uri, $matches)) {
            return array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
        }

        return false;
    }

    /**
     * Call the controller action
     */
    private function callAction(string $action, array $params): void
    {
        if (!str_contains($action, '@')) {
            throw new \RuntimeException("Invalid route action: {$action}");
        }

        [$controllerClass, $method] = explode('@', $action);

        // Resolve full class name under App\Modules namespace
        if (!str_starts_with($controllerClass, 'App\\')) {
            $controllerClass = 'App\\Modules\\' . $controllerClass;
        }

        if (!class_exists($controllerClass)) {
            throw new \RuntimeException("Controller not found: {$controllerClass}");
        }

        $controller = new $controllerClass();

        if (!method_exists($controller, $method)) {
            throw new \RuntimeException("Method {$method} not found in {$controllerClass}");
        }

        call_user_func_array([$controller, $method], $params);
    }

    /**
     * Render 404 page
     */
    private function notFound(): void
    {
        http_response_code(404);
        $viewPath = ROOT_PATH . '/resources/views/errors/404.php';
        if (file_exists($viewPath)) {
            require $viewPath;
        } else {
            echo '<h1>404 — Page Not Found</h1>';
        }
    }
}
