<?php
namespace App\Core;

/**
 * Base Controller
 */
abstract class Controller
{
    /**
     * Render a view with optional layout
     */
    protected function view(string $view, array $data = [], string $layout = 'app'): void
    {
        View::render($view, $data, $layout);
    }

    /**
     * Redirect to a URL
     */
    protected function redirect(string $path): void
    {
        $base = rtrim(env('APP_URL', ''), '/');
        $url  = $base . '/' . ltrim($path, '/');
        header('Location: ' . $url);
        exit;
    }

    /**
     * Return JSON response
     */
    protected function json(mixed $data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    /**
     * Redirect back to the previous page
     */
    protected function back(): void
    {
        $referer = $_SERVER['HTTP_REFERER'] ?? env('APP_URL', '/');
        header('Location: ' . $referer);
        exit;
    }

    /**
     * Validate CSRF token from POST data
     */
    protected function validateCSRF(): bool
    {
        $token = $_POST['_csrf_token'] ?? null;
        if (!CSRF::validate($token)) {
            Session::flash('error', 'Invalid security token. Please try again.');
            $this->back();
            return false;
        }
        return true;
    }

    /**
     * Get the currently authenticated user ID
     */
    protected function userId(): ?string
    {
        return Session::get('user_id');
    }

    /**
     * Get the current business ID from session
     */
    protected function businessId(): ?string
    {
        return Session::get('business_id');
    }

    /**
     * Validate input and redirect back with errors if invalid
     */
    protected function validate(array $data, array $rules): array
    {
        $errors = Validator::validate($data, $rules);

        if (!empty($errors)) {
            Session::setErrors($errors);
            Session::setOldInput($data);
            $this->back();
        }

        return $data;
    }
}
