<?php
namespace App\Core;

/**
 * View renderer with layout support
 */
class View
{
    /**
     * Render a view file with optional layout wrapping
     */
    public static function render(string $view, array $data = [], ?string $layout = null): void
    {
        $viewPath = ROOT_PATH . '/resources/views/' . str_replace('.', '/', $view) . '.php';

        if (!file_exists($viewPath)) {
            throw new \RuntimeException("View not found: {$view} ({$viewPath})");
        }

        // Extract data variables into scope
        extract($data);

        // Provide flash messages and errors to every view
        $flash  = Session::getFlash();
        $errors = Session::getErrors();
        $oldInput = $_SESSION['_old_input'] ?? [];

        // Capture view content
        ob_start();
        require $viewPath;
        $content = ob_get_clean();

        // If a layout is specified, wrap content in layout
        if ($layout !== null) {
            $layoutPath = ROOT_PATH . '/resources/views/layouts/' . $layout . '.php';
            if (!file_exists($layoutPath)) {
                throw new \RuntimeException("Layout not found: {$layout}");
            }
            require $layoutPath;
        } else {
            echo $content;
        }

        // Clear old input after rendering
        Session::clearOldInput();
    }

    /**
     * Render a partial/component
     */
    public static function component(string $name, array $data = []): void
    {
        $path = ROOT_PATH . '/resources/views/components/' . $name . '.php';

        if (!file_exists($path)) {
            throw new \RuntimeException("Component not found: {$name}");
        }

        extract($data);
        require $path;
    }

    /**
     * Escape output for safe HTML display
     */
    public static function e(?string $value): string
    {
        return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
    }
}
