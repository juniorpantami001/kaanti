<?php
namespace App\Core;

/**
 * Secure session management
 */
class Session
{
    private static bool $started = false;

    public static function start(): void
    {
        if (self::$started || session_status() === PHP_SESSION_ACTIVE) {
            self::$started = true;
            return;
        }

        $lifetime = (int) env('SESSION_LIFETIME', 120) * 60;
        $secure   = env('APP_ENV') === 'production';

        if (!headers_sent()) {
            ini_set('session.cookie_httponly', '1');
            ini_set('session.cookie_samesite', 'Lax');
            ini_set('session.use_strict_mode', '1');
            ini_set('session.use_only_cookies', '1');
            ini_set('session.gc_maxlifetime', (string) $lifetime);

            if ($secure) {
                ini_set('session.cookie_secure', '1');
            }

            session_set_cookie_params([
                'lifetime' => $lifetime,
                'path'     => '/',
                'httponly'  => true,
                'samesite' => 'Lax',
                'secure'   => $secure,
            ]);
        }

        if (session_status() !== PHP_SESSION_ACTIVE) {
            @session_start();
        }

        self::$started = true;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return $_SESSION[$key] ?? $default;
    }

    public static function set(string $key, mixed $value): void
    {
        $_SESSION[$key] = $value;
    }

    public static function has(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    public static function remove(string $key): void
    {
        unset($_SESSION[$key]);
    }

    /**
     * Set a flash message (available only for the next request)
     */
    public static function flash(string $type, string $message): void
    {
        $_SESSION['_flash'][] = [
            'type'    => $type,
            'message' => $message,
        ];
    }

    /**
     * Get and clear all flash messages
     */
    public static function getFlash(): array
    {
        $messages = $_SESSION['_flash'] ?? [];
        unset($_SESSION['_flash']);
        return $messages;
    }

    /**
     * Store old input for form repopulation
     */
    public static function setOldInput(array $data): void
    {
        unset($data['password'], $data['password_confirmation'], $data['_csrf_token']);
        $_SESSION['_old_input'] = $data;
    }

    /**
     * Get old input value
     */
    public static function getOldInput(string $key, mixed $default = ''): mixed
    {
        return $_SESSION['_old_input'][$key] ?? $default;
    }

    /**
     * Clear old input
     */
    public static function clearOldInput(): void
    {
        unset($_SESSION['_old_input']);
    }

    /**
     * Store validation errors
     */
    public static function setErrors(array $errors): void
    {
        $_SESSION['_errors'] = $errors;
    }

    /**
     * Get and clear validation errors
     */
    public static function getErrors(): array
    {
        $errors = $_SESSION['_errors'] ?? [];
        unset($_SESSION['_errors']);
        return $errors;
    }

    /**
     * Regenerate session ID to prevent fixation
     */
    public static function regenerate(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE && !headers_sent()) {
            session_regenerate_id(true);
        }
    }

    /**
     * Destroy the entire session
     */
    public static function destroy(): void
    {
        $_SESSION = [];

        if (ini_get('session.use_cookies') && !headers_sent()) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }

        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
        self::$started = false;
    }

    public static function isStarted(): bool
    {
        return self::$started;
    }
}
