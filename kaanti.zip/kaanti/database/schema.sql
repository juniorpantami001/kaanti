-- ====================================================================
-- KAANTI MANAGER — DATABASE SCHEMA (MySQL 8.0.16+)
-- Multi-Tenant SME Financial Management SaaS
-- ====================================================================


-- Custom ENUM types if needed or CHECK constraints for maximum compatibility
-- 1. USERS
CREATE TABLE IF NOT EXISTS users (
    id CHAR(36) NOT NULL PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(30) NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    is_super_admin BOOLEAN NOT NULL DEFAULT FALSE,
    email_verified_at DATETIME NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'pending')),
    language VARCHAR(10) NOT NULL DEFAULT 'en' CHECK (language IN ('en', 'ha')),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_users_email (email),
    INDEX idx_users_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 2. USER PROFILES
CREATE TABLE IF NOT EXISTS profiles (
    id CHAR(36) NOT NULL PRIMARY KEY,
    user_id CHAR(36) NOT NULL UNIQUE,
    avatar_url VARCHAR(500) NULL,
    gender VARCHAR(20) NULL,
    address TEXT NULL,
    state VARCHAR(50) NULL,
    country VARCHAR(50) NOT NULL DEFAULT 'Nigeria',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_profiles_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. PASSWORD RESET TOKENS
CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id CHAR(36) NOT NULL PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    token VARCHAR(255) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    used_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_password_reset_token (token),
    CONSTRAINT fk_password_reset_tokens_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 4. EMAIL VERIFICATION TOKENS
CREATE TABLE IF NOT EXISTS email_verification_tokens (
    id CHAR(36) NOT NULL PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    token VARCHAR(255) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_email_verification_tokens_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. BUSINESSES (TENANTS)
CREATE TABLE IF NOT EXISTS businesses (
    id CHAR(36) NOT NULL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    type VARCHAR(50) NOT NULL,
    category VARCHAR(100) NULL,
    location TEXT NULL,
    state VARCHAR(50) NULL,
    phone VARCHAR(30) NULL,
    email VARCHAR(255) NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'NGN',
    language VARCHAR(10) NOT NULL DEFAULT 'en',
    logo_path VARCHAR(500) NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_businesses_slug (slug),
    INDEX idx_businesses_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 6. BUSINESS MEMBERS (TENANT USERS & ROLES)
CREATE TABLE IF NOT EXISTS business_members (
    id CHAR(36) NOT NULL PRIMARY KEY,
    business_id CHAR(36) NOT NULL,
    user_id CHAR(36) NOT NULL,
    role VARCHAR(30) NOT NULL DEFAULT 'staff' CHECK (role IN ('owner', 'administrator', 'manager', 'staff')),
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'invited')),
    joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_business_user UNIQUE (business_id, user_id),
    INDEX idx_business_members_business (business_id),
    INDEX idx_business_members_user (user_id),
    CONSTRAINT fk_business_members_business_id FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    CONSTRAINT fk_business_members_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 7. BUSINESS SETTINGS
CREATE TABLE IF NOT EXISTS business_settings (
    id CHAR(36) NOT NULL PRIMARY KEY,
    business_id CHAR(36) NOT NULL,
    `key` VARCHAR(100) NOT NULL,
    `value` TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_business_key UNIQUE (business_id, `key`),
    CONSTRAINT fk_business_settings_business_id FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. INCOME CATEGORIES
CREATE TABLE IF NOT EXISTS income_categories (
    id CHAR(36) NOT NULL PRIMARY KEY,
    business_id CHAR(36) NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT NULL,
    icon VARCHAR(50) NULL DEFAULT 'trending-up',
    is_default BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_income_cat_business (business_id),
    CONSTRAINT fk_income_categories_business_id FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 9. EXPENSE CATEGORIES
CREATE TABLE IF NOT EXISTS expense_categories (
    id CHAR(36) NOT NULL PRIMARY KEY,
    business_id CHAR(36) NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT NULL,
    icon VARCHAR(50) NULL DEFAULT 'trending-down',
    is_default BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_expense_cat_business (business_id),
    CONSTRAINT fk_expense_categories_business_id FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 10. CUSTOMERS
CREATE TABLE IF NOT EXISTS customers (
    id CHAR(36) NOT NULL PRIMARY KEY,
    business_id CHAR(36) NOT NULL,
    name VARCHAR(255) NOT NULL,
    business_name VARCHAR(255) NULL,
    phone VARCHAR(30) NULL,
    email VARCHAR(255) NULL,
    address TEXT NULL,
    notes TEXT NULL,
    total_transactions INTEGER NOT NULL DEFAULT 0,
    total_spent DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_customers_business (business_id),
    INDEX idx_customers_phone (phone),
    CONSTRAINT fk_customers_business_id FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 11. INVENTORY (PRODUCTS)
CREATE TABLE IF NOT EXISTS inventory (
    id CHAR(36) NOT NULL PRIMARY KEY,
    business_id CHAR(36) NOT NULL,
    name VARCHAR(255) NOT NULL,
    sku VARCHAR(100) NULL,
    category VARCHAR(100) NULL,
    description TEXT NULL,
    quantity INTEGER NOT NULL DEFAULT 0,
    cost_price DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    selling_price DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    min_stock_level INTEGER NOT NULL DEFAULT 5,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived')),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_inventory_business (business_id),
    INDEX idx_inventory_status (status),
    CONSTRAINT fk_inventory_business_id FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 12. INVENTORY MOVEMENTS (STOCK AUDIT)
CREATE TABLE IF NOT EXISTS inventory_movements (
    id CHAR(36) NOT NULL PRIMARY KEY,
    inventory_id CHAR(36) NOT NULL,
    business_id CHAR(36) NOT NULL,
    type VARCHAR(30) NOT NULL CHECK (type IN ('addition', 'removal', 'adjustment', 'sale', 'purchase')),
    quantity INTEGER NOT NULL,
    previous_quantity INTEGER NOT NULL,
    new_quantity INTEGER NOT NULL,
    reason TEXT NULL,
    created_by CHAR(36) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_inv_movements_business (business_id),
    INDEX idx_inv_movements_inventory (inventory_id),
    CONSTRAINT fk_inventory_movements_inventory_id FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE CASCADE,
    CONSTRAINT fk_inventory_movements_business_id FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    CONSTRAINT fk_inventory_movements_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 13. TRANSACTIONS
CREATE TABLE IF NOT EXISTS transactions (
    id CHAR(36) NOT NULL PRIMARY KEY,
    business_id CHAR(36) NOT NULL,
    customer_id CHAR(36) NULL,
    category_id CHAR(36) NULL,
    category_name VARCHAR(100) NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('income', 'expense')),
    amount DECIMAL(15,2) NOT NULL CHECK (amount >= 0),
    description TEXT NOT NULL,
    reference_number VARCHAR(100) NULL,
    transaction_date DATE NOT NULL DEFAULT (CURRENT_DATE),
    payment_method VARCHAR(50) NOT NULL DEFAULT 'Cash' CHECK (payment_method IN ('Cash', 'Bank Transfer', 'POS', 'Mobile Money', 'Cheque', 'Credit')),
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'voided')),
    voided_at DATETIME NULL,
    voided_reason TEXT NULL,
    voided_by CHAR(36) NULL,
    created_by CHAR(36) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_transactions_business (business_id),
    INDEX idx_transactions_date (transaction_date),
    INDEX idx_transactions_type (type),
    INDEX idx_transactions_status (status),
    CONSTRAINT fk_transactions_business_id FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    CONSTRAINT fk_transactions_customer_id FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
    CONSTRAINT fk_transactions_voided_by FOREIGN KEY (voided_by) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_transactions_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13a. TRANSACTION ITEMS (INVENTORY SALES AND COST SNAPSHOTS)
CREATE TABLE IF NOT EXISTS transaction_items (
    id CHAR(36) NOT NULL PRIMARY KEY,
    transaction_id CHAR(36) NOT NULL,
    business_id CHAR(36) NOT NULL,
    inventory_id CHAR(36) NULL,
    product_name VARCHAR(255) NOT NULL,
    sku VARCHAR(100) NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(15,2) NOT NULL CHECK (unit_price >= 0),
    unit_cost DECIMAL(15,2) NOT NULL CHECK (unit_cost >= 0),
    line_total DECIMAL(15,2) NOT NULL,
    line_cost DECIMAL(15,2) NOT NULL,
    line_profit DECIMAL(15,2) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_transaction_items_transaction (transaction_id),
    INDEX idx_transaction_items_business_product (business_id, inventory_id),
    CONSTRAINT fk_transaction_items_transaction FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE CASCADE,
    CONSTRAINT fk_transaction_items_inventory FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 14. FINANCIAL REPORTS CACHE / EXPORTS
CREATE TABLE IF NOT EXISTS financial_reports (
    id CHAR(36) NOT NULL PRIMARY KEY,
    business_id CHAR(36) NOT NULL,
    report_type VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_income DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    total_expenses DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    net_profit DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    file_path VARCHAR(500) NULL,
    generated_by CHAR(36) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_financial_reports_business_id FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    CONSTRAINT fk_financial_reports_generated_by FOREIGN KEY (generated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 15. PARTNER INSTITUTIONS
CREATE TABLE IF NOT EXISTS partner_institutions (
    id CHAR(36) NOT NULL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    description TEXT NULL,
    website VARCHAR(255) NULL,
    logo_path VARCHAR(500) NULL,
    contact_email VARCHAR(255) NULL,
    contact_phone VARCHAR(50) NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 16. FINANCING PRODUCTS (SHARIAH / ETHICAL DISCOVERY)
CREATE TABLE IF NOT EXISTS financing_products (
    id CHAR(36) NOT NULL PRIMARY KEY,
    partner_id CHAR(36) NULL,
    provider VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL CHECK (type IN ('Murabaha', 'Musharakah', 'Mudarabah', 'Ijarah', 'Salam', 'Other')),
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    eligibility TEXT NULL,
    application_process TEXT NULL,
    terms_and_fees TEXT NULL,
    contact_info TEXT NULL,
    application_link VARCHAR(500) NULL,
    is_verified BOOLEAN NOT NULL DEFAULT FALSE,
    verification_date DATE NULL,
    is_demo BOOLEAN NOT NULL DEFAULT TRUE,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_financing_products_partner_id FOREIGN KEY (partner_id) REFERENCES partner_institutions(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 17. INVESTMENT PRODUCTS (SUKUK & ETHICAL FUNDS)
CREATE TABLE IF NOT EXISTS investment_products (
    id CHAR(36) NOT NULL PRIMARY KEY,
    partner_id CHAR(36) NULL,
    provider VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL CHECK (type IN ('Sukuk', 'Islamic Fund', 'Ethical Equity', 'Real Estate Fund', 'Other')),
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    risk_disclosure TEXT NOT NULL,
    fees TEXT NULL,
    provider_link VARCHAR(500) NULL,
    is_verified BOOLEAN NOT NULL DEFAULT FALSE,
    is_demo BOOLEAN NOT NULL DEFAULT TRUE,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_investment_products_partner_id FOREIGN KEY (partner_id) REFERENCES partner_institutions(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 18. CONSENT RECORDS
CREATE TABLE IF NOT EXISTS consent_records (
    id CHAR(36) NOT NULL PRIMARY KEY,
    user_id CHAR(36) NOT NULL,
    business_id CHAR(36) NULL,
    consent_type VARCHAR(100) NOT NULL,
    granted BOOLEAN NOT NULL DEFAULT TRUE,
    granted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    revoked_at DATETIME NULL,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_consent_records_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_consent_records_business_id FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 19. AUDIT LOGS
CREATE TABLE IF NOT EXISTS audit_logs (
    id CHAR(36) NOT NULL PRIMARY KEY,
    user_id CHAR(36) NULL,
    business_id CHAR(36) NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    entity_id VARCHAR(100) NULL,
    old_values JSON NULL,
    new_values JSON NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_business (business_id),
    INDEX idx_audit_created (created_at),
    CONSTRAINT fk_audit_logs_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_audit_logs_business_id FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 20. LEARNING CATEGORIES
CREATE TABLE IF NOT EXISTS learning_categories (
    id CHAR(36) NOT NULL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    name_ha VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    description TEXT NULL,
    icon VARCHAR(50) NULL DEFAULT 'book-open',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 21. LEARNING ARTICLES
CREATE TABLE IF NOT EXISTS learning_articles (
    id CHAR(36) NOT NULL PRIMARY KEY,
    category_id CHAR(36) NOT NULL,
    title VARCHAR(255) NOT NULL,
    title_ha VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    content TEXT NOT NULL,
    content_ha TEXT NOT NULL,
    excerpt TEXT NULL,
    excerpt_ha TEXT NULL,
    author_id CHAR(36) NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'published' CHECK (status IN ('draft', 'published')),
    featured_image VARCHAR(500) NULL,
    read_time_minutes INTEGER NOT NULL DEFAULT 3,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    published_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_learning_articles_slug (slug),
    INDEX idx_learning_articles_status (status),
    CONSTRAINT fk_learning_articles_category_id FOREIGN KEY (category_id) REFERENCES learning_categories(id) ON DELETE CASCADE,
    CONSTRAINT fk_learning_articles_author_id FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 22. LOGIN ATTEMPTS (RATE LIMITING & SECURITY)
CREATE TABLE IF NOT EXISTS login_attempts (
    id CHAR(36) NOT NULL PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    successful BOOLEAN NOT NULL DEFAULT FALSE,
    INDEX idx_login_attempts_email (email),
    INDEX idx_login_attempts_time (attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 23. OWNER SUBSCRIPTIONS
CREATE TABLE IF NOT EXISTS owner_subscriptions (
    id CHAR(36) NOT NULL PRIMARY KEY,
    owner_user_id CHAR(36) NOT NULL UNIQUE,
    status VARCHAR(20) NOT NULL DEFAULT 'pending'
        CHECK (status IN ('trialing', 'pending', 'active', 'past_due', 'suspended', 'cancelled')),
    activated_at DATETIME NOT NULL,
    current_period_start DATETIME NULL,
    current_period_end DATETIME NULL,
    grace_ends_at DATETIME NULL,
    paystack_customer_code VARCHAR(100) NULL,
    paystack_subscription_code VARCHAR(100) NULL,
    paystack_plan_code VARCHAR(100) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_owner_subscription_paystack_code (paystack_subscription_code),
    INDEX idx_owner_subscriptions_status (status),
    INDEX idx_owner_subscriptions_period_end (current_period_end),
    CONSTRAINT fk_owner_subscriptions_user FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 24. OWNER SUBSCRIPTION PAYMENTS
CREATE TABLE IF NOT EXISTS subscription_payments (
    id CHAR(36) NOT NULL PRIMARY KEY,
    owner_user_id CHAR(36) NOT NULL,
    reference VARCHAR(100) NOT NULL UNIQUE,
    amount DECIMAL(15,2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'NGN',
    status VARCHAR(20) NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'paid', 'failed')),
    paid_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_subscription_payments_owner (owner_user_id),
    CONSTRAINT fk_subscription_payments_user FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 25. SUBSCRIPTION SETTINGS
CREATE TABLE IF NOT EXISTS subscription_settings (
    setting_key VARCHAR(100) NOT NULL PRIMARY KEY,
    setting_value VARCHAR(255) NOT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


