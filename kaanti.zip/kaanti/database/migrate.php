<?php
/**
 * Kaanti Manager — Database Migration & Seed CLI Runner
 * 
 * Usage: php database/migrate.php [--seed]
 */

define('ROOT_PATH', dirname(__DIR__));
require ROOT_PATH . '/vendor/autoload.php';

use App\Core\Env;
use App\Core\Database;

echo "========================================================\n";
echo "   KAANTI MANAGER — DATABASE MIGRATOR (MySQL)           \n";
echo "========================================================\n\n";

// Load environment
Env::load(ROOT_PATH . '/.env');

$dbHost = env('DB_HOST', 'localhost');
$dbPort = env('DB_PORT', '3306');
$dbName = env('DB_DATABASE', 'kaanti_manager');
$dbUser = env('DB_USERNAME', 'root');
$dbPass = env('DB_PASSWORD', '');

echo "Connecting to MySQL at {$dbHost}:{$dbPort} for database '{$dbName}'...\n";

try {
    $db = Database::getInstance();
    $pdo = $db->getConnection();
    echo "✓ Connected to MySQL successfully!\n\n";

    // 1. Run Schema
    $schemaFile = ROOT_PATH . '/database/schema.sql';
    if (!file_exists($schemaFile)) {
        die("Error: schema.sql file not found at {$schemaFile}\n");
    }

    echo "Running schema migration from database/schema.sql...\n";
    $schemaSql = file_get_contents($schemaFile);
    $pdo->exec($schemaSql);
    $transactionItemsBusinessForeignKey = $pdo->query("
        SELECT CONSTRAINT_NAME
        FROM information_schema.REFERENTIAL_CONSTRAINTS
        WHERE CONSTRAINT_SCHEMA = DATABASE()
          AND TABLE_NAME = 'transaction_items'
          AND CONSTRAINT_NAME = 'fk_transaction_items_business'
        LIMIT 1
    ")->fetchColumn();
    if ($transactionItemsBusinessForeignKey) {
        $pdo->exec('ALTER TABLE transaction_items DROP FOREIGN KEY fk_transaction_items_business');
    }
    echo "✓ Database schema created / verified successfully!\n\n";

    // Existing owners must complete payment before accessing business features.
    $pdo->exec("
        INSERT IGNORE INTO owner_subscriptions
            (id, owner_user_id, status, activated_at, current_period_start, current_period_end, grace_ends_at)
        SELECT
            UUID(),
            bm.user_id,
            'suspended',
            CURRENT_TIMESTAMP,
            NULL,
            NULL,
            NULL
        FROM business_members bm
        WHERE bm.role = 'owner' AND bm.status = 'active'
        GROUP BY bm.user_id
    ");
    $pdo->exec("
        UPDATE owner_subscriptions
        SET status = 'suspended',
            current_period_start = NULL,
            current_period_end = NULL,
            grace_ends_at = NULL,
            updated_at = CURRENT_TIMESTAMP
        WHERE status IN ('trialing', 'pending', 'past_due')
    ");

    // 2. Check Seed Option
    $runSeed = in_array('--seed', $argv, true) || true; // Default run seed

    if ($runSeed) {
        $seedFile = ROOT_PATH . '/database/seeders/seed.sql';
        if (file_exists($seedFile)) {
            echo "Seeding default categories and demo discovery listings from database/seeders/seed.sql...\n";
            $seedSql = file_get_contents($seedFile);
            $pdo->exec($seedSql);
            echo "✓ Initial seed data populated successfully!\n\n";
        }
    }

    // 3. Create Super Admin if not already existing
    $adminEmail = env('ADMIN_EMAIL', 'admin@kaanti.com');
    $checkAdmin = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
    $checkAdmin->execute([$adminEmail]);
    if (!$checkAdmin->fetch()) {
        $password = env('ADMIN_PASSWORD');
        if (!is_string($password) || strlen($password) < 12) {
            fwrite(STDERR, "Set ADMIN_PASSWORD to a unique password of at least 12 characters in .env before creating the admin account.\n");
            exit(1);
        }

        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $insertAdmin = $pdo->prepare("
            INSERT INTO users (id, email, phone, password_hash, first_name, last_name, is_super_admin, status, language)
            VALUES (?, ?, '08000000000', ?, 'Super', 'Administrator', TRUE, 'active', 'en')
        ");
        $insertAdmin->execute([Database::generateUuid(), $adminEmail, $hashed]);
        echo "✓ Created Super Admin account for {$adminEmail}.\n\n";
    }

    echo "========================================================\n";
    echo "   MIGRATION COMPLETED SUCCESSFULLY!                    \n";
    echo "========================================================\n";

} catch (\PDOException $e) {
    echo "\n❌ Database Error: " . $e->getMessage() . "\n";
    echo "Please verify that:\n";
    echo "1. MySQL server is running on {$dbHost}:{$dbPort}.\n";
    echo "2. The database '{$dbName}' exists (e.g. run 'CREATE DATABASE {$dbName};').\n";
    echo "3. Credentials in .env (DB_USERNAME, DB_PASSWORD) are accurate.\n\n";
    exit(1);
}
