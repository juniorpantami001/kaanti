-- ====================================================================
-- KAANTI MANAGER — SEED DATA
-- Default Categories, Demo Discovery Products & Initial Setup
-- ====================================================================
-- 1. DEFAULT INCOME CATEGORIES (business_id is NULL for platform defaults)
INSERT IGNORE INTO income_categories (id, name, description, icon, is_default) VALUES
(UUID(), 'Sales Revenue', 'Income from direct sale of goods and products', 'shopping-cart', TRUE),
(UUID(), 'Services Rendered', 'Revenue from services and consulting offered', 'briefcase', TRUE),
(UUID(), 'Commissions', 'Commissions earned on referrals or agency services', 'percent', TRUE),
(UUID(), 'Customer Deposits', 'Advances and down payments received', 'download', TRUE),
(UUID(), 'Other Income', 'Miscellaneous business receipts and gains', 'plus-circle', TRUE);

-- 2. DEFAULT EXPENSE CATEGORIES (business_id is NULL for platform defaults)
INSERT IGNORE INTO expense_categories (id, name, description, icon, is_default) VALUES
(UUID(), 'Inventory & Stock Purchases', 'Cost of goods purchased for resale', 'package', TRUE),
(UUID(), 'Shop & Office Rent', 'Rental payments for commercial spaces', 'home', TRUE),
(UUID(), 'Utilities (Electricity, Water)', 'PHCN/NEPA bills, generator diesel, water supply', 'zap', TRUE),
(UUID(), 'Salaries & Wages', 'Staff payments, daily worker compensation', 'users', TRUE),
(UUID(), 'Transportation & Delivery', 'Fuel, logistics, haulage, rider deliveries', 'truck', TRUE),
(UUID(), 'Marketing & Signage', 'Adverts, market associations, banners, social media', 'megaphone', TRUE),
(UUID(), 'Repairs & Maintenance', 'Store repairs, vehicle servicing, equipment fixing', 'wrench', TRUE),
(UUID(), 'Bank Charges & POS Fees', 'Transfer fees, POS merchant charges, stamp duty', 'credit-card', TRUE),
(UUID(), 'Taxes & Levies', 'Local government tickets, market union dues, revenues', 'file-text', TRUE),
(UUID(), 'Other Expenses', 'General miscellaneous operational expenses', 'minus-circle', TRUE);

-- 3. LEARNING CATEGORIES (Bilingual: English & Hausa)
INSERT IGNORE INTO learning_categories (id, name, name_ha, slug, description, icon, sort_order) VALUES
(UUID(), 'Recordkeeping Essentials', 'Tushen Rubuta Bayanai', 'recordkeeping-essentials', 'Basic bookkeeping and daily cash logging for SMEs', 'book-open', 1),
(UUID(), 'Cash Flow & Budgeting', 'Gudanar da Kudi da Tsari', 'cash-flow-budgeting', 'How to separate business money from personal money', 'dollar-sign', 2),
(UUID(), 'Inventory Control', 'Kula da Kayan Kasuwa', 'inventory-control', 'Tracking your stock and avoiding dead inventory', 'package', 3),
(UUID(), 'Islamic Financial Ethics', 'Ka''idojin Kasuwanci na Musulunci', 'islamic-finance-ethics', 'Principles of halal commerce, contracts, and partnerships', 'shield-check', 4),
(UUID(), 'Business Growth & Marketing', 'Bunkasa Kasuwanci da Tallatawa', 'business-growth', 'Practical ways to attract and retain profitable customers', 'trending-up', 5);

-- 4. SAMPLE EDUCATIONAL ARTICLES
INSERT IGNORE INTO learning_articles (id, category_id, title, title_ha, slug, content, content_ha, excerpt, excerpt_ha, read_time_minutes, status)
SELECT 
    UUID(),
    id,
    'Why Separating Business and Personal Money Saves Your Store',
    'Dalilin da Ya Sa Ware Kudin Kasuwanci da na Gida ke Tsira da Shagonka',
    'separating-business-and-personal-money',
    'Many small businesses face cash flow problems not because they lack sales, but because shop proceeds are spent directly on personal and family expenses without recording. By paying yourself a fixed monthly or weekly stipend from your profit, your business cash reserves remain intact to restock goods at wholesale rates.',
    'Mafi yawan ''yan kasuwa suna fuskantar matsalar rashin kudi ba wai don ba a ciniki ba, a''a saboda ana cire kudin gida da bukatun yau da kullum kai tsaye daga aljihun shago ba tare da rubutawa ba. Idan ka ware wa kanka albashi ko kudin cefane daga riba, jarin shagonka zai ci gaba da tsayawa daram don siyo kaya.',
    'Learn how commingling personal and business funds drains SME liquidity and how to stop it.',
    'Koyi yadda hada kudin aljihu da na shago ke karya jari da hanyoyin magance hakan.',
    4,
    'published'
FROM learning_categories WHERE slug = 'cash-flow-budgeting' LIMIT 1;

INSERT IGNORE INTO learning_articles (id, category_id, title, title_ha, slug, content, content_ha, excerpt, excerpt_ha, read_time_minutes, status)
SELECT 
    UUID(),
    id,
    'Understanding Murabaha: Cost-Plus Financing for Equipment & Goods',
    'Fahimtar Murabaha: Tsarin Sayen Kayan Kasuwanci da Riba Sananniya',
    'understanding-murabaha-financing',
    'Murabaha is an Islamic financing structure where the financier buys an asset (such as store inventory, delivery tricycle, or machinery) and sells it to the business owner at cost plus an agreed-upon transparent markup, payable in flexible instalments without compounding interest.',
    'Murabaha wani tsari ne na kudi na Musulunci inda banki ko mai ba da kudi zai sayi kayan aiki (kamar babur din kaya, ko kayan shago) sannan ya sayar maka da shi tare da ribar da aka amince a kai a fili, kana biya a hankali ba tare da kudin ruwa ba.',
    'A plain-English and Hausa guide to asset financing without riba or hidden surprises.',
    'Bayanin yadda ake samun kayan aiki ba tare da kudin ruwa ko yaudara ba.',
    5,
    'published'
FROM learning_categories WHERE slug = 'islamic-finance-ethics' LIMIT 1;

-- 5. PARTNER INSTITUTIONS (Verified and Demonstration Profiles)
INSERT IGNORE INTO partner_institutions (id, name, type, description, website, contact_email, contact_phone, status) VALUES
(UUID(), 'Jaiz Bank Plc', 'Non-Interest Commercial Bank', 'Pioneer non-interest commercial bank in Nigeria providing Shariah-compliant retail and SME financing.', 'https://jaizbankplc.com', 'customercare@jaizbankplc.com', '+234 708 063 5555', 'active'),
(UUID(), 'TAJBank Limited', 'Non-Interest Bank', 'Specialized non-interest bank offering SME working capital and asset acquisition products across Northern Nigeria.', 'https://tajbank.com', 'contact@tajbank.com', '+234 818 888 8252', 'active'),
(UUID(), 'Lotus Bank', 'Non-Interest Bank', 'Full-service non-interest bank dedicated to ethical banking and supporting market traders and entrepreneurs.', 'https://lotusbank.com', 'support@lotusbank.com', '+234 700 56887 2265', 'active');

-- 6. FINANCING PRODUCTS (Educational Discovery Listings)
INSERT IGNORE INTO financing_products (id, partner_id, provider, type, name, description, eligibility, application_process, terms_and_fees, contact_info, application_link, is_verified, is_demo, status)
SELECT
    UUID(),
    p.id,
    p.name,
    'Murabaha',
    'SME Working Capital & Inventory Facility',
    'Structured cost-plus arrangement for bulk inventory procurement. The bank purchases trade goods directly from verified distributors and delivers to your business premises.',
    'Registered or verifiable enterprise operating for at least 12 months with clean bank statement or Kaanti transaction records.',
    'Submit business details, 6 months transaction history, proforma invoice from verified commodity supplier.',
    'Agreed profit margin disclosed upfront. No hidden compounding penalty fees.',
    p.contact_email,
    p.website,
    TRUE,
    FALSE,
    'active'
FROM partner_institutions p WHERE p.name = 'Jaiz Bank Plc' LIMIT 1;

INSERT IGNORE INTO financing_products (id, partner_id, provider, type, name, description, eligibility, application_process, terms_and_fees, contact_info, application_link, is_verified, is_demo, status)
SELECT
    UUID(),
    p.id,
    p.name,
    'Ijarah',
    'Commercial Machinery & Vehicle Lease-to-Own',
    'Equipment lease contract allowing traders and agro-processors to acquire processing units or distribution delivery vans with gradual ownership transfer.',
    'Active business with verifiable turnover and appropriate business location.',
    'Application with quote for machinery/vehicle, registration documents, and personal guarantor.',
    'Fixed monthly rental payments; asset ownership transferred at lease conclusion for a nominal fee.',
    p.contact_email,
    p.website,
    TRUE,
    FALSE,
    'active'
FROM partner_institutions p WHERE p.name = 'TAJBank Limited' LIMIT 1;

-- 7. INVESTMENT DISCOVERY PRODUCTS (Informational Only)
INSERT IGNORE INTO investment_products (id, provider, type, name, description, risk_disclosure, fees, provider_link, is_verified, is_demo, status) VALUES
(UUID(), 'Federal Government of Nigeria (DMO)', 'Sukuk', 'FGN Sovereign Ijarah Sukuk', 'Sovereign asset-backed rental bond issued by the Debt Management Office to fund national road and bridge infrastructure. Offers semi-annual rental distributions backed by the sovereign credit of Nigeria.', 'Low to moderate sovereign credit risk. Capital is tied down until bond maturity (typically 7-10 years), but tradable on NGX/FMDQ secondary markets.', 'Brokered via authorized issuing houses with standard statutory SEC/NGX transaction charges.', 'https://dmo.gov.ng', TRUE, FALSE, 'active'),
(UUID(), 'Marble Capital', 'Islamic Fund', 'Marble Halal Fixed Income Fund', 'SEC-registered collective investment scheme that pools capital to invest exclusively in Shariah-compliant short-to-medium term instruments including corporate Sukuk and bank Murabaha placements.', 'Moderate market risk; returns depend on underlying asset performance. Not covered by NDIC insurance.', '1.5% annual management fee deducted from fund NAV.', 'https://marblecapital.ng', TRUE, FALSE, 'active');
