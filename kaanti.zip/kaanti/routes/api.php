<?php
/**
 * API Routes
 *
 * REST / JSON endpoint definitions.
 */

// Headers for JSON API responses
header('Content-Type: application/json; charset=UTF-8');

/** @var \App\Core\Router $router */
// API endpoints will be registered here as needed
