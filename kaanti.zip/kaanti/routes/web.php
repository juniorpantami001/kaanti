<?php
/**
 * Web Routes
 *
 * All application web routes registered here.
 */

use App\Middleware\AuthMiddleware;
use App\Middleware\GuestMiddleware;
use App\Middleware\BusinessMiddleware;
use App\Middleware\AdminMiddleware;

/** @var \App\Core\Router $router */

// ── Public / Guest Routes ──────────────────────────────────────────
$router->get('/', 'Auth\\Controllers\\AuthController@index');

$router->get('/login', 'Auth\\Controllers\\AuthController@showLogin', [GuestMiddleware::class]);
$router->post('/login', 'Auth\\Controllers\\AuthController@login', [GuestMiddleware::class]);

$router->get('/register', 'Auth\\Controllers\\AuthController@showRegister', [GuestMiddleware::class]);
$router->post('/register', 'Auth\\Controllers\\AuthController@register', [GuestMiddleware::class]);

$router->get('/forgot-password', 'Auth\\Controllers\\AuthController@showForgotPassword', [GuestMiddleware::class]);
$router->post('/forgot-password', 'Auth\\Controllers\\AuthController@forgotPassword', [GuestMiddleware::class]);

$router->get('/reset-password/{token}', 'Auth\\Controllers\\AuthController@showResetPassword', [GuestMiddleware::class]);
$router->post('/reset-password', 'Auth\\Controllers\\AuthController@resetPassword', [GuestMiddleware::class]);

// Logout
$router->post('/logout', 'Auth\\Controllers\\AuthController@logout');
$router->get('/logout', 'Auth\\Controllers\\AuthController@logout');

// ── Authenticated Routes (Require Login) ───────────────────────────
$router->get('/onboarding', 'Business\\Controllers\\BusinessController@showOnboarding', [AuthMiddleware::class]);
$router->post('/onboarding', 'Business\\Controllers\\BusinessController@createBusiness', [AuthMiddleware::class]);

// Subscription routes (billing remains accessible when business access is restricted)
$router->get('/subscription', 'Subscription\\Controllers\\SubscriptionController@index', [AuthMiddleware::class]);
$router->post('/subscription/checkout', 'Subscription\\Controllers\\SubscriptionController@checkout', [AuthMiddleware::class]);
$router->get('/subscription/callback', 'Subscription\\Controllers\\SubscriptionController@callback');
$router->post('/paystack/webhook', 'Subscription\\Controllers\\SubscriptionController@webhook');

// ── Business Scope Protected Routes (Require Login & Active Business) ─
$protectedMiddlewares = [AuthMiddleware::class, BusinessMiddleware::class];

// 1. Dashboard
$router->get('/dashboard', 'Dashboard\\Controllers\\DashboardController@index', $protectedMiddlewares);

// 2. Transactions & Inflows / Outflows
$router->get('/transactions', 'Transactions\\Controllers\\TransactionController@index', $protectedMiddlewares);
$router->get('/transactions/{id}', 'Transactions\\Controllers\\TransactionController@show', $protectedMiddlewares);
$router->post('/transactions/{id}/void', 'Transactions\\Controllers\\TransactionController@void', $protectedMiddlewares);

$router->get('/income', 'Transactions\\Controllers\\TransactionController@index', $protectedMiddlewares);
$router->get('/income/create', 'Income\\Controllers\\IncomeController@create', $protectedMiddlewares);
$router->post('/income', 'Income\\Controllers\\IncomeController@store', $protectedMiddlewares);

$router->get('/expenses', 'Transactions\\Controllers\\TransactionController@index', $protectedMiddlewares);
$router->get('/expenses/create', 'Expenses\\Controllers\\ExpenseController@create', $protectedMiddlewares);
$router->post('/expenses', 'Expenses\\Controllers\\ExpenseController@store', $protectedMiddlewares);

// 3. Inventory Management
$router->get('/inventory', 'Inventory\\Controllers\\InventoryController@index', $protectedMiddlewares);
$router->get('/sales', 'Sales\\Controllers\\SaleController@index', $protectedMiddlewares);
$router->get('/sales/create', 'Sales\\Controllers\\SaleController@create', $protectedMiddlewares);
$router->post('/sales', 'Sales\\Controllers\\SaleController@store', $protectedMiddlewares);
$router->get('/inventory/create', 'Inventory\\Controllers\\InventoryController@create', $protectedMiddlewares);
$router->post('/inventory', 'Inventory\\Controllers\\InventoryController@store', $protectedMiddlewares);
$router->get('/inventory/{id}', 'Inventory\\Controllers\\InventoryController@show', $protectedMiddlewares);
$router->get('/inventory/{id}/edit', 'Inventory\\Controllers\\InventoryController@edit', $protectedMiddlewares);
$router->post('/inventory/{id}/edit', 'Inventory\\Controllers\\InventoryController@update', $protectedMiddlewares);
$router->post('/inventory/{id}/adjust', 'Inventory\\Controllers\\InventoryController@adjustStock', $protectedMiddlewares);
$router->post('/inventory/{id}/archive', 'Inventory\\Controllers\\InventoryController@archive', $protectedMiddlewares);

// 4. Customer Management
$router->get('/customers', 'Customers\\Controllers\\CustomerController@index', $protectedMiddlewares);
$router->get('/customers/create', 'Customers\\Controllers\\CustomerController@create', $protectedMiddlewares);
$router->post('/customers', 'Customers\\Controllers\\CustomerController@store', $protectedMiddlewares);
$router->get('/customers/{id}', 'Customers\\Controllers\\CustomerController@show', $protectedMiddlewares);
$router->get('/customers/{id}/edit', 'Customers\\Controllers\\CustomerController@edit', $protectedMiddlewares);
$router->post('/customers/{id}/edit', 'Customers\\Controllers\\CustomerController@update', $protectedMiddlewares);

// 5. Financial Reports & Statements
$router->get('/reports', 'Reports\\Controllers\\ReportController@index', $protectedMiddlewares);
$router->get('/reports/download', 'Reports\\Controllers\\ReportController@downloadPdf', $protectedMiddlewares);

// 6. Growth & Discovery: Financing & Ethical Investments
$router->get('/financing', 'Financing\\Controllers\\FinancingController@index', $protectedMiddlewares);
$router->get('/financing/{id}', 'Financing\\Controllers\\FinancingController@show', $protectedMiddlewares);

$router->get('/investments', 'Investments\\Controllers\\InvestmentController@index', $protectedMiddlewares);

// 7. Kaanti Learn (Bilingual Education)
$router->get('/learning', 'Learning\\Controllers\\LearningController@index', $protectedMiddlewares);
$router->get('/learning/{slug}', 'Learning\\Controllers\\LearningController@show', $protectedMiddlewares);

// ── Super Administration (Guarded by AdminMiddleware) ─────────────
$adminMiddlewares = [AuthMiddleware::class, AdminMiddleware::class];

$router->get('/admin', 'Admin\\Controllers\\AdminController@index', $adminMiddlewares);
$router->get('/admin/businesses', 'Admin\\Controllers\\AdminController@businesses', $adminMiddlewares);
$router->post('/admin/businesses/{id}/toggle', 'Admin\\Controllers\\AdminController@toggleBusinessStatus', $adminMiddlewares);
$router->get('/admin/users', 'Admin\\Controllers\\AdminController@users', $adminMiddlewares);
$router->get('/admin/audit', 'Admin\\Controllers\\AdminController@auditLogs', $adminMiddlewares);
