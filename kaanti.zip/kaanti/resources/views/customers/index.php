<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.5rem; color: var(--text-main); margin-bottom: 0.25rem;">
            Customer Directory
        </h1>
        <p class="text-sm text-muted">Manage your trade buyers, market clients, contacts, and purchase histories.</p>
    </div>

    <div style="display: flex; gap: 0.5rem;">
        <a href="<?= url('customers/create') ?>" class="btn btn-primary btn-sm">
            <i data-lucide="user-plus" style="width: 16px; height: 16px;"></i>
            <span>Add New Customer</span>
        </a>
    </div>
</div>

<!-- Search Form -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-body" style="padding: 1rem 1.25rem;">
        <form method="GET" action="<?= url('customers') ?>" style="display: flex; gap: 0.75rem;">
            <input 
                type="text" 
                name="search" 
                class="form-control" 
                value="<?= e($search ?? '') ?>" 
                placeholder="Search by customer name, trading name, phone, or email..."
            >
            <button type="submit" class="btn btn-primary">
                <i data-lucide="search" style="width: 16px; height: 16px;"></i>
                <span>Search</span>
            </button>
            <?php if (!empty($search)): ?>
                <a href="<?= url('customers') ?>" class="btn btn-secondary">Clear</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Customer Table -->
<div class="card">
    <?php if (empty($customers)): ?>
        <div class="empty-state">
            <div class="empty-state-icon">
                <i data-lucide="users" style="width: 32px; height: 32px;"></i>
            </div>
            <div class="empty-state-title">No customers found</div>
            <div class="empty-state-desc">Keep track of your frequent buyers, wholesalers, and market contacts in one secure directory.</div>
            <a href="<?= url('customers/create') ?>" class="btn btn-primary">
                <i data-lucide="user-plus" style="width: 16px; height: 16px;"></i>
                <span>Add Your First Customer</span>
            </a>
        </div>
    <?php else: ?>
        <div class="table-container" style="border: none;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Customer / Enterprise Name</th>
                        <th>Phone Number</th>
                        <th>Address / Market Location</th>
                        <th style="text-align: center;">Transactions</th>
                        <th style="text-align: right;">Total Spent</th>
                        <th style="text-align: center;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($customers as $c): ?>
                        <tr>
                            <td class="font-medium">
                                <a href="<?= url('customers/' . $c['id']) ?>" style="color: inherit; font-weight: 600;">
                                    <?= e($c['name']) ?>
                                </a>
                                <?php if (!empty($c['business_name'])): ?>
                                    <div class="text-xs text-muted">
                                        <?= e($c['business_name']) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($c['phone'])): ?>
                                    <a href="tel:<?= e($c['phone']) ?>" class="text-sm font-medium" style="color: var(--primary);">
                                        <?= e($c['phone']) ?>
                                    </a>
                                <?php else: ?>
                                    <span class="text-xs text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-sm text-secondary">
                                <?= e($c['address'] ?: '—') ?>
                            </td>
                            <td style="text-align: center; font-weight: 600;">
                                <?= number_format($c['total_transactions']) ?>
                            </td>
                            <td style="text-align: right; font-weight: 700; color: var(--primary);">
                                <?= format_naira($c['total_spent']) ?>
                            </td>
                            <td style="text-align: center;">
                                <div style="display: inline-flex; gap: 0.35rem;">
                                    <a href="<?= url('customers/' . $c['id']) ?>" class="btn btn-secondary btn-sm" style="padding: 0.25rem 0.5rem;" title="View history">
                                        <i data-lucide="eye" style="width: 14px; height: 14px;"></i>
                                    </a>
                                    <a href="<?= url('customers/' . $c['id'] . '/edit') ?>" class="btn btn-secondary btn-sm" style="padding: 0.25rem 0.5rem;" title="Edit details">
                                        <i data-lucide="edit-2" style="width: 14px; height: 14px;"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
