<div style="max-width: 680px; margin: 0 auto;">
    <div style="margin-bottom: 1.5rem;">
        <a href="<?= url('customers') ?>" class="text-sm text-muted" style="display: inline-flex; align-items: center; gap: 0.35rem; margin-bottom: 0.5rem;">
            <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
            <span>Back to customers</span>
        </a>
        <h1 style="font-size: 1.6rem; color: var(--text-main);">Add New Customer</h1>
        <p class="text-sm text-muted">Register a buyer to link future sales and maintain customer debt or payment logs.</p>
    </div>

    <div class="card">
        <div class="card-body" style="padding: 1.75rem;">
            <form action="<?= url('customers') ?>" method="POST" novalidate>
                <?= csrf_field() ?>

                <div class="form-row">
                    <div class="form-group">
                        <label for="name" class="form-label required">Contact / Individual Name</label>
                        <input 
                            type="text" 
                            name="name" 
                            id="name" 
                            class="form-control <?= has_error($errors, 'name') ? 'is-invalid' : '' ?>" 
                            value="<?= e(old('name')) ?>" 
                            placeholder="e.g. Alhaji Musa Garba" 
                            required 
                            autofocus
                        >
                        <?php foreach (field_errors($errors, 'name') as $err): ?>
                            <div class="form-error"><?= e($err) ?></div>
                        <?php endforeach; ?>
                    </div>

                    <div class="form-group">
                        <label for="business_name" class="form-label">Customer Company / Store Name</label>
                        <input 
                            type="text" 
                            name="business_name" 
                            id="business_name" 
                            class="form-control" 
                            value="<?= e(old('business_name')) ?>" 
                            placeholder="e.g. Garba General Enterprises"
                        >
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="phone" class="form-label">Phone Number</label>
                        <input 
                            type="tel" 
                            name="phone" 
                            id="phone" 
                            class="form-control <?= has_error($errors, 'phone') ? 'is-invalid' : '' ?>" 
                            value="<?= e(old('phone')) ?>" 
                            placeholder="08031234567"
                        >
                        <?php foreach (field_errors($errors, 'phone') as $err): ?>
                            <div class="form-error"><?= e($err) ?></div>
                        <?php endforeach; ?>
                    </div>

                    <div class="form-group">
                        <label for="email" class="form-label">Email Address</label>
                        <input 
                            type="email" 
                            name="email" 
                            id="email" 
                            class="form-control <?= has_error($errors, 'email') ? 'is-invalid' : '' ?>" 
                            value="<?= e(old('email')) ?>" 
                            placeholder="customer@example.com"
                        >
                        <?php foreach (field_errors($errors, 'email') as $err): ?>
                            <div class="form-error"><?= e($err) ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="address" class="form-label">Location / Market Stall Address</label>
                    <input 
                        type="text" 
                        name="address" 
                        id="address" 
                        class="form-control" 
                        value="<?= e(old('address')) ?>" 
                        placeholder="e.g. Shop B12, Singa Market, Kano"
                    >
                </div>

                <div class="form-group">
                    <label for="notes" class="form-label">Notes</label>
                    <textarea name="notes" id="notes" class="form-control" rows="2" placeholder="e.g. Prefers bank transfer, wholesale buyer of grains"><?= e(old('notes')) ?></textarea>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1.5rem;">
                    <a href="<?= url('customers') ?>" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i data-lucide="user-check" style="width: 18px; height: 18px;"></i>
                        <span>Save Customer</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
