<div style="max-width: 900px; margin: 0 auto;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.75rem;">
        <a href="<?= url('customers') ?>" class="text-sm text-muted" style="display: inline-flex; align-items: center; gap: 0.35rem;">
            <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
            <span>Back to customer directory</span>
        </a>

        <div style="display: flex; gap: 0.5rem;">
            <a href="<?= url('customers/' . $customer['id'] . '/edit') ?>" class="btn btn-secondary btn-sm">
                <i data-lucide="edit-2" style="width: 15px; height: 15px;"></i>
                <span>Edit Profile</span>
            </a>
            <a href="<?= url('income/create') ?>?customer_id=<?= urlencode($customer['id']) ?>" class="btn btn-primary btn-sm">
                <i data-lucide="plus-circle" style="width: 15px; height: 15px;"></i>
                <span>Record New Sale</span>
            </a>
        </div>
    </div>

    <!-- Customer Profile Card -->
    <div class="card" style="margin-bottom: 1.5rem;">
        <div class="card-header" style="background: var(--surface-alt);">
            <div>
                <span class="text-xs text-muted uppercase font-semibold">Customer Account Profile</span>
                <h1 style="font-size: 1.5rem; color: var(--text-main); margin-top: 0.15rem;">
                    <?= e($customer['name']) ?>
                </h1>
                <?php if (!empty($customer['business_name'])): ?>
                    <div class="text-sm font-semibold" style="color: var(--primary);">
                        <?= e($customer['business_name']) ?>
                    </div>
                <?php endif; ?>
            </div>

            <div style="text-align: right;">
                <div class="text-xs text-muted uppercase font-semibold">Total Lifetime Purchases</div>
                <div style="font-size: 1.5rem; font-weight: 800; color: var(--primary);">
                    <?= format_naira($customer['total_spent']) ?>
                </div>
            </div>
        </div>

        <div class="card-body" style="padding: 1.5rem;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.25rem; font-size: 0.92rem;">
                <div>
                    <span class="text-xs text-muted block uppercase">Phone Number</span>
                    <?php if (!empty($customer['phone'])): ?>
                        <a href="tel:<?= e($customer['phone']) ?>" class="font-bold text-primary">
                            <?= e($customer['phone']) ?>
                        </a>
                    <?php else: ?>
                        <span class="text-muted">Not provided</span>
                    <?php endif; ?>
                </div>

                <div>
                    <span class="text-xs text-muted block uppercase">Email Address</span>
                    <?php if (!empty($customer['email'])): ?>
                        <a href="mailto:<?= e($customer['email']) ?>" class="font-medium text-main">
                            <?= e($customer['email']) ?>
                        </a>
                    <?php else: ?>
                        <span class="text-muted">Not provided</span>
                    <?php endif; ?>
                </div>

                <div>
                    <span class="text-xs text-muted block uppercase">Total Transactions</span>
                    <strong class="text-main"><?= number_format($customer['total_transactions']) ?> orders</strong>
                </div>

                <div>
                    <span class="text-xs text-muted block uppercase">Client Since</span>
                    <strong class="text-main"><?= format_date($customer['created_at']) ?></strong>
                </div>

                <?php if (!empty($customer['address'])): ?>
                    <div style="grid-column: span 2;">
                        <span class="text-xs text-muted block uppercase">Physical Location / Stall</span>
                        <div class="text-main font-medium"><?= e($customer['address']) ?></div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($customer['notes'])): ?>
                    <div style="grid-column: span 2;">
                        <span class="text-xs text-muted block uppercase">Internal Notes</span>
                        <div style="background: var(--bg-app); padding: 0.6rem 0.85rem; border-radius: var(--radius-sm); color: var(--text-secondary); margin-top: 0.25rem;">
                            <?= nl2br(e($customer['notes'])) ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Customer's Transaction History -->
    <div class="card">
        <div class="card-header">
            <div class="card-title" style="display: flex; align-items: center; gap: 0.5rem;">
                <i data-lucide="receipt" style="width: 18px; height: 18px; color: var(--primary);"></i>
                <span>Purchase & Payment History</span>
            </div>
            <a href="<?= url('income/create') ?>?customer_id=<?= urlencode($customer['id']) ?>" class="btn btn-primary btn-sm">
                <span>Record Sale</span>
            </a>
        </div>

        <?php if (empty($transactions)): ?>
            <div class="empty-state">
                <div class="empty-state-icon">
                    <i data-lucide="receipt" style="width: 28px; height: 28px;"></i>
                </div>
                <div class="empty-state-title">No transactions linked to this customer yet</div>
                <div class="empty-state-desc">When you record sales or invoice this customer, their transaction receipts will appear here automatically.</div>
            </div>
        <?php else: ?>
            <div class="table-container" style="border: none;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Ref #</th>
                            <th>Description</th>
                            <th>Payment Method</th>
                            <th>Status</th>
                            <th style="text-align: right;">Amount</th>
                            <th style="text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transactions as $tx): ?>
                            <tr>
                                <td class="text-sm text-muted">
                                    <?= format_date($tx['transaction_date']) ?>
                                </td>
                                <td>
                                    <code style="font-size: 0.75rem; background: var(--surface-alt); padding: 0.15rem 0.4rem; border-radius: var(--radius-sm);">
                                        <?= e($tx['reference_number']) ?>
                                    </code>
                                </td>
                                <td class="font-medium">
                                    <?= e($tx['description']) ?>
                                </td>
                                <td>
                                    <span class="text-xs"><?= e($tx['payment_method']) ?></span>
                                </td>
                                <td>
                                    <?php if ($tx['status'] === 'voided'): ?>
                                        <span class="badge badge-danger">Voided</span>
                                    <?php else: ?>
                                        <span class="badge badge-success">Active</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: right; font-weight: 700; color: <?= $tx['type'] === 'income' ? 'var(--primary)' : 'var(--danger)' ?>;">
                                    <?= format_naira($tx['amount']) ?>
                                </td>
                                <td style="text-align: center;">
                                    <a href="<?= url('transactions/' . $tx['id']) ?>" class="btn btn-secondary btn-sm" style="padding: 0.25rem 0.5rem;" title="View voucher">
                                        <i data-lucide="eye" style="width: 14px; height: 14px;"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
