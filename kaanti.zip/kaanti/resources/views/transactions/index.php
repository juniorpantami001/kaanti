<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.5rem; color: var(--text-main); margin-bottom: 0.25rem;">
            Transactions Ledger
        </h1>
        <p class="text-sm text-muted">Complete financial inflows and outflows with immutable audit trails.</p>
    </div>

    <div style="display: flex; gap: 0.6rem; flex-wrap: wrap;">
        <a href="<?= url('income/create') ?>" class="btn btn-primary btn-sm">
            <i data-lucide="plus-circle" style="width: 16px; height: 16px;"></i>
            <span>Record Income</span>
        </a>
        <a href="<?= url('expenses/create') ?>" class="btn btn-secondary btn-sm" style="color: var(--danger); border-color: rgba(220,38,38,0.3);">
            <i data-lucide="minus-circle" style="width: 16px; height: 16px;"></i>
            <span>Record Expense</span>
        </a>
    </div>
</div>

<!-- Filters Card -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-body" style="padding: 1rem 1.25rem;">
        <form method="GET" action="<?= url('transactions') ?>" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)) 80px; gap: 0.85rem; align-items: end;">
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label text-xs">Search Keywords</label>
                <input type="text" name="search" class="form-control" value="<?= e($filters['search'] ?? '') ?>" placeholder="Description, Ref...">
            </div>

            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label text-xs">Transaction Type</label>
                <select name="type" class="form-control">
                    <option value="">All Types</option>
                    <option value="income" <?= ($filters['type'] ?? '') === 'income' ? 'selected' : '' ?>>Income Only</option>
                    <option value="expense" <?= ($filters['type'] ?? '') === 'expense' ? 'selected' : '' ?>>Expense Only</option>
                </select>
            </div>

            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label text-xs">Start Date</label>
                <input type="date" name="start_date" class="form-control" value="<?= e($filters['start_date'] ?? '') ?>">
            </div>

            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label text-xs">End Date</label>
                <input type="date" name="end_date" class="form-control" value="<?= e($filters['end_date'] ?? '') ?>">
            </div>

            <div style="display: flex; gap: 0.35rem;">
                <button type="submit" class="btn btn-primary btn-block" title="Apply filter">
                    <i data-lucide="search" style="width: 16px; height: 16px;"></i>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Ledger Table -->
<div class="card">
    <?php if (empty($transactions)): ?>
        <div class="empty-state">
            <div class="empty-state-icon">
                <i data-lucide="arrow-left-right" style="width: 32px; height: 32px;"></i>
            </div>
            <div class="empty-state-title">No transactions match your query</div>
            <div class="empty-state-desc">Try clearing your filters or record a new transaction to begin building your financial history.</div>
            <a href="<?= url('income/create') ?>" class="btn btn-primary">
                <i data-lucide="plus-circle" style="width: 16px; height: 16px;"></i>
                <span>Record Income</span>
            </a>
        </div>
    <?php else: ?>
        <div class="table-container" style="border: none;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Ref #</th>
                        <th>Type</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Customer</th>
                        <th>Payment</th>
                        <th>Status</th>
                        <th style="text-align: right;">Amount</th>
                        <th style="text-align: center;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $t): ?>
                        <tr style="<?= $t['status'] === 'voided' ? 'opacity: 0.55; text-decoration: line-through;' : '' ?>">
                            <td class="text-sm text-muted">
                                <?= format_date($t['transaction_date']) ?>
                            </td>
                            <td>
                                <code style="font-size: 0.78rem; background: var(--surface-alt); padding: 0.15rem 0.4rem; border-radius: var(--radius-sm);">
                                    <?= e($t['reference_number'] ?: 'TXN') ?>
                                </code>
                            </td>
                            <td>
                                <span class="badge badge-<?= $t['type'] ?>">
                                    <?= e(ucfirst($t['type'])) ?>
                                </span>
                            </td>
                            <td class="font-medium">
                                <a href="<?= url('transactions/' . $t['id']) ?>" style="color: inherit;">
                                    <?= e($t['description']) ?>
                                </a>
                            </td>
                            <td>
                                <span class="text-xs text-muted">
                                    <?= e($t['category_name'] ?: 'General') ?>
                                </span>
                            </td>
                            <td>
                                <?php if (!empty($t['customer_name'])): ?>
                                    <a href="<?= url('customers/' . $t['customer_id']) ?>" class="text-xs font-medium text-primary">
                                        <?= e($t['customer_name']) ?>
                                    </a>
                                <?php else: ?>
                                    <span class="text-xs text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="text-xs">
                                    <?= e($t['payment_method']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($t['status'] === 'voided'): ?>
                                    <span class="badge badge-danger">Voided</span>
                                <?php else: ?>
                                    <span class="badge badge-success">Active</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: right; font-weight: 700; color: <?= $t['type'] === 'income' ? 'var(--primary)' : 'var(--danger)' ?>;">
                                <?= $t['type'] === 'income' ? '+' : '-' ?><?= format_naira($t['amount']) ?>
                            </td>
                            <td style="text-align: center;">
                                <a href="<?= url('transactions/' . $t['id']) ?>" class="btn btn-secondary btn-sm" style="padding: 0.25rem 0.55rem;" title="View details voucher">
                                    <i data-lucide="eye" style="width: 14px; height: 14px;"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
