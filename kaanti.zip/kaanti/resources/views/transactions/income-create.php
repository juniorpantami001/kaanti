<div style="max-width: 680px; margin: 0 auto;">
    <div style="margin-bottom: 1.5rem;">
        <a href="<?= url('transactions') ?>" class="text-sm text-muted" style="display: inline-flex; align-items: center; gap: 0.35rem; margin-bottom: 0.5rem;">
            <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
            <span>Back to transactions</span>
        </a>
        <h1 style="font-size: 1.6rem; color: var(--text-main);">Record Business Income</h1>
        <p class="text-sm text-muted">Log cash inflows, direct sales, client service fees, or trade revenue.</p>
    </div>

    <div class="card">
        <div class="card-body" style="padding: 1.75rem;">
            <form action="<?= url('income') ?>" method="POST" novalidate>
                <?= csrf_field() ?>

                <div class="form-row">
                    <div class="form-group">
                        <label for="amount" class="form-label required">Amount Received (₦)</label>
                        <input 
                            type="number" 
                            step="0.01" 
                            name="amount" 
                            id="amount" 
                            class="form-control <?= has_error($errors, 'amount') ? 'is-invalid' : '' ?>" 
                            value="<?= e(old('amount')) ?>" 
                            placeholder="0.00" 
                            required 
                            autofocus
                        >
                        <?php foreach (field_errors($errors, 'amount') as $err): ?>
                            <div class="form-error"><?= e($err) ?></div>
                        <?php endforeach; ?>
                    </div>

                    <div class="form-group">
                        <label for="transaction_date" class="form-label required">Date of Inflow</label>
                        <input 
                            type="date" 
                            name="transaction_date" 
                            id="transaction_date" 
                            class="form-control <?= has_error($errors, 'transaction_date') ? 'is-invalid' : '' ?>" 
                            value="<?= e(old('transaction_date', date('Y-m-d'))) ?>" 
                            required
                        >
                        <?php foreach (field_errors($errors, 'transaction_date') as $err): ?>
                            <div class="form-error"><?= e($err) ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description" class="form-label required">Description / Narration</label>
                    <input 
                        type="text" 
                        name="description" 
                        id="description" 
                        class="form-control <?= has_error($errors, 'description') ? 'is-invalid' : '' ?>" 
                        value="<?= e(old('description')) ?>" 
                        placeholder="e.g. Sale of 5 bags of rice / Textile delivery" 
                        required
                    >
                    <?php foreach (field_errors($errors, 'description') as $err): ?>
                        <div class="form-error"><?= e($err) ?></div>
                    <?php endforeach; ?>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="category_name" class="form-label required">Income Category</label>
                        <select name="category_name" id="category_name" class="form-control" required>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= e($cat['name']) ?>" <?= old('category_name') === $cat['name'] ? 'selected' : '' ?>>
                                    <?= e($cat['name']) ?>
                                </option>
                            <?php endforeach; ?>
                            <option value="Direct Sales">Direct Sales</option>
                            <option value="Service Fee">Service Fee</option>
                            <option value="Other Inflow">Other Inflow</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="payment_method" class="form-label required">Payment Method</label>
                        <select name="payment_method" id="payment_method" class="form-control" required>
                            <option value="Cash" <?= old('payment_method') === 'Cash' ? 'selected' : '' ?>>Cash (Kudi a hannu)</option>
                            <option value="Bank Transfer" <?= old('payment_method') === 'Bank Transfer' ? 'selected' : '' ?>>Bank Transfer</option>
                            <option value="POS" <?= old('payment_method') === 'POS' ? 'selected' : '' ?>>POS Terminal</option>
                            <option value="Mobile Money" <?= old('payment_method') === 'Mobile Money' ? 'selected' : '' ?>>Mobile Money / OPay / PalmPay</option>
                            <option value="Cheque" <?= old('payment_method') === 'Cheque' ? 'selected' : '' ?>>Cheque</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="customer_id" class="form-label">Link to Customer (Optional)</label>
                    <select name="customer_id" id="customer_id" class="form-control">
                        <option value="">— Walk-in Anonymous Customer —</option>
                        <?php foreach ($customers as $c): ?>
                            <option value="<?= e($c['id']) ?>" <?= old('customer_id') === $c['id'] ? 'selected' : '' ?>>
                                <?= e($c['name']) ?> <?= !empty($c['phone']) ? '(' . e($c['phone']) . ')' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">Linking automatically updates the customer's total spending history.</div>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1.5rem;">
                    <a href="<?= url('transactions') ?>" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i data-lucide="check-circle" style="width: 18px; height: 18px;"></i>
                        <span>Save Income Entry</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
