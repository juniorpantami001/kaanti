<div style="max-width: 720px; margin: 0 auto;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.75rem;">
        <a href="<?= url('transactions') ?>" class="text-sm text-muted" style="display: inline-flex; align-items: center; gap: 0.35rem;">
            <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
            <span>Back to transactions</span>
        </a>

        <div style="display: flex; gap: 0.5rem;">
            <button type="button" onclick="window.print()" class="btn btn-secondary btn-sm">
                <i data-lucide="printer" style="width: 15px; height: 15px;"></i>
                <span>Print Voucher</span>
            </button>
            <?php if ($transaction['status'] === 'active'): ?>
                <button type="button" onclick="openModal('voidTxModal')" class="btn btn-danger btn-sm">
                    <i data-lucide="x-circle" style="width: 15px; height: 15px;"></i>
                    <span>Void Transaction</span>
                </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Official Transaction Voucher Card -->
    <div class="card" style="border: 2px solid var(--border);">
        <div class="card-header" style="background-color: var(--surface-alt); padding: 1.25rem 1.75rem;">
            <div>
                <div class="text-xs uppercase font-semibold text-muted" style="letter-spacing: 0.06em;">Official Transaction Receipt Voucher</div>
                <div class="text-lg font-bold" style="color: var(--text-main); margin-top: 0.15rem;">
                    <?= e($transaction['reference_number']) ?>
                </div>
            </div>
            <div>
                <?php if ($transaction['status'] === 'voided'): ?>
                    <span class="badge badge-danger" style="font-size: 0.85rem; padding: 0.35rem 0.8rem;">
                        <i data-lucide="alert-octagon" style="width: 14px; height: 14px;"></i>
                        <span>VOIDED / REVERSED</span>
                    </span>
                <?php else: ?>
                    <span class="badge badge-success" style="font-size: 0.85rem; padding: 0.35rem 0.8rem;">
                        <i data-lucide="check" style="width: 14px; height: 14px;"></i>
                        <span>ACTIVE RECORD</span>
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-body" style="padding: 1.75rem;">
            <!-- Amount Callout -->
            <div style="text-align: center; padding: 1.5rem 0; border-bottom: 1px dashed var(--border); margin-bottom: 1.5rem;">
                <div class="text-xs text-muted uppercase font-semibold">Total Amount Recorded</div>
                <div style="font-size: 2.4rem; font-weight: 800; color: <?= $transaction['type'] === 'income' ? 'var(--primary)' : 'var(--danger)' ?>; margin-top: 0.25rem;">
                    <?= $transaction['type'] === 'income' ? '+' : '-' ?><?= format_naira($transaction['amount']) ?>
                </div>
                <div class="text-sm font-medium" style="color: var(--text-secondary); margin-top: 0.25rem;">
                    <?= e(ucfirst($transaction['type'])) ?> Transaction
                </div>
            </div>

            <!-- Details Grid -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.25rem; font-size: 0.92rem;">
                <div>
                    <span class="text-xs text-muted block uppercase">Transaction Date</span>
                    <strong class="text-main"><?= format_date($transaction['transaction_date'], 'l, j F Y') ?></strong>
                </div>

                <div>
                    <span class="text-xs text-muted block uppercase">Category</span>
                    <strong class="text-main"><?= e($transaction['category_name'] ?: 'General') ?></strong>
                </div>

                <div>
                    <span class="text-xs text-muted block uppercase">Payment Method</span>
                    <strong class="text-main"><?= e($transaction['payment_method']) ?></strong>
                </div>

                <div>
                    <span class="text-xs text-muted block uppercase">Associated Customer</span>
                    <?php if (!empty($transaction['customer_name'])): ?>
                        <a href="<?= url('customers/' . $transaction['customer_id']) ?>" class="font-bold text-primary">
                            <?= e($transaction['customer_name']) ?>
                        </a>
                    <?php else: ?>
                        <span class="text-muted">Unlinked / Walk-in</span>
                    <?php endif; ?>
                </div>

                <div style="grid-column: span 2;">
                    <span class="text-xs text-muted block uppercase">Description / Narration</span>
                    <div style="background: var(--surface-alt); padding: 0.75rem 1rem; border-radius: var(--radius-sm); margin-top: 0.35rem; font-weight: 500;">
                        <?= e($transaction['description']) ?>
                    </div>
                </div>

                <div>
                    <span class="text-xs text-muted block uppercase">Recorded By</span>
                    <span class="text-sm"><?= e(trim(($transaction['first_name'] ?? '') . ' ' . ($transaction['last_name'] ?? '')) ?: 'System') ?></span>
                </div>

                <div>
                    <span class="text-xs text-muted block uppercase">System Timestamp</span>
                    <span class="text-sm text-muted"><?= e($transaction['created_at']) ?></span>
                </div>
            </div>

            <?php if (!empty($items)): ?>
                <div style="margin-top: 1.75rem;">
                    <div class="card-title" style="margin-bottom: 0.75rem;">Products in This Sale</div>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th style="text-align: right;">Qty</th>
                                    <th style="text-align: right;">Unit Price</th>
                                    <th style="text-align: right;">Line Total</th>
                                    <th style="text-align: right;">Gross Profit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($items as $item): ?>
                                    <tr>
                                        <td class="font-medium">
                                            <?= e($item['product_name']) ?>
                                            <?php if (!empty($item['sku'])): ?><div class="text-xs text-muted"><?= e($item['sku']) ?></div><?php endif; ?>
                                        </td>
                                        <td style="text-align: right;"><?= number_format((int) $item['quantity']) ?></td>
                                        <td style="text-align: right;"><?= format_naira($item['unit_price']) ?></td>
                                        <td style="text-align: right;"><?= format_naira($item['line_total']) ?></td>
                                        <td style="text-align: right; font-weight: 600;"><?= format_naira($item['line_profit']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="4" style="text-align: right;">Total Gross Profit</th>
                                    <th style="text-align: right;"><?= format_naira($grossProfit) ?></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <p class="text-xs text-muted" style="margin-top: 0.5rem;">
                        Profit uses the product cost recorded when the sale was made<?= $transaction['status'] === 'voided' ? ' and is excluded from active sales totals because this sale is voided' : '' ?>.
                    </p>
                </div>
            <?php endif; ?>

            <?php if ($transaction['status'] === 'voided'): ?>
                <div style="margin-top: 1.5rem; background: var(--danger-bg); border: 1px solid var(--danger-border); padding: 1rem 1.25rem; border-radius: var(--radius-md);">
                    <div style="display: flex; align-items: center; gap: 0.5rem; color: var(--danger); font-weight: 600; font-size: 0.9rem;">
                        <i data-lucide="alert-triangle" style="width: 18px; height: 18px;"></i>
                        <span>Audit Record: This transaction was voided</span>
                    </div>
                    <div class="text-sm" style="color: #991B1B; margin-top: 0.35rem;">
                        <strong>Reason:</strong> <?= e($transaction['voided_reason'] ?: 'No reason stated') ?><br>
                        <strong>Voided At:</strong> <?= e($transaction['voided_at']) ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Void Modal -->
<div id="voidTxModal" class="modal-overlay" style="display: none; position: fixed; inset: 0; background: rgba(15,23,42,0.6); z-index: 50; align-items: center; justify-content: center; padding: 1rem;">
    <div class="card" style="max-width: 480px; width: 100%; box-shadow: var(--shadow-lg);">
        <div class="card-header">
            <div class="card-title text-danger" style="display: flex; align-items: center; gap: 0.5rem;">
                <i data-lucide="alert-circle" style="width: 20px; height: 20px;"></i>
                <span>Void Transaction</span>
            </div>
            <button type="button" onclick="closeModal('voidTxModal')" style="background: none; border: none; cursor: pointer; color: var(--text-muted);">
                <i data-lucide="x" style="width: 18px; height: 18px;"></i>
            </button>
        </div>
        <div class="card-body">
            <p class="text-sm text-muted" style="margin-bottom: 1.25rem;">
                Voiding reverses this transaction's effect on cash flow and reports<?php if (!empty($items)): ?> and restores the sold stock<?php endif; ?>. The record remains in the audit log marked as voided.
            </p>
            <form action="<?= url('transactions/' . $transaction['id'] . '/void') ?>" method="POST">
                <?= csrf_field() ?>
                <div class="form-group">
                    <label for="void_reason" class="form-label required">Reason for voiding / reversal</label>
                    <textarea name="void_reason" id="void_reason" class="form-control" rows="3" placeholder="e.g. Customer returned goods / Duplicate entry logged" required></textarea>
                </div>
                <div style="display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1rem;">
                    <button type="button" onclick="closeModal('voidTxModal')" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-danger">Confirm Void</button>
                </div>
            </form>
        </div>
    </div>
</div>
