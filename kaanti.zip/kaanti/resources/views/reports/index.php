<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.5rem; color: var(--text-main); margin-bottom: 0.25rem;">
            Financial & Bookkeeping Reports
        </h1>
        <p class="text-sm text-muted">Periodic cash flow summaries, category breakdowns, and performance analytics.</p>
    </div>

    <div style="display: flex; gap: 0.5rem;">
        <a href="<?= url('reports/download') ?>?start_date=<?= urlencode($startDate) ?>&end_date=<?= urlencode($endDate) ?>" target="_blank" class="btn btn-secondary btn-sm">
            <i data-lucide="printer" style="width: 16px; height: 16px;"></i>
            <span>Print / PDF Export</span>
        </a>
    </div>
</div>

<!-- Notice Callout -->
<div class="alert alert-info" style="margin-bottom: 1.5rem;">
    <i data-lucide="info" style="width: 20px; height: 20px; flex-shrink: 0;"></i>
    <div class="text-xs">
        <strong>Management Bookkeeping Notice:</strong> These statements are compiled directly from internal business records for operational management and financial tracking. They do not constitute statutory audited financial statements.
    </div>
</div>

<!-- Date Range Filter -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-body" style="padding: 1.15rem 1.25rem;">
        <form method="GET" action="<?= url('reports') ?>" style="display: flex; align-items: end; gap: 1rem; flex-wrap: wrap;">
            <div class="form-group" style="margin-bottom: 0; min-width: 180px;">
                <label class="form-label text-xs">Start Date</label>
                <input type="date" name="start_date" class="form-control" value="<?= e($startDate) ?>" required>
            </div>

            <div class="form-group" style="margin-bottom: 0; min-width: 180px;">
                <label class="form-label text-xs">End Date</label>
                <input type="date" name="end_date" class="form-control" value="<?= e($endDate) ?>" required>
            </div>

            <button type="submit" class="btn btn-primary">
                <i data-lucide="calendar" style="width: 16px; height: 16px;"></i>
                <span>Generate Period Report</span>
            </button>
        </form>
    </div>
</div>

<!-- Financial Summary Cards -->
<div class="stats-grid">
    <div class="stat-card">
        <div>
            <div class="stat-title">Period Inflow (Income)</div>
            <div class="stat-value" style="color: var(--primary);">
                <?= format_naira($totalIncome) ?>
            </div>
            <div class="stat-subtext"><?= format_date($startDate) ?> to <?= format_date($endDate) ?></div>
        </div>
        <div class="stat-icon-box icon-box-green">
            <i data-lucide="trending-up" style="width: 22px; height: 22px;"></i>
        </div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-title">Period Outflow (Expenses)</div>
            <div class="stat-value" style="color: var(--danger);">
                <?= format_naira($totalExpenses) ?>
            </div>
            <div class="stat-subtext"><?= format_date($startDate) ?> to <?= format_date($endDate) ?></div>
        </div>
        <div class="stat-icon-box icon-box-red">
            <i data-lucide="trending-down" style="width: 22px; height: 22px;"></i>
        </div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-title">Net Operating Cash Flow</div>
            <div class="stat-value" style="color: <?= $netCashFlow >= 0 ? 'var(--primary-dark)' : 'var(--danger)' ?>;">
                <?= format_naira($netCashFlow) ?>
            </div>
            <div class="stat-subtext"><?= $netCashFlow >= 0 ? 'Operating Surplus' : 'Operating Deficit' ?></div>
        </div>
        <div class="stat-icon-box <?= $netCashFlow >= 0 ? 'icon-box-green' : 'icon-box-red' ?>">
            <i data-lucide="wallet" style="width: 22px; height: 22px;"></i>
        </div>
    </div>
</div>

<!-- Breakdowns Row -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
    <!-- Income Category Breakdown -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Income by Category</div>
        </div>
        <?php if (empty($incomeBreakdown)): ?>
            <div class="empty-state" style="padding: 2rem 1rem;">
                <p class="text-sm text-muted">No income recorded in this date range.</p>
            </div>
        <?php else: ?>
            <div class="table-container" style="border: none;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th style="text-align: center;">Entries</th>
                            <th style="text-align: right;">Total (₦)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($incomeBreakdown as $ib): ?>
                            <tr>
                                <td class="font-medium"><?= e($ib['category_name']) ?></td>
                                <td style="text-align: center;"><?= number_format($ib['count']) ?></td>
                                <td style="text-align: right; font-weight: 600; color: var(--primary);">
                                    <?= format_naira($ib['total']) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!-- Expense Category Breakdown -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Expenses by Category</div>
        </div>
        <?php if (empty($expenseBreakdown)): ?>
            <div class="empty-state" style="padding: 2rem 1rem;">
                <p class="text-sm text-muted">No expenses recorded in this date range.</p>
            </div>
        <?php else: ?>
            <div class="table-container" style="border: none;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th style="text-align: center;">Entries</th>
                            <th style="text-align: right;">Total (₦)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($expenseBreakdown as $eb): ?>
                            <tr>
                                <td class="font-medium"><?= e($eb['category_name']) ?></td>
                                <td style="text-align: center;"><?= number_format($eb['count']) ?></td>
                                <td style="text-align: right; font-weight: 600; color: var(--danger);">
                                    <?= format_naira($eb['total']) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Detailed Transactions Table -->
<div class="card">
    <div class="card-header">
        <div class="card-title">Statement Entries in Period (<?= count($transactions) ?>)</div>
    </div>
    <?php if (empty($transactions)): ?>
        <div class="empty-state">
            <p class="text-sm text-muted">No transactions found within the selected dates.</p>
        </div>
    <?php else: ?>
        <div class="table-container" style="border: none;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Ref #</th>
                        <th>Type</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Payment</th>
                        <th style="text-align: right;">Amount (₦)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($transactions as $t): ?>
                        <tr>
                            <td class="text-sm text-muted"><?= format_date($t['transaction_date']) ?></td>
                            <td><code><?= e($t['reference_number']) ?></code></td>
                            <td>
                                <span class="badge badge-<?= $t['type'] ?>">
                                    <?= ucfirst($t['type']) ?>
                                </span>
                            </td>
                            <td><?= e($t['description']) ?></td>
                            <td class="text-xs text-muted"><?= e($t['category_name']) ?></td>
                            <td class="text-xs"><?= e($t['payment_method']) ?></td>
                            <td style="text-align: right; font-weight: 600; color: <?= $t['type'] === 'income' ? 'var(--primary)' : 'var(--danger)' ?>;">
                                <?= $t['type'] === 'income' ? '+' : '-' ?><?= format_naira($t['amount']) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
