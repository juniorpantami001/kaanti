<div style="max-width: 800px; margin: 0 auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
    <!-- Statement Header -->
    <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #1B5E20; padding-bottom: 1.5rem; margin-bottom: 1.5rem;">
        <div style="display: flex; align-items: center; gap: 0.85rem;">
            <img src="<?= asset('images/logo.jpeg') ?>" alt="Kaanti" style="width: 50px; height: 50px; border-radius: 6px; object-fit: cover;">
            <div>
                <h1 style="font-size: 1.4rem; font-weight: 800; color: #1B5E20; margin: 0;">Kaanti Manager</h1>
                <div style="font-size: 0.75rem; color: #F9A825; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em;">Manage. Grow. Prosper.</div>
            </div>
        </div>

        <div style="text-align: right;">
            <div style="font-size: 1.25rem; font-weight: 800; color: #0F172A; text-transform: uppercase;">Financial Statement</div>
            <div style="font-size: 0.82rem; color: #64748B;">Generated: <?= date('F j, Y, g:i a') ?></div>
            <div style="font-size: 0.82rem; font-weight: 600; color: #2E7D32;">Enterprise: <?= e($businessName) ?></div>
        </div>
    </div>

    <!-- Statement Parameters -->
    <div style="background-color: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 1rem 1.25rem; margin-bottom: 1.5rem; display: flex; justify-content: space-between;">
        <div>
            <span style="font-size: 0.75rem; color: #64748B; text-transform: uppercase; display: block;">Reporting Period</span>
            <strong><?= format_date($startDate, 'F j, Y') ?> &mdash; <?= format_date($endDate, 'F j, Y') ?></strong>
        </div>
        <div>
            <span style="font-size: 0.75rem; color: #64748B; text-transform: uppercase; display: block;">Report Scope</span>
            <strong>Complete Cash Inflows & Outflows</strong>
        </div>
        <div>
            <span style="font-size: 0.75rem; color: #64748B; text-transform: uppercase; display: block;">Currency</span>
            <strong>Nigerian Naira (NGN / ₦)</strong>
        </div>
    </div>

    <!-- Net Cash Summary Box -->
    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem; text-align: center;">
        <div style="border: 1px solid #E2E8F0; border-radius: 8px; padding: 1rem; background: #ECFDF5;">
            <div style="font-size: 0.75rem; color: #065F46; font-weight: 600; text-transform: uppercase;">Total Income</div>
            <div style="font-size: 1.35rem; font-weight: 800; color: #059669; margin-top: 0.25rem;">
                <?= format_naira($totalIncome) ?>
            </div>
        </div>

        <div style="border: 1px solid #E2E8F0; border-radius: 8px; padding: 1rem; background: #FEF2F2;">
            <div style="font-size: 0.75rem; color: #991B1B; font-weight: 600; text-transform: uppercase;">Total Expenses</div>
            <div style="font-size: 1.35rem; font-weight: 800; color: #DC2626; margin-top: 0.25rem;">
                <?= format_naira($totalExpenses) ?>
            </div>
        </div>

        <div style="border: 1px solid #E2E8F0; border-radius: 8px; padding: 1rem; background: #FFFFFF;">
            <div style="font-size: 0.75rem; color: #64748B; font-weight: 600; text-transform: uppercase;">Net Operating Cash Flow</div>
            <div style="font-size: 1.35rem; font-weight: 800; color: <?= $netCashFlow >= 0 ? '#1B5E20' : '#DC2626' ?>; margin-top: 0.25rem;">
                <?= format_naira($netCashFlow) ?>
            </div>
        </div>
    </div>

    <!-- Transaction Table -->
    <table style="width: 100%; border-collapse: collapse; margin-bottom: 2rem; font-size: 0.82rem;">
        <thead>
            <tr style="background: #F1F5F9; border-bottom: 2px solid #CBD5E1;">
                <th style="padding: 0.6rem 0.75rem; text-align: left;">Date</th>
                <th style="padding: 0.6rem 0.75rem; text-align: left;">Ref #</th>
                <th style="padding: 0.6rem 0.75rem; text-align: left;">Type</th>
                <th style="padding: 0.6rem 0.75rem; text-align: left;">Description</th>
                <th style="padding: 0.6rem 0.75rem; text-align: left;">Category</th>
                <th style="padding: 0.6rem 0.75rem; text-align: right;">Amount (₦)</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($transactions)): ?>
                <tr>
                    <td colspan="6" style="padding: 2rem; text-align: center; color: #64748B;">No transactions logged during this period.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($transactions as $t): ?>
                    <tr style="border-bottom: 1px solid #E2E8F0;">
                        <td style="padding: 0.55rem 0.75rem; color: #475569;"><?= format_date($t['transaction_date']) ?></td>
                        <td style="padding: 0.55rem 0.75rem;"><code><?= e($t['reference_number']) ?></code></td>
                        <td style="padding: 0.55rem 0.75rem; font-weight: 600; color: <?= $t['type'] === 'income' ? '#059669' : '#DC2626' ?>;">
                            <?= ucfirst($t['type']) ?>
                        </td>
                        <td style="padding: 0.55rem 0.75rem;"><?= e($t['description']) ?></td>
                        <td style="padding: 0.55rem 0.75rem; color: #64748B;"><?= e($t['category_name']) ?></td>
                        <td style="padding: 0.55rem 0.75rem; text-align: right; font-weight: 700; color: <?= $t['type'] === 'income' ? '#059669' : '#DC2626' ?>;">
                            <?= $t['type'] === 'income' ? '+' : '-' ?><?= format_naira($t['amount']) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Bookkeeping Disclaimer Footnote -->
    <div style="border-top: 1px solid #E2E8F0; padding-top: 1rem; font-size: 0.75rem; color: #64748B; line-height: 1.5;">
        <strong>Statutory Notice:</strong> This document is generated for business bookkeeping, internal review, and operational decision-making purposes. It is not an audited statutory financial report certified by an external auditor. Kaanti Manager is a software platform and does not offer formal audit certification.
    </div>
</div>
