<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 Page Not Found — Kaanti Manager</title>
    <link rel="icon" type="image/jpeg" href="<?= asset('images/logo.jpeg') ?>">
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
</head>
<body style="display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 1.5rem; text-align: center;">
    <div class="card" style="max-width: 480px; width: 100%; padding: 3rem 2rem;">
        <div style="width: 72px; height: 72px; border-radius: 50%; background: var(--primary-subtle); color: var(--primary); display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem;">
            <i data-lucide="compass" style="width: 36px; height: 36px;"></i>
        </div>
        <h1 style="font-size: 2rem; margin-bottom: 0.5rem; color: var(--text-main);">404 &bull; Page Not Found</h1>
        <p class="text-muted" style="margin-bottom: 2rem;">
            The page or record you requested does not exist, has been moved, or belongs to another business tenant.
        </p>
        <div style="display: flex; justify-content: center; gap: 0.75rem;">
            <a href="<?= url('dashboard') ?>" class="btn btn-primary">
                <i data-lucide="home" style="width: 18px; height: 18px;"></i>
                <span>Return to Dashboard</span>
            </a>
            <a href="<?= url('login') ?>" class="btn btn-secondary">
                <span>Sign In</span>
            </a>
        </div>
    </div>
    <script>
        if (window.lucide) window.lucide.createIcons();
    </script>
</body>
</html>
