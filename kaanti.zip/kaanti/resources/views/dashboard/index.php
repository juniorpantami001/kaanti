<?php
/**
 * Kaanti Manager — Dashboard View
 * Displays verified tenant metrics, financial performance, and business summaries.
 */
?>

<!-- Welcome Banner -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.6rem; color: var(--text-main); margin-bottom: 0.25rem;">
            <?= e($businessName) ?>
        </h1>
        <p class="text-sm text-muted">
            Financial & Operations Overview &bull; All monetary figures verified from real records.
        </p>
    </div>

    <!-- Quick Action Shortcut Buttons -->
    <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
        <a href="<?= url('income/create') ?>" class="btn btn-primary btn-sm">
            <i data-lucide="plus-circle" style="width: 16px; height: 16px;"></i>
            <span>Record Income</span>
        </a>
        <a href="<?= url('sales/create') ?>" class="btn btn-primary btn-sm">
            <i data-lucide="shopping-cart" style="width: 16px; height: 16px;"></i>
            <span>New Sale</span>
        </a>
        <a href="<?= url('expenses/create') ?>" class="btn btn-secondary btn-sm" style="color: var(--danger); border-color: rgba(220,38,38,0.3);">
            <i data-lucide="minus-circle" style="width: 16px; height: 16px;"></i>
            <span>Record Expense</span>
        </a>
        <a href="<?= url('inventory/create') ?>" class="btn btn-secondary btn-sm">
            <i data-lucide="package-plus" style="width: 16px; height: 16px;"></i>
            <span>Add Product</span>
        </a>
        <a href="<?= url('reports') ?>" class="btn btn-secondary btn-sm">
            <i data-lucide="file-text" style="width: 16px; height: 16px;"></i>
            <span>Reports</span>
        </a>
    </div>
</div>

<!-- 1. Financial Overview KPI Cards -->
<div class="stats-grid">
    <!-- Total Income -->
    <div class="stat-card">
        <div>
            <div class="stat-title">Total Income</div>
            <div class="stat-value" style="color: var(--primary);">
                <?= format_naira($totalIncome) ?>
            </div>
            <div class="stat-subtext">All verified business inflows</div>
        </div>
        <div class="stat-icon-box icon-box-green">
            <i data-lucide="trending-up" style="width: 22px; height: 22px;"></i>
        </div>
    </div>

    <!-- Total Expenses -->
    <div class="stat-card">
        <div>
            <div class="stat-title">Total Expenses</div>
            <div class="stat-value" style="color: var(--danger);">
                <?= format_naira($totalExpenses) ?>
            </div>
            <div class="stat-subtext">Operational expenditures</div>
        </div>
        <div class="stat-icon-box icon-box-red">
            <i data-lucide="trending-down" style="width: 22px; height: 22px;"></i>
        </div>
    </div>

    <!-- Net Cash Flow -->
    <div class="stat-card">
        <div>
            <div class="stat-title">Net Cash Flow</div>
            <div class="stat-value" style="color: <?= $netCashFlow >= 0 ? 'var(--primary-dark)' : 'var(--danger)' ?>;">
                <?= format_naira($netCashFlow) ?>
            </div>
            <div class="stat-subtext">Net operating surplus / (deficit)</div>
        </div>
        <div class="stat-icon-box <?= $netCashFlow >= 0 ? 'icon-box-green' : 'icon-box-red' ?>">
            <i data-lucide="wallet" style="width: 22px; height: 22px;"></i>
        </div>
    </div>

    <!-- Transactions Count -->
    <div class="stat-card">
        <div>
            <div class="stat-title">Transactions</div>
            <div class="stat-value">
                <?= number_format($txCount) ?>
            </div>
            <div class="stat-subtext">Total active entries logged</div>
        </div>
        <div class="stat-icon-box icon-box-blue">
            <i data-lucide="arrow-left-right" style="width: 22px; height: 22px;"></i>
        </div>
    </div>
</div>

<!-- 2. Business Health Secondary Metrics -->
<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); margin-bottom: 1.5rem;">
    <div class="card" style="padding: 1rem 1.25rem; display: flex; align-items: center; gap: 1rem;">
        <div style="background: var(--surface-alt); padding: 0.6rem; border-radius: var(--radius-md); color: var(--text-main);">
            <i data-lucide="package" style="width: 22px; height: 22px;"></i>
        </div>
        <div>
            <div class="text-xs text-muted uppercase font-medium">Inventory Stock</div>
            <div class="text-lg font-bold"><?= number_format($totalProducts) ?> Products</div>
        </div>
    </div>

    <div class="card" style="padding: 1rem 1.25rem; display: flex; align-items: center; gap: 1rem;">
        <div style="background: var(--warning-bg); padding: 0.6rem; border-radius: var(--radius-md); color: var(--warning);">
            <i data-lucide="alert-triangle" style="width: 22px; height: 22px;"></i>
        </div>
        <div>
            <div class="text-xs text-muted uppercase font-medium">Low Stock Alert</div>
            <div class="text-lg font-bold" style="color: <?= $lowStockCount > 0 ? 'var(--warning)' : 'var(--text-main)' ?>;">
                <?= number_format($lowStockCount) ?> Items Reorder
            </div>
        </div>
    </div>

    <div class="card" style="padding: 1rem 1.25rem; display: flex; align-items: center; gap: 1rem;">
        <div style="background: var(--primary-subtle); padding: 0.6rem; border-radius: var(--radius-md); color: var(--primary);">
            <i data-lucide="users" style="width: 22px; height: 22px;"></i>
        </div>
        <div>
            <div class="text-xs text-muted uppercase font-medium">Registered Customers</div>
            <div class="text-lg font-bold"><?= number_format($totalCustomers) ?> Active</div>
        </div>
    </div>

    <a href="<?= url('sales') ?>" class="card" style="padding: 1rem 1.25rem; display: flex; align-items: center; gap: 1rem; color: inherit; text-decoration: none;">
        <div style="background: var(--primary-subtle); padding: 0.6rem; border-radius: var(--radius-md); color: var(--primary);">
            <i data-lucide="badge-dollar-sign" style="width: 22px; height: 22px;"></i>
        </div>
        <div>
            <div class="text-xs text-muted uppercase font-medium">Gross Sales Profit</div>
            <div class="text-lg font-bold"><?= format_naira($grossSalesProfit) ?></div>
        </div>
    </a>
</div>

<!-- 3. Financial Performance Charts -->
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.25rem; margin-bottom: 1.5rem;">
    <!-- Monthly Cash Flow -->
    <div class="card">
        <div class="card-header">
            <div class="card-title" style="display: flex; align-items: center; gap: 0.5rem;">
                <i data-lucide="bar-chart-2" style="width: 18px; height: 18px; color: var(--primary);"></i>
                <span>Monthly Cash Flow Performance</span>
            </div>
            <span class="text-xs text-muted">Last 6 months</span>
        </div>
        <div class="card-body">
            <div style="height: 260px; position: relative;">
                <canvas id="cashFlowChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Expense Category Breakdown -->
    <div class="card">
        <div class="card-header">
            <div class="card-title" style="display: flex; align-items: center; gap: 0.5rem;">
                <i data-lucide="pie-chart" style="width: 18px; height: 18px; color: var(--accent);"></i>
                <span>Expense Breakdown</span>
            </div>
            <span class="text-xs text-muted">By Category</span>
        </div>
        <div class="card-body">
            <div style="height: 260px; position: relative;">
                <canvas id="expenseChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- 4. Recent Transactions & Activity Table -->
<div class="card">
    <div class="card-header">
        <div class="card-title" style="display: flex; align-items: center; gap: 0.5rem;">
            <i data-lucide="receipt" style="width: 18px; height: 18px; color: var(--primary);"></i>
            <span>Recent Transactions</span>
        </div>
        <a href="<?= url('transactions') ?>" class="text-xs text-primary font-semibold hover:underline">
            View All Transactions &rarr;
        </a>
    </div>

    <?php if (empty($recentTransactions)): ?>
        <!-- Empty State for Fresh Business -->
        <div class="empty-state">
            <div class="empty-state-icon">
                <i data-lucide="receipt" style="width: 30px; height: 30px;"></i>
            </div>
            <div class="empty-state-title">No transactions recorded yet</div>
            <div class="empty-state-desc">
                Your business is freshly launched. Start by logging your first daily sales, stock purchase, or operational expense.
            </div>
            <div style="display: flex; justify-content: center; gap: 0.75rem;">
                <a href="<?= url('income/create') ?>" class="btn btn-primary">
                    <i data-lucide="plus-circle" style="width: 16px; height: 16px;"></i>
                    <span>Record First Income</span>
                </a>
                <a href="<?= url('expenses/create') ?>" class="btn btn-secondary">
                    <i data-lucide="minus-circle" style="width: 16px; height: 16px;"></i>
                    <span>Record First Expense</span>
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="table-container" style="border: none;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Payment Method</th>
                        <th style="text-align: right;">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentTransactions as $tx): ?>
                        <tr>
                            <td class="text-sm text-muted">
                                <?= format_date($tx['transaction_date']) ?>
                            </td>
                            <td>
                                <span class="badge badge-<?= $tx['type'] ?>">
                                    <?= e(ucfirst($tx['type'])) ?>
                                </span>
                            </td>
                            <td class="font-medium">
                                <?= e($tx['description']) ?>
                            </td>
                            <td>
                                <span class="text-xs text-muted">
                                    <?= e($tx['category_name'] ?? 'General') ?>
                                </span>
                            </td>
                            <td>
                                <span class="text-xs">
                                    <?= e($tx['payment_method']) ?>
                                </span>
                            </td>
                            <td style="text-align: right; font-weight: 600; color: <?= $tx['type'] === 'income' ? 'var(--primary)' : 'var(--danger)' ?>;">
                                <?= $tx['type'] === 'income' ? '+' : '-' ?><?= format_naira($tx['amount']) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Chart initialization script -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    // 1. Monthly Cashflow Data Prep
    <?php
        $months = [];
        $incomes = [];
        $expenses = [];
        foreach ($monthlyStats as $ms) {
            $months[] = $ms['month_label'];
            $incomes[] = (float) $ms['monthly_income'];
            $expenses[] = (float) $ms['monthly_expense'];
        }
        if (empty($months)) {
            $months = [date('M')];
            $incomes = [$totalIncome];
            $expenses = [$totalExpenses];
        }
    ?>
    const cfLabels = <?= json_encode($months) ?>;
    const cfIncome = <?= json_encode($incomes) ?>;
    const cfExpense = <?= json_encode($expenses) ?>;
    window.initCashFlowChart('cashFlowChart', cfLabels, cfIncome, cfExpense);

    // 2. Expense Category Breakdown Data Prep
    <?php
        $catLabels = [];
        $catAmounts = [];
        foreach ($expenseCategories as $ec) {
            $catLabels[] = $ec['category'];
            $catAmounts[] = (float) $ec['total'];
        }
    ?>
    const expLabels = <?= json_encode($catLabels) ?>;
    const expAmounts = <?= json_encode($catAmounts) ?>;
    window.initExpenseChart('expenseChart', expLabels, expAmounts);
});
</script>
