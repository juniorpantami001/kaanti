<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.5rem; color: var(--text-main); margin-bottom: 0.25rem;">
            Ethical & Shariah Investment Discovery
        </h1>
        <p class="text-sm text-muted">Learn about Sukuk bonds, ethical equity funds, and halal wealth-building products in Nigeria.</p>
    </div>
</div>

<!-- Mandatory Risk & Regulatory Disclosure -->
<div class="alert alert-warning" style="margin-bottom: 1.5rem;">
    <i data-lucide="alert-triangle" style="width: 22px; height: 22px; flex-shrink: 0;"></i>
    <div class="text-xs" style="line-height: 1.5;">
        <strong>Important Risk & Investment Disclaimer:</strong> Kaanti Manager is strictly an educational discovery platform. We do not accept investment funds, provide custody, pool capital, or offer personalized investment advice. Investments carry financial risk including potential loss of capital, and past returns do not guarantee future yields. Always consult a registered investment advisor before committing business funds.
    </div>
</div>

<!-- Type Filter Pills -->
<div style="display: flex; gap: 0.5rem; margin-bottom: 1.5rem; overflow-x: auto; padding-bottom: 0.25rem;">
    <a href="<?= url('investments') ?>" class="btn btn-sm <?= empty($selectedType) ? 'btn-primary' : 'btn-secondary' ?>">
        All Products
    </a>
    <a href="<?= url('investments?type=Sukuk') ?>" class="btn btn-sm <?= $selectedType === 'Sukuk' ? 'btn-primary' : 'btn-secondary' ?>">
        Sovereign & Corporate Sukuk
    </a>
    <a href="<?= url('investments?type=Islamic+Fund') ?>" class="btn btn-sm <?= $selectedType === 'Islamic Fund' ? 'btn-primary' : 'btn-secondary' ?>">
        Islamic Mutual Funds
    </a>
    <a href="<?= url('investments?type=Ethical+Equity') ?>" class="btn btn-sm <?= $selectedType === 'Ethical Equity' ? 'btn-primary' : 'btn-secondary' ?>">
        Ethical Equities
    </a>
</div>

<!-- Investment Grid -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 1.25rem;">
    <?php if (empty($investments)): ?>
        <div class="card" style="grid-column: 1 / -1;">
            <div class="empty-state">
                <i data-lucide="piggy-bank" style="width: 32px; height: 32px; margin: 0 auto 1rem; color: var(--text-muted);"></i>
                <div class="empty-state-title">No investment instruments in this view</div>
                <div class="empty-state-desc">Select another category or view all verified ethical instruments.</div>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($investments as $inv): ?>
            <div class="card" style="display: flex; flex-direction: column; justify-content: space-between;">
                <div class="card-body">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.75rem;">
                        <div>
                            <span class="text-xs font-semibold uppercase text-muted"><?= e($inv['provider']) ?></span>
                            <h2 style="font-size: 1.2rem; color: var(--text-main); margin-top: 0.15rem;"><?= e($inv['name']) ?></h2>
                        </div>
                        <span class="badge" style="background: var(--primary-subtle); color: var(--primary-dark); font-weight: 700;">
                            <?= e($inv['type']) ?>
                        </span>
                    </div>

                    <p class="text-sm text-secondary" style="margin-bottom: 1.25rem; line-height: 1.55;">
                        <?= nl2br(e($inv['description'])) ?>
                    </p>

                    <!-- Risk Disclosure Box -->
                    <div style="background: var(--warning-bg); border: 1px solid var(--warning-border); padding: 0.75rem 0.85rem; border-radius: var(--radius-sm); margin-bottom: 1rem;">
                        <div class="text-xs font-bold text-warning" style="display: flex; align-items: center; gap: 0.35rem; margin-bottom: 0.25rem;">
                            <i data-lucide="alert-circle" style="width: 14px; height: 14px;"></i>
                            <span>Risk Disclosure</span>
                        </div>
                        <div class="text-xs" style="color: #92400E; line-height: 1.45;">
                            <?= e($inv['risk_disclosure']) ?>
                        </div>
                    </div>

                    <?php if (!empty($inv['fees'])): ?>
                        <div class="text-xs text-muted" style="margin-bottom: 0.5rem;">
                            <strong>Verified Fees:</strong> <?= e($inv['fees']) ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="card-footer" style="display: flex; justify-content: space-between; align-items: center;">
                    <span class="text-xs text-muted">SEC / Regulatory Registered</span>
                    <?php if (!empty($inv['provider_link'])): ?>
                        <a href="<?= e($inv['provider_link']) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm">
                            <span>Official Prospectus</span>
                            <i data-lucide="external-link" style="width: 13px; height: 13px;"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
