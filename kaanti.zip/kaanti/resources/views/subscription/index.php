<?php
$status = $subscription['status'] ?? 'not_started';
$statusLabel = match ($status) {
    'trialing' => 'Payment required',
    'pending' => 'Payment required',
    'active' => 'Active',
    'past_due' => 'Past due',
    'suspended' => 'Suspended',
    'cancelled' => 'Cancelled',
    default => 'Not started',
};
$statusClass = match ($status) {
    'active' => 'badge-success',
    'trialing', 'pending', 'past_due' => 'badge-warning',
    'suspended', 'cancelled' => 'badge-danger',
    default => 'badge-info',
};
?>
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.5rem; color: var(--text-main); margin: 0 0 0.25rem;">Business subscription</h1>
        <p class="text-sm text-muted" style="margin: 0;">One ₦5,000 monthly subscription covers all businesses owned by this account.</p>
    </div>
    <?php if ($isOwner && $status !== 'active'): ?>
        <form action="<?= url('subscription/checkout') ?>" method="POST">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-primary">
                <span>Continue to secure payment</span>
            </button>
        </form>
    <?php endif; ?>
</div>

<section class="card" aria-labelledby="subscription-status-heading">
    <div class="card-body">
        <h2 id="subscription-status-heading" style="font-size: 1.1rem; margin: 0 0 1rem;">Subscription status</h2>
        <p style="margin: 0 0 1rem;">
            <span class="badge <?= e($statusClass) ?>"><?= e($statusLabel) ?></span>
        </p>

        <?php if ($status === 'trialing'): ?>
            <p class="text-sm text-muted">Free trials have ended. Complete payment now to restore business access.</p>
        <?php elseif ($status === 'pending'): ?>
            <p class="text-sm text-muted">Payment is required now before business features can be used.</p>
        <?php elseif ($status === 'past_due'): ?>
            <p class="text-sm text-muted">Payment is overdue and business access is paused until payment succeeds.</p>
        <?php elseif ($status === 'suspended'): ?>
            <p class="text-sm text-muted">Business access is paused until the subscription payment is completed.</p>
        <?php elseif ($status === 'active'): ?>
            <p class="text-sm text-muted">Your ₦5,000 monthly subscription is active.</p>
        <?php elseif ($status === 'cancelled'): ?>
            <p class="text-sm text-muted">The Paystack subscription is cancelled. Access remains available until the current paid period ends.</p>
        <?php else: ?>
            <p class="text-sm text-muted">A subscription record has not been created for this owner account yet.</p>
        <?php endif; ?>

        <?php if (!empty($subscription['current_period_end'])): ?>
            <p class="text-sm" style="margin: 1rem 0 0;">
                <strong>Current period ends:</strong>
                <?= e(date('M j, Y', strtotime($subscription['current_period_end']))) ?>
            </p>
        <?php endif; ?>

        <?php if (!$isOwner): ?>
            <p class="text-sm text-muted" style="margin: 1rem 0 0;">Only the business owner can manage billing. Please contact the owner to update the subscription.</p>
        <?php endif; ?>
    </div>
</section>
