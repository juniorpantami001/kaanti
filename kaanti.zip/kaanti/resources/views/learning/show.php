<?php
$title   = $lang === 'ha' ? $article['title_ha'] : $article['title'];
$content = $lang === 'ha' ? $article['content_ha'] : $article['content'];
$catName = $lang === 'ha' ? $article['category_name_ha'] : $article['category_name'];
?>

<div style="max-width: 760px; margin: 0 auto;">
    <div style="margin-bottom: 1.5rem;">
        <a href="<?= url('learning') ?>" class="text-sm text-muted" style="display: inline-flex; align-items: center; gap: 0.35rem; margin-bottom: 0.5rem;">
            <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
            <span><?= $lang === 'ha' ? 'Koma shafin koyo' : 'Back to Kaanti Learn' ?></span>
        </a>

        <div style="display: flex; gap: 0.5rem; align-items: center; margin-bottom: 0.5rem;">
            <span class="badge" style="background: var(--primary-subtle); color: var(--primary-dark); font-weight: 700;">
                <?= e($catName) ?>
            </span>
            <span class="text-xs text-muted">&bull; <?= $article['read_time_minutes'] ?> min read</span>
            <span class="text-xs text-muted">&bull; <?= format_date($article['published_at']) ?></span>
        </div>

        <h1 style="font-size: 2rem; color: var(--text-main); line-height: 1.25; margin-bottom: 0.75rem;">
            <?= e($title) ?>
        </h1>
    </div>

    <!-- Article Reader Card -->
    <div class="card" style="margin-bottom: 2rem;">
        <div class="card-body" style="padding: 2.25rem 2.5rem; font-size: 1.05rem; line-height: 1.8; color: var(--text-main);">
            <div style="white-space: pre-line;">
                <?= e($content) ?>
            </div>

            <!-- Hausa / English Alternate Notice -->
            <div style="margin-top: 2.5rem; padding-top: 1.5rem; border-top: 1px solid var(--border); background: var(--bg-app); padding: 1.25rem; border-radius: var(--radius-md);">
                <div class="text-xs font-bold uppercase text-muted" style="margin-bottom: 0.35rem;">
                    <?= $lang === 'ha' ? 'Wannan darasi a Harshen Turanci (English Version):' : 'Hausa Translation Available (Karatun Harshen Hausa):' ?>
                </div>
                <div class="text-sm text-secondary">
                    <?php if ($lang === 'ha'): ?>
                        <strong><?= e($article['title']) ?></strong>: <?= e($article['excerpt']) ?>
                    <?php else: ?>
                        <strong><?= e($article['title_ha']) ?></strong>: <?= e($article['excerpt_ha']) ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Related Articles -->
    <?php if (!empty($related)): ?>
        <div style="margin-top: 2rem;">
            <h3 style="font-size: 1.2rem; margin-bottom: 1rem;"><?= $lang === 'ha' ? 'Karin Darussa a Wannan Bangare' : 'Related Guides in this Category' ?></h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem;">
                <?php foreach ($related as $rel): ?>
                    <a href="<?= url('learning/' . $rel['slug']) ?>" class="card" style="padding: 1.25rem; display: block; text-decoration: none;">
                        <h4 style="font-size: 0.95rem; color: var(--text-main); margin-bottom: 0.35rem;">
                            <?= e($lang === 'ha' ? $rel['title_ha'] : $rel['title']) ?>
                        </h4>
                        <span class="text-xs text-muted"><?= $rel['read_time_minutes'] ?> min read &rarr;</span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
