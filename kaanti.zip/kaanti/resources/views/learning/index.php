<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.5rem; color: var(--text-main); margin-bottom: 0.25rem;">
            <?= $lang === 'ha' ? 'Koyon Kaanti: Ilimin Kasuwanci' : 'Kaanti Learn: SME Business Education' ?>
        </h1>
        <p class="text-sm text-muted">
            <?= $lang === 'ha' 
                ? 'Koyi yadda ake gudanar da kudi, rubuta ciniki, da bunkasa jari cikin sauki.' 
                : 'Practical guides on bookkeeping, inventory control, cash flow discipline, and ethical finance.' 
            ?>
        </p>
    </div>

    <!-- Language Toggle Quick Switch -->
    <div style="display: flex; align-items: center; gap: 0.5rem;">
        <span class="text-xs text-muted">Harshe / Language:</span>
        <span class="badge" style="background: var(--primary-subtle); color: var(--primary); font-weight: 700;">
            <?= $lang === 'ha' ? 'Hausa (HA)' : 'English (EN)' ?>
        </span>
    </div>
</div>

<!-- Search Bar -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-body" style="padding: 1rem 1.25rem;">
        <form method="GET" action="<?= url('learning') ?>" style="display: flex; gap: 0.75rem;">
            <input 
                type="text" 
                name="search" 
                class="form-control" 
                value="<?= e($search ?? '') ?>" 
                placeholder="<?= $lang === 'ha' ? 'Bincika darussa ko lakcoci...' : 'Search articles, topics, keywords...' ?>"
            >
            <button type="submit" class="btn btn-primary">
                <i data-lucide="search" style="width: 16px; height: 16px;"></i>
                <span><?= $lang === 'ha' ? 'Bincika' : 'Search' ?></span>
            </button>
            <?php if (!empty($search) || !empty($selectedCategory)): ?>
                <a href="<?= url('learning') ?>" class="btn btn-secondary">Clear</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Category Filter Pills -->
<div style="display: flex; gap: 0.5rem; margin-bottom: 1.5rem; overflow-x: auto; padding-bottom: 0.25rem;">
    <a href="<?= url('learning') ?>" class="btn btn-sm <?= empty($selectedCategory) ? 'btn-primary' : 'btn-secondary' ?>">
        <?= $lang === 'ha' ? 'Duk Darussa' : 'All Topics' ?>
    </a>
    <?php foreach ($categories as $cat): ?>
        <a href="<?= url('learning?category=' . $cat['slug']) ?>" class="btn btn-sm <?= $selectedCategory === $cat['slug'] ? 'btn-primary' : 'btn-secondary' ?>">
            <?= e($lang === 'ha' ? $cat['name_ha'] : $cat['name']) ?>
        </a>
    <?php endforeach; ?>
</div>

<!-- Articles Grid -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.25rem;">
    <?php if (empty($articles)): ?>
        <div class="card" style="grid-column: 1 / -1;">
            <div class="empty-state">
                <i data-lucide="book-open" style="width: 32px; height: 32px; margin: 0 auto 1rem; color: var(--text-muted);"></i>
                <div class="empty-state-title"><?= $lang === 'ha' ? 'Babu darasin da aka samu a wannan bangare' : 'No articles found in this category' ?></div>
                <div class="empty-state-desc"><?= $lang === 'ha' ? 'Zabi wani rukuni daban ko ka share bincikenka.' : 'Select another topic or clear your search filter.' ?></div>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($articles as $art): ?>
            <?php 
                $title   = $lang === 'ha' ? $art['title_ha'] : $art['title'];
                $excerpt = $lang === 'ha' ? ($art['excerpt_ha'] ?: $art['excerpt']) : $art['excerpt'];
                $catName = $lang === 'ha' ? $art['category_name_ha'] : $art['category_name'];
            ?>
            <div class="card" style="display: flex; flex-direction: column; justify-content: space-between;">
                <div class="card-body">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
                        <span class="badge" style="background: var(--primary-subtle); color: var(--primary-dark); font-weight: 600;">
                            <?= e($catName) ?>
                        </span>
                        <span class="text-xs text-muted" style="display: flex; align-items: center; gap: 0.3rem;">
                            <i data-lucide="clock" style="width: 13px; height: 13px;"></i>
                            <span><?= $art['read_time_minutes'] ?> min read</span>
                        </span>
                    </div>

                    <h2 style="font-size: 1.15rem; color: var(--text-main); margin-bottom: 0.65rem; line-height: 1.35;">
                        <a href="<?= url('learning/' . $art['slug']) ?>" style="color: inherit;">
                            <?= e($title) ?>
                        </a>
                    </h2>

                    <p class="text-sm text-secondary" style="line-height: 1.55; margin-bottom: 1rem;">
                        <?= e($excerpt) ?>
                    </p>
                </div>

                <div class="card-footer" style="display: flex; justify-content: space-between; align-items: center;">
                    <span class="text-xs text-muted">Kaanti Academy</span>
                    <a href="<?= url('learning/' . $art['slug']) ?>" class="btn btn-outline-primary btn-sm">
                        <span><?= $lang === 'ha' ? 'Karanta Karasa' : 'Read Article' ?></span>
                        <i data-lucide="arrow-right" style="width: 14px; height: 14px;"></i>
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
