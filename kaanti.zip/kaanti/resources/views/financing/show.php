<div style="max-width: 800px; margin: 0 auto;">
    <div style="margin-bottom: 1.5rem;">
        <a href="<?= url('financing') ?>" class="text-sm text-muted" style="display: inline-flex; align-items: center; gap: 0.35rem; margin-bottom: 0.5rem;">
            <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
            <span>Back to financing discovery</span>
        </a>
        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 1rem;">
            <div>
                <span class="badge" style="background: var(--primary-subtle); color: var(--primary-dark); font-weight: 700; margin-bottom: 0.4rem;">
                    <?= e($product['type']) ?> Contract
                </span>
                <h1 style="font-size: 1.6rem; color: var(--text-main);"><?= e($product['name']) ?></h1>
                <div class="text-sm font-semibold" style="color: var(--primary); margin-top: 0.2rem;">
                    Provider: <?= e($product['provider']) ?>
                </div>
            </div>

            <?php if ($product['is_verified']): ?>
                <span class="badge badge-success" style="font-size: 0.85rem; padding: 0.35rem 0.75rem;">
                    <i data-lucide="shield-check" style="width: 14px; height: 14px;"></i>
                    <span>Verified Partner</span>
                </span>
            <?php else: ?>
                <span class="badge badge-warning" style="font-size: 0.85rem; padding: 0.35rem 0.75rem;">
                    <i data-lucide="eye" style="width: 14px; height: 14px;"></i>
                    <span>Demonstration Profile</span>
                </span>
            <?php endif; ?>
        </div>
    </div>

    <!-- Product Details Card -->
    <div class="card" style="margin-bottom: 1.5rem;">
        <div class="card-body" style="padding: 1.75rem;">
            <div style="margin-bottom: 1.5rem;">
                <h3 class="card-title" style="margin-bottom: 0.5rem;">Overview & Structure</h3>
                <p class="text-secondary" style="line-height: 1.6; font-size: 0.95rem;">
                    <?= nl2br(e($product['description'])) ?>
                </p>
            </div>

            <?php if (!empty($product['eligibility'])): ?>
                <div style="margin-bottom: 1.5rem; padding-top: 1.25rem; border-top: 1px solid var(--border);">
                    <h3 class="card-title" style="margin-bottom: 0.5rem;">Who is Eligible?</h3>
                    <p class="text-secondary" style="line-height: 1.6; font-size: 0.95rem;">
                        <?= nl2br(e($product['eligibility'])) ?>
                    </p>
                </div>
            <?php endif; ?>

            <?php if (!empty($product['application_process'])): ?>
                <div style="margin-bottom: 1.5rem; padding-top: 1.25rem; border-top: 1px solid var(--border);">
                    <h3 class="card-title" style="margin-bottom: 0.5rem;">Application Steps</h3>
                    <p class="text-secondary" style="line-height: 1.6; font-size: 0.95rem;">
                        <?= nl2br(e($product['application_process'])) ?>
                    </p>
                </div>
            <?php endif; ?>

            <?php if (!empty($product['terms_and_fees'])): ?>
                <div style="margin-bottom: 1.5rem; padding-top: 1.25rem; border-top: 1px solid var(--border);">
                    <h3 class="card-title" style="margin-bottom: 0.5rem;">Terms & Profit Margins</h3>
                    <p class="text-secondary" style="line-height: 1.6; font-size: 0.95rem;">
                        <?= nl2br(e($product['terms_and_fees'])) ?>
                    </p>
                </div>
            <?php endif; ?>

            <?php if (!empty($product['contact_info'])): ?>
                <div style="padding-top: 1.25rem; border-top: 1px solid var(--border);">
                    <h3 class="card-title" style="margin-bottom: 0.5rem;">Direct Contact Information</h3>
                    <p class="text-secondary" style="line-height: 1.6; font-size: 0.95rem;">
                        <?= nl2br(e($product['contact_info'])) ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>

        <div class="card-footer" style="display: flex; justify-content: space-between; align-items: center;">
            <span class="text-xs text-muted">Kaanti Manager facilitates discovery without charging brokerage fees.</span>
            <?php if (!empty($product['application_link'])): ?>
                <a href="<?= e($product['application_link']) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary">
                    <span>Visit Partner Application Portal</span>
                    <i data-lucide="external-link" style="width: 16px; height: 16px;"></i>
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>
