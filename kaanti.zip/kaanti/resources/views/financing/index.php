<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.5rem; color: var(--text-main); margin-bottom: 0.25rem;">
            Financing Discovery Directory
        </h1>
        <p class="text-sm text-muted">Explore verified and Shariah-compliant financing opportunities for growing Nigerian businesses.</p>
    </div>
</div>

<!-- Non-lender Disclaimer Alert -->
<div class="alert alert-info" style="margin-bottom: 1.5rem;">
    <i data-lucide="shield-alert" style="width: 20px; height: 20px; flex-shrink: 0;"></i>
    <div class="text-xs">
        <strong>Notice & Regulatory Disclosure:</strong> Kaanti Manager is a financial management software platform, not a bank, moneylender, or credit broker. We do not provide loans, guarantee approvals, or collect advance fees. All applications occur directly on the official portals of licensed financial partners.
    </div>
</div>

<!-- Filter Tabs -->
<div style="display: flex; gap: 0.5rem; margin-bottom: 1.5rem; overflow-x: auto; padding-bottom: 0.25rem;">
    <a href="<?= url('financing') ?>" class="btn btn-sm <?= empty($selectedType) ? 'btn-primary' : 'btn-secondary' ?>">
        All Financing Types
    </a>
    <a href="<?= url('financing?type=Murabaha') ?>" class="btn btn-sm <?= $selectedType === 'Murabaha' ? 'btn-primary' : 'btn-secondary' ?>">
        Murabaha (Cost-Plus Trade)
    </a>
    <a href="<?= url('financing?type=Ijarah') ?>" class="btn btn-sm <?= $selectedType === 'Ijarah' ? 'btn-primary' : 'btn-secondary' ?>">
        Ijarah (Lease-to-Own)
    </a>
    <a href="<?= url('financing?type=Mudarabah') ?>" class="btn btn-sm <?= $selectedType === 'Mudarabah' ? 'btn-primary' : 'btn-secondary' ?>">
        Mudarabah (Profit Sharing)
    </a>
    <a href="<?= url('financing?type=Musharakah') ?>" class="btn btn-sm <?= $selectedType === 'Musharakah' ? 'btn-primary' : 'btn-secondary' ?>">
        Musharakah (Partnership)
    </a>
    <a href="<?= url('financing?type=Salam') ?>" class="btn btn-sm <?= $selectedType === 'Salam' ? 'btn-primary' : 'btn-secondary' ?>">
        Salam (Agricultural Advance)
    </a>
</div>

<!-- Products Grid -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.25rem;">
    <?php if (empty($products)): ?>
        <div class="card" style="grid-column: 1 / -1;">
            <div class="empty-state">
                <i data-lucide="landmark" style="width: 32px; height: 32px; margin: 0 auto 1rem; color: var(--text-muted);"></i>
                <div class="empty-state-title">No listings match this category yet</div>
                <div class="empty-state-desc">New verified non-interest financial partners are onboarded regularly. Check back soon.</div>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($products as $fp): ?>
            <div class="card" style="display: flex; flex-direction: column; justify-content: space-between;">
                <div class="card-body">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.75rem;">
                        <div>
                            <span class="text-xs font-semibold uppercase text-muted"><?= e($fp['provider']) ?></span>
                            <h2 style="font-size: 1.15rem; color: var(--text-main); margin-top: 0.15rem;"><?= e($fp['name']) ?></h2>
                        </div>
                        <?php if ($fp['is_verified']): ?>
                            <span class="badge badge-success" title="Terms independently verified">
                                <i data-lucide="shield-check" style="width: 12px; height: 12px;"></i>
                                <span>Verified Partner</span>
                            </span>
                        <?php else: ?>
                            <span class="badge badge-warning" title="Demonstration listing">
                                <i data-lucide="eye" style="width: 12px; height: 12px;"></i>
                                <span>Demo Listing</span>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div style="margin-bottom: 1rem;">
                        <span class="badge" style="background: var(--primary-subtle); color: var(--primary-dark); font-weight: 700;">
                            <?= e($fp['type']) ?>
                        </span>
                    </div>

                    <p class="text-sm text-secondary" style="margin-bottom: 1rem; line-height: 1.5;">
                        <?= e(str_limit($fp['description'], 160)) ?>
                    </p>

                    <?php if (!empty($fp['eligibility'])): ?>
                        <div style="background: var(--bg-app); padding: 0.6rem 0.75rem; border-radius: var(--radius-sm); font-size: 0.78rem; color: var(--text-secondary); margin-bottom: 1rem;">
                            <strong>Eligibility:</strong> <?= e(str_limit($fp['eligibility'], 90)) ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="card-footer" style="display: flex; justify-content: space-between; align-items: center;">
                    <a href="<?= url('financing/' . $fp['id']) ?>" class="btn btn-secondary btn-sm">
                        <span>Read Terms & Details</span>
                    </a>
                    <?php if (!empty($fp['application_link'])): ?>
                        <a href="<?= e($fp['application_link']) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm">
                            <span>Official Portal</span>
                            <i data-lucide="external-link" style="width: 13px; height: 13px;"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
