<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= e($title ?? 'Kaanti Manager — Manage. Grow. Prosper.') ?></title>
    
    <!-- Favicon using official logo -->
    <link rel="icon" type="image/jpeg" href="<?= asset('images/logo.jpeg') ?>">
    
    <!-- Application Design System -->
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    
    <!-- Chart.js for Financial Visualizations -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="app-wrapper">
        <!-- Sidebar Navigation Drawer -->
        <?php \App\Core\View::component('sidebar'); ?>
        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <!-- Main Workspace -->
        <div class="main-wrapper">
            <!-- Header Topbar -->
            <?php \App\Core\View::component('topbar'); ?>

            <!-- Page Body Content -->
            <main class="content-body">
                <!-- Flash Alerts -->
                <?php \App\Core\View::component('alert', ['flash' => $flash ?? []]); ?>

                <!-- View Output -->
                <?= $content ?>
            </main>
        </div>
    </div>

    <!-- Client Script -->
    <script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
