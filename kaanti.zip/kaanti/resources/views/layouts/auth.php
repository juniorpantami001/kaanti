<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'Kaanti Manager — Manage. Grow. Prosper.') ?></title>

    <!-- Favicon -->
    <link rel="icon" type="image/jpeg" href="<?= asset('images/logo.jpeg') ?>">

    <!-- Application Design System -->
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">

    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
</head>
<body>
    <div class="auth-page">
        <!-- Branded Side Panel (Desktop) -->
        <div class="auth-brand-side">
            <div style="display: flex; align-items: center; gap: 0.85rem;">
                <img src="<?= asset('images/logo.jpeg') ?>" alt="Kaanti" style="width: 44px; height: 44px; border-radius: var(--radius-md); background: #fff; object-fit: cover;">
                <div>
                    <span style="font-size: 1.4rem; font-weight: 700; color: #fff;">Kaanti Manager</span>
                    <div style="color: var(--accent); font-size: 0.75rem; letter-spacing: 0.08em; text-transform: uppercase; font-weight: 600;">Manage. Grow. Prosper.</div>
                </div>
            </div>

            <div style="max-width: 480px; z-index: 10;">
                <span class="badge" style="background: rgba(249, 168, 37, 0.2); color: #F9A825; border: 1px solid rgba(249, 168, 37, 0.4); margin-bottom: 1rem; font-size: 0.8rem; padding: 0.3rem 0.75rem;">
                    Northern Nigeria SME Suite
                </span>
                <h2 style="font-size: 2.1rem; color: #FFFFFF; font-weight: 700; margin-bottom: 1rem; line-height: 1.25;">
                    Empowering market traders & shop owners with clear numbers.
                </h2>
                <p style="color: rgba(255, 255, 255, 0.85); font-size: 1.05rem; line-height: 1.6;">
                    Track daily sales, control shop inventory, manage debtor customers, and discover verified non-interest Islamic financing.
                </p>

                <div style="margin-top: 2rem; display: flex; flex-direction: column; gap: 0.75rem;">
                    <div style="display: flex; align-items: center; gap: 0.75rem; color: rgba(255,255,255,0.9); font-size: 0.92rem;">
                        <i data-lucide="shield-check" style="color: var(--accent); width: 20px; height: 20px;"></i>
                        <span>100% tenant-isolated, confidential business records</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.75rem; color: rgba(255,255,255,0.9); font-size: 0.92rem;">
                        <i data-lucide="check-circle-2" style="color: var(--accent); width: 20px; height: 20px;"></i>
                        <span>Bilingual interface with full English & Hausa support</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.75rem; color: rgba(255,255,255,0.9); font-size: 0.92rem;">
                        <i data-lucide="trending-up" style="color: var(--accent); width: 20px; height: 20px;"></i>
                        <span>Accurate Naira calculations with no fake numbers</span>
                    </div>
                </div>
            </div>

            <div style="font-size: 0.82rem; color: rgba(255, 255, 255, 0.6); z-index: 10;">
                &copy; <?= date('Y') ?> Kaanti Manager. All rights reserved.
            </div>
        </div>

        <!-- Auth Form Interactive Side -->
        <div class="auth-form-side">
            <!-- Mobile Brand Header -->
            <div class="auth-logo-mobile">
                <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;">
                    <img src="<?= asset('images/logo.jpeg') ?>" alt="Kaanti" style="width: 38px; height: 38px; border-radius: var(--radius-md); object-fit: cover;">
                    <div>
                        <div style="font-size: 1.2rem; font-weight: 700; color: var(--text-main);">Kaanti Manager</div>
                        <div style="color: var(--primary); font-size: 0.7rem; font-weight: 600; text-transform: uppercase;">Manage. Grow. Prosper.</div>
                    </div>
                </div>
            </div>

            <!-- Flash messages -->
            <?php \App\Core\View::component('alert', ['flash' => $flash ?? []]); ?>

            <!-- View content -->
            <?= $content ?>
        </div>
    </div>

    <!-- Script -->
    <script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
