<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title ?? 'Report — Kaanti Manager') ?></title>
    <link rel="icon" type="image/jpeg" href="<?= asset('images/logo.jpeg') ?>">
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    <style>
        body {
            background-color: #FFFFFF !important;
            padding: 2.5rem;
            color: #0F172A;
            font-size: 13px;
        }
        .no-print {
            display: flex;
            gap: 0.75rem;
            margin-bottom: 2rem;
            justify-content: flex-end;
        }
        @media print {
            .no-print { display: none !important; }
            body { padding: 0 !important; }
        }
    </style>
</head>
<body>
    <div class="no-print">
        <button type="button" onclick="window.print()" class="btn btn-primary btn-sm">
            Print / Save as PDF
        </button>
        <button type="button" onclick="window.close()" class="btn btn-secondary btn-sm">
            Close Window
        </button>
    </div>

    <?= $content ?>
</body>
</html>
