<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.25rem;">
            <a href="<?= url('admin') ?>" class="text-sm text-muted">Admin</a>
            <span class="text-muted">/</span>
            <h1 style="font-size: 1.5rem; color: var(--text-main); margin: 0;">Immutable System Audit Logs</h1>
        </div>
        <p class="text-sm text-muted">Security and operational events recorded with caller identity, IP address, and payload diffs.</p>
    </div>

    <a href="<?= url('admin') ?>" class="btn btn-secondary btn-sm">
        <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
        <span>Back to Admin</span>
    </a>
</div>

<div class="card">
    <div class="table-container" style="border: none;">
        <table class="table">
            <thead>
                <tr>
                    <th>Timestamp</th>
                    <th>User Email</th>
                    <th>Business</th>
                    <th>Action</th>
                    <th>Entity</th>
                    <th>IP & Agent</th>
                    <th>Old / New Values</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 2rem; color: var(--text-muted);">No audit records logged yet.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($logs as $l): ?>
                        <tr>
                            <td class="text-xs text-muted"><?= format_date($l['created_at'], 'M j, Y H:i:s') ?></td>
                            <td class="font-medium text-xs"><?= e($l['email'] ?: 'System') ?></td>
                            <td class="text-xs"><?= e($l['business_name'] ?: 'Global') ?></td>
                            <td><code><?= e($l['action']) ?></code></td>
                            <td class="text-xs text-secondary"><?= e($l['entity_type']) ?> #<?= e(substr($l['entity_id'] ?? '—', 0, 8)) ?></td>
                            <td class="text-xs text-muted" style="max-width: 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                <?= e($l['ip_address']) ?>
                            </td>
                            <td class="text-xs">
                                <?php if (!empty($l['new_values'])): ?>
                                    <code style="font-size: 0.7rem; background: var(--surface-alt); padding: 0.15rem 0.35rem; border-radius: 3px;">
                                        <?= e(str_limit($l['new_values'], 40)) ?>
                                    </code>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
