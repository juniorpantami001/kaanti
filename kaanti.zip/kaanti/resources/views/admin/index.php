<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.25rem;">
            <h1 style="font-size: 1.6rem; color: var(--text-main);">Super Admin Control Center</h1>
            <span class="badge" style="background: var(--danger-bg); color: var(--danger); font-weight: 700;">Privileged Access</span>
        </div>
        <p class="text-sm text-muted">Platform-wide multi-tenant monitoring, account security, and audit enforcement.</p>
    </div>

    <div style="display: flex; gap: 0.5rem;">
        <a href="<?= url('admin/businesses') ?>" class="btn btn-secondary btn-sm">
            <i data-lucide="store" style="width: 15px; height: 15px;"></i>
            <span>Businesses Directory</span>
        </a>
        <a href="<?= url('admin/users') ?>" class="btn btn-secondary btn-sm">
            <i data-lucide="users" style="width: 15px; height: 15px;"></i>
            <span>User Accounts</span>
        </a>
        <a href="<?= url('admin/audit') ?>" class="btn btn-secondary btn-sm">
            <i data-lucide="file-text" style="width: 15px; height: 15px;"></i>
            <span>Audit Trail</span>
        </a>
    </div>
</div>

<!-- Platform Wide KPI Statistics -->
<div class="stats-grid">
    <div class="stat-card">
        <div>
            <div class="stat-title">Registered Businesses</div>
            <div class="stat-value" style="color: var(--primary);"><?= number_format($totalBusinesses) ?></div>
            <div class="stat-subtext">Tenant organizations</div>
        </div>
        <div class="stat-icon-box icon-box-green">
            <i data-lucide="store" style="width: 22px; height: 22px;"></i>
        </div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-title">Platform Users</div>
            <div class="stat-value"><?= number_format($totalUsers) ?></div>
            <div class="stat-subtext">Registered accounts</div>
        </div>
        <div class="stat-icon-box icon-box-blue">
            <i data-lucide="users" style="width: 22px; height: 22px;"></i>
        </div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-title">Transactions Logged</div>
            <div class="stat-value"><?= number_format($totalTx) ?></div>
            <div class="stat-subtext">Platform transaction volume</div>
        </div>
        <div class="stat-icon-box icon-box-gold">
            <i data-lucide="receipt" style="width: 22px; height: 22px;"></i>
        </div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-title">Total Transaction Value</div>
            <div class="stat-value" style="color: var(--primary);">
                <?= format_naira($totalVolume) ?>
            </div>
            <div class="stat-subtext">Gross platform throughput</div>
        </div>
        <div class="stat-icon-box icon-box-green">
            <i data-lucide="coins" style="width: 22px; height: 22px;"></i>
        </div>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div>
            <div class="stat-title">Active Businesses</div>
            <div class="stat-value" style="color: var(--primary);"><?= number_format($activeBusinesses) ?></div>
            <div class="stat-subtext">Business status is active</div>
        </div>
        <div class="stat-icon-box icon-box-green">
            <i data-lucide="store" style="width: 22px; height: 22px;"></i>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-title">Suspended Businesses</div>
            <div class="stat-value"><?= number_format($suspendedBusinesses) ?></div>
            <div class="stat-subtext">Can be reactivated below</div>
        </div>
        <div class="stat-icon-box icon-box-gold">
            <i data-lucide="pause-circle" style="width: 22px; height: 22px;"></i>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-title">Active Subscriptions</div>
            <div class="stat-value"><?= number_format($activeSubscriptions) ?></div>
            <div class="stat-subtext">Owner accounts paid</div>
        </div>
        <div class="stat-icon-box icon-box-blue">
            <i data-lucide="credit-card" style="width: 22px; height: 22px;"></i>
        </div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-title">Subscriptions to Review</div>
            <div class="stat-value"><?= number_format($subscriptionsNeedingAttention) ?></div>
            <div class="stat-subtext">Past due or access suspended</div>
        </div>
        <div class="stat-icon-box icon-box-gold">
            <i data-lucide="alert-circle" style="width: 22px; height: 22px;"></i>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">Subscription Collections</div>
            <div class="text-xs text-muted">Gross successful Paystack payments</div>
        </div>
        <i data-lucide="wallet" style="width: 20px; height: 20px; color: var(--primary);"></i>
    </div>
    <div class="stats-grid" style="margin-bottom: 0;">
        <div class="stat-card">
            <div>
                <div class="stat-title">Collected All Time</div>
                <div class="stat-value" style="color: var(--primary);"><?= format_naira($lifetimeSubscriptionRevenue) ?></div>
                <div class="stat-subtext">Paid subscription charges</div>
            </div>
            <div class="stat-icon-box icon-box-green">
                <i data-lucide="coins" style="width: 22px; height: 22px;"></i>
            </div>
        </div>
        <div class="stat-card">
            <div>
                <div class="stat-title">Collected This Month</div>
                <div class="stat-value"><?= format_naira($monthlySubscriptionRevenue) ?></div>
                <div class="stat-subtext">Paid since the start of this month</div>
            </div>
            <div class="stat-icon-box icon-box-blue">
                <i data-lucide="calendar-days" style="width: 22px; height: 22px;"></i>
            </div>
        </div>
        <div class="stat-card">
            <div>
                <div class="stat-title">Successful Payments</div>
                <div class="stat-value"><?= number_format($successfulSubscriptionPayments) ?></div>
                <div class="stat-subtext">Recorded paid charges</div>
            </div>
            <div class="stat-icon-box icon-box-gold">
                <i data-lucide="receipt" style="width: 22px; height: 22px;"></i>
            </div>
        </div>
    </div>
    <p class="text-xs text-muted" style="padding: 0 1rem 1rem; margin: 0;">Gross collections only; Paystack fees and refunds are not deducted.</p>
</div>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">Business Management</div>
            <div class="text-xs text-muted">Latest businesses, owner accounts, and access controls</div>
        </div>
        <a href="<?= url('admin/businesses') ?>" class="btn btn-primary btn-sm">
            <i data-lucide="settings-2" style="width: 15px; height: 15px;"></i>
            <span>Manage All Businesses</span>
        </a>
    </div>

    <?php if (empty($recentBusinesses)): ?>
        <div class="empty-state">
            <p class="text-sm text-muted">No businesses are registered yet.</p>
        </div>
    <?php else: ?>
        <div class="table-container" style="border: none;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Business</th>
                        <th>Owner</th>
                        <th>Subscription</th>
                        <th>Business Status</th>
                        <th>Registered</th>
                        <th style="text-align: right;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentBusinesses as $business): ?>
                        <tr>
                            <td>
                                <div class="font-bold"><?= e($business['name']) ?></div>
                                <div class="text-xs text-muted"><?= e($business['type']) ?></div>
                            </td>
                            <td class="text-sm"><?= e($business['owner_email'] ?: 'Owner not assigned') ?></td>
                            <td>
                                <?php if (!empty($business['subscription_status'])): ?>
                                    <span class="badge <?= $business['subscription_status'] === 'active' ? 'badge-success' : 'badge-warning' ?>">
                                        <?= e(ucwords(str_replace('_', ' ', $business['subscription_status']))) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-xs text-muted">Not set up</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($business['status'] === 'active'): ?>
                                    <span class="badge badge-success">Active</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Suspended</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-xs text-muted"><?= e(format_date($business['created_at'], 'M j, Y')) ?></td>
                            <td style="text-align: right;">
                                <form action="<?= url('admin/businesses/' . $business['id'] . '/toggle') ?>" method="POST" onsubmit="return confirm('Change access status for this business?');" style="display: inline;">
                                    <?= csrf_field() ?>
                                    <?php if ($business['status'] === 'active'): ?>
                                        <button type="submit" class="btn btn-secondary btn-sm" style="color: var(--danger);">
                                            <span>Suspend</span>
                                        </button>
                                    <?php else: ?>
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <span>Reactivate</span>
                                        </button>
                                    <?php endif; ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Recent Security & Platform Audit Activity -->
<div class="card">
    <div class="card-header">
        <div class="card-title" style="display: flex; align-items: center; gap: 0.5rem;">
            <i data-lucide="shield-check" style="width: 18px; height: 18px; color: var(--primary);"></i>
            <span>Recent Platform Activity & Audit Logs</span>
        </div>
        <a href="<?= url('admin/audit') ?>" class="text-xs text-primary font-semibold">View Full Trail &rarr;</a>
    </div>

    <?php if (empty($recentAudit)): ?>
        <div class="empty-state">
            <p class="text-sm text-muted">No audit activity logged yet.</p>
        </div>
    <?php else: ?>
        <div class="table-container" style="border: none;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>User</th>
                        <th>Business Tenant</th>
                        <th>Action Performed</th>
                        <th>Target Entity</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentAudit as $log): ?>
                        <tr>
                            <td class="text-xs text-muted"><?= format_date($log['created_at'], 'M j, Y H:i:s') ?></td>
                            <td class="font-medium text-sm">
                                <?= e($log['email'] ?: 'System') ?>
                            </td>
                            <td>
                                <?= !empty($log['business_name']) ? '<span class="badge badge-info">' . e($log['business_name']) . '</span>' : '<span class="text-xs text-muted">Platform-wide</span>' ?>
                            </td>
                            <td>
                                <code><?= e($log['action']) ?></code>
                            </td>
                            <td class="text-xs text-secondary"><?= e($log['entity_type']) ?> (<?= e(substr($log['entity_id'] ?? '—', 0, 8)) ?>)</td>
                            <td class="text-xs text-muted"><?= e($log['ip_address'] ?: '127.0.0.1') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
