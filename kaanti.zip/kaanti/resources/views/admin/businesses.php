<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.25rem;">
            <a href="<?= url('admin') ?>" class="text-sm text-muted">Admin</a>
            <span class="text-muted">/</span>
            <h1 style="font-size: 1.5rem; color: var(--text-main); margin: 0;">Business Tenants</h1>
        </div>
        <p class="text-sm text-muted">Manage SME accounts, monitor activity, and enforce platform activation or suspensions.</p>
    </div>

    <a href="<?= url('admin') ?>" class="btn btn-secondary btn-sm">
        <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
        <span>Back to Admin</span>
    </a>
</div>

<div class="card" style="margin-bottom: 1rem;">
    <div class="card-body" style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: end;">
        <div class="form-group" style="flex: 1; min-width: 220px; margin: 0;">
            <label for="businessSearch" class="form-label">Search businesses</label>
            <input id="businessSearch" type="search" class="form-control" placeholder="Name, owner, type, or location" autocomplete="off">
        </div>
        <div class="form-group" style="width: 200px; margin: 0;">
            <label for="businessStatusFilter" class="form-label">Business status</label>
            <select id="businessStatusFilter" class="form-control">
                <option value="">All statuses</option>
                <option value="active">Active</option>
                <option value="suspended">Suspended</option>
            </select>
        </div>
        <div id="businessResultCount" class="text-sm text-muted" role="status" aria-live="polite"></div>
    </div>
</div>

<div class="card">
    <div class="table-container" style="border: none;">
        <table class="table">
            <thead>
                <tr>
                    <th>Business Name</th>
                    <th>Type / Sector</th>
                    <th>Location / State</th>
                    <th>Owner</th>
                    <th>Subscription</th>
                    <th>Contact Phone</th>
                    <th style="text-align: center;">Members</th>
                    <th style="text-align: center;">Transactions</th>
                    <th>Status</th>
                    <th style="text-align: center;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($businesses)): ?>
                    <tr>
                        <td colspan="10" style="text-align: center; padding: 2rem; color: var(--text-muted);">No businesses registered yet.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($businesses as $b): ?>
                        <tr class="business-row" data-status="<?= e($b['status']) ?>" data-search="<?= e(implode(' ', [$b['name'], $b['slug'], $b['type'], $b['category'] ?? '', $b['location'] ?? '', $b['state'] ?? '', $b['owner_email'] ?? ''])) ?>">
                            <td class="font-bold">
                                <?= e($b['name']) ?>
                                <div class="text-xs text-muted">slug: <?= e($b['slug']) ?></div>
                            </td>
                            <td>
                                <?= e($b['type']) ?>
                                <?php if (!empty($b['category'])): ?>
                                    <div class="text-xs text-muted"><?= e($b['category']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= e($b['location'] ?: '—') ?>
                                <span class="badge badge-info" style="font-size: 0.7rem; margin-left: 0.25rem;"><?= e($b['state'] ?: 'Nigeria') ?></span>
                            </td>
                            <td class="text-xs"><?= e($b['owner_email'] ?: '—') ?></td>
                            <td>
                                <?php if (!empty($b['subscription_status'])): ?>
                                    <span class="badge <?= $b['subscription_status'] === 'active' ? 'badge-success' : 'badge-warning' ?>">
                                        <?= e(ucwords(str_replace('_', ' ', $b['subscription_status']))) ?>
                                    </span>
                                    <?php if (!empty($b['subscription_period_end'])): ?>
                                        <div class="text-xs text-muted"><?= e(date('M j, Y', strtotime($b['subscription_period_end']))) ?></div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="badge badge-info">Not set up</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-xs"><?= e($b['phone'] ?: '—') ?></td>
                            <td style="text-align: center; font-weight: 600;"><?= number_format($b['member_count']) ?></td>
                            <td style="text-align: center; font-weight: 600;"><?= number_format($b['tx_count']) ?></td>
                            <td>
                                <?php if ($b['status'] === 'active'): ?>
                                    <span class="badge badge-success">Active</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Suspended</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <form action="<?= url('admin/businesses/' . $b['id'] . '/toggle') ?>" method="POST" onsubmit="return confirm('Change status for this tenant?');" style="display: inline;">
                                    <?= csrf_field() ?>
                                    <?php if ($b['status'] === 'active'): ?>
                                        <button type="submit" class="btn btn-secondary btn-sm" style="color: var(--danger); padding: 0.25rem 0.5rem;" title="Suspend Tenant">
                                            <i data-lucide="pause-circle" style="width: 14px; height: 14px;"></i>
                                            <span>Suspend</span>
                                        </button>
                                    <?php else: ?>
                                        <button type="submit" class="btn btn-primary btn-sm" style="padding: 0.25rem 0.5rem;" title="Activate Tenant">
                                            <i data-lucide="play-circle" style="width: 14px; height: 14px;"></i>
                                            <span>Activate</span>
                                        </button>
                                    <?php endif; ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                <tr id="businessNoResults" hidden>
                    <td colspan="10" style="text-align: center; padding: 2rem; color: var(--text-muted);">No businesses match your search.</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script>
    (() => {
        const search = document.getElementById('businessSearch');
        const status = document.getElementById('businessStatusFilter');
        const resultCount = document.getElementById('businessResultCount');
        const noResults = document.getElementById('businessNoResults');
        const rows = Array.from(document.querySelectorAll('.business-row'));

        const filterBusinesses = () => {
            const query = search.value.trim().toLocaleLowerCase();
            const selectedStatus = status.value;
            let visible = 0;

            rows.forEach((row) => {
                const matches = row.dataset.search.toLocaleLowerCase().includes(query)
                    && (!selectedStatus || row.dataset.status === selectedStatus);
                row.hidden = !matches;
                if (matches) visible++;
            });

            noResults.hidden = visible > 0 || rows.length === 0;
            resultCount.textContent = `${visible} of ${rows.length} businesses`;
        };

        search.addEventListener('input', filterBusinesses);
        status.addEventListener('change', filterBusinesses);
        filterBusinesses();
    })();
</script>
