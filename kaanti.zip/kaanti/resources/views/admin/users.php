<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.25rem;">
            <a href="<?= url('admin') ?>" class="text-sm text-muted">Admin</a>
            <span class="text-muted">/</span>
            <h1 style="font-size: 1.5rem; color: var(--text-main); margin: 0;">Users Directory</h1>
        </div>
        <p class="text-sm text-muted">Platform users, roles, email verification status, and tenant affiliations.</p>
    </div>

    <a href="<?= url('admin') ?>" class="btn btn-secondary btn-sm">
        <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
        <span>Back to Admin</span>
    </a>
</div>

<div class="card">
    <div class="table-container" style="border: none;">
        <table class="table">
            <thead>
                <tr>
                    <th>Full Name</th>
                    <th>Email Address</th>
                    <th>Phone</th>
                    <th>Role Privilege</th>
                    <th style="text-align: center;">Tenants</th>
                    <th>Status</th>
                    <th>Registered</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 2rem; color: var(--text-muted);">No users found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users as $u): ?>
                        <tr>
                            <td class="font-bold">
                                <?= e($u['first_name'] . ' ' . $u['last_name']) ?>
                            </td>
                            <td>
                                <code><?= e($u['email']) ?></code>
                            </td>
                            <td class="text-xs"><?= e($u['phone'] ?: '—') ?></td>
                            <td>
                                <?php if ($u['is_super_admin']): ?>
                                    <span class="badge badge-danger">Super Admin</span>
                                <?php else: ?>
                                    <span class="badge badge-info">Business User</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center; font-weight: 600;">
                                <?= number_format($u['business_count']) ?>
                            </td>
                            <td>
                                <span class="badge badge-success"><?= e(ucfirst($u['status'])) ?></span>
                            </td>
                            <td class="text-xs text-muted"><?= format_date($u['created_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
