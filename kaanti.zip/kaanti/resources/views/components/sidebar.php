<?php
use App\Core\Session;
$userName = Session::get('user_name', 'Business Owner');
$isSuperAdmin = (bool) Session::get('is_super_admin');
$businessName = $isSuperAdmin
    ? 'Platform Control Center'
    : Session::get('business_name', 'Kaanti Business');
$userRole = $isSuperAdmin ? 'Super Admin' : ucfirst(Session::get('business_role', 'owner'));
$initials = strtoupper(substr($userName, 0, 1));
$isAdminHome = is_active('admin')
    && !is_active('admin/businesses')
    && !is_active('admin/users')
    && !is_active('admin/audit');
?>
<!-- Sidebar Navigation -->
<aside class="sidebar" id="appSidebar">
    <div class="sidebar-header">
        <img src="<?= asset('images/logo.jpeg') ?>" alt="Kaanti Logo" class="sidebar-logo-img">
        <div>
            <div class="sidebar-brand-name">Kaanti</div>
            <div class="sidebar-brand-tagline">Manage. Grow. Prosper.</div>
        </div>
    </div>

    <nav class="sidebar-nav">
        <?php if ($isSuperAdmin): ?>
            <div class="nav-section-label">Platform Administration</div>
            <a href="<?= url('admin') ?>" class="nav-link <?= $isAdminHome ? 'active' : '' ?>">
                <i data-lucide="layout-dashboard"></i>
                <span>Admin Dashboard</span>
            </a>
            <a href="<?= url('admin/businesses') ?>" class="nav-link <?= active_class('admin/businesses') ?>">
                <i data-lucide="store"></i>
                <span>All Businesses</span>
            </a>
            <a href="<?= url('admin/users') ?>" class="nav-link <?= active_class('admin/users') ?>">
                <i data-lucide="users"></i>
                <span>User Accounts</span>
            </a>
            <a href="<?= url('admin/audit') ?>" class="nav-link <?= active_class('admin/audit') ?>">
                <i data-lucide="shield-check"></i>
                <span>Audit Trail</span>
            </a>
        <?php else: ?>
            <div class="nav-section-label">Main Menu</div>
            <a href="<?= url('dashboard') ?>" class="nav-link <?= active_class('dashboard') ?>">
                <i data-lucide="layout-dashboard"></i>
                <span>Dashboard</span>
            </a>

            <div class="nav-section-label">Financials & Operations</div>
            <a href="<?= url('transactions') ?>" class="nav-link <?= active_class('transactions') ?>">
                <i data-lucide="arrow-left-right"></i>
                <span>Transactions</span>
            </a>
            <a href="<?= url('income') ?>" class="nav-link <?= active_class('income') ?>">
                <i data-lucide="trending-up"></i>
                <span>Income</span>
            </a>
            <a href="<?= url('expenses') ?>" class="nav-link <?= active_class('expenses') ?>">
                <i data-lucide="trending-down"></i>
                <span>Expenses</span>
            </a>
            <a href="<?= url('inventory') ?>" class="nav-link <?= active_class('inventory') ?>">
                <i data-lucide="package"></i>
                <span>Inventory</span>
            </a>
            <a href="<?= url('sales') ?>" class="nav-link <?= active_class('sales') ?>">
                <i data-lucide="shopping-cart"></i>
                <span>Sales & Profit</span>
            </a>
            <a href="<?= url('customers') ?>" class="nav-link <?= active_class('customers') ?>">
                <i data-lucide="users"></i>
                <span>Customers</span>
            </a>
            <a href="<?= url('reports') ?>" class="nav-link <?= active_class('reports') ?>">
                <i data-lucide="bar-chart-3"></i>
                <span>Reports & PDF</span>
            </a>
            <?php if (Session::get('business_role') === 'owner'): ?>
                <a href="<?= url('subscription') ?>" class="nav-link <?= active_class('subscription') ?>">
                    <i data-lucide="credit-card"></i>
                    <span>Subscription</span>
                </a>
            <?php endif; ?>

            <div class="nav-section-label">Growth & Discovery</div>
            <a href="<?= url('financing') ?>" class="nav-link <?= active_class('financing') ?>">
                <i data-lucide="landmark"></i>
                <span>Financing Discovery</span>
            </a>
            <a href="<?= url('investments') ?>" class="nav-link <?= active_class('investments') ?>">
                <i data-lucide="piggy-bank"></i>
                <span>Investments</span>
            </a>
            <a href="<?= url('learning') ?>" class="nav-link <?= active_class('learning') ?>">
                <i data-lucide="book-open"></i>
                <span>Kaanti Learn</span>
            </a>
        <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
        <div class="user-snippet">
            <div class="user-avatar-placeholder">
                <?= e($initials) ?>
            </div>
            <div style="flex: 1; min-width: 0;">
                <div class="text-sm font-semibold truncate" style="color: #FFFFFF;">
                    <?= e($userName) ?>
                </div>
                <div class="text-xs truncate" style="color: rgba(255,255,255,0.65);">
                    <?= e($businessName) ?> (<?= e($userRole) ?>)
                </div>
            </div>
            <a href="<?= url('logout') ?>" title="Sign Out" style="color: rgba(255,255,255,0.7); padding: 0.35rem; display: flex;" aria-label="Sign out">
                <i data-lucide="log-out" style="width: 18px; height: 18px;"></i>
            </a>
        </div>
    </div>
</aside>
