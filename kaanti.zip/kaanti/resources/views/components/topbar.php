<?php
use App\Core\Session;
$isSuperAdmin = (bool) Session::get('is_super_admin');
$businessName = $isSuperAdmin ? 'Platform Control Center' : Session::get('business_name', 'My Business');
$businessRole = $isSuperAdmin ? 'Super Admin' : ucfirst(Session::get('business_role', 'owner'));
?>
<!-- Top Navigation Bar -->
<header class="topbar">
    <div class="topbar-left">
        <button type="button" class="hamburger-btn" id="hamburgerBtn" aria-label="Toggle navigation drawer">
            <i data-lucide="menu" style="width: 22px; height: 22px;"></i>
        </button>

        <div class="business-pill">
            <i data-lucide="store" style="width: 16px; height: 16px; color: var(--primary);"></i>
            <span class="truncate" style="max-width: 200px;"><?= e($businessName) ?></span>
            <span class="role-tag"><?= e($businessRole) ?></span>
        </div>
    </div>

    <div class="topbar-right">
        <div style="font-size: 0.82rem; color: var(--text-muted); display: flex; align-items: center; gap: 0.4rem;">
            <i data-lucide="calendar" style="width: 15px; height: 15px;"></i>
            <span><?= date('D, j M Y') ?></span>
        </div>
        <a href="<?= url('logout') ?>" class="btn btn-secondary btn-sm" style="display: inline-flex; gap: 0.4rem;">
            <i data-lucide="log-out" style="width: 15px; height: 15px;"></i>
            <span>Logout</span>
        </a>
    </div>
</header>
