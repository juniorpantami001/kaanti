<?php
/**
 * Flash Alert Component
 * Renders session flash notices and error messages with auto-dismiss.
 */
?>
<?php if (!empty($flash)): ?>
    <?php foreach ($flash as $f): ?>
        <?php 
            $type = $f['type'] ?? 'info';
            $alertClass = match($type) {
                'success' => 'alert-success',
                'error', 'danger' => 'alert-danger',
                'warning' => 'alert-warning',
                default => 'alert-info',
            };
            $icon = match($type) {
                'success' => 'check-circle-2',
                'error', 'danger' => 'alert-circle',
                'warning' => 'alert-triangle',
                default => 'info',
            };
        ?>
        <div class="alert <?= $alertClass ?>" role="alert">
            <i data-lucide="<?= $icon ?>" style="width:20px;height:20px;flex-shrink:0;"></i>
            <div style="flex:1;">
                <?= $f['message'] ?>
            </div>
            <button type="button" class="alert-dismiss" aria-label="Close notification">
                <i data-lucide="x" style="width:16px;height:16px;"></i>
            </button>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
