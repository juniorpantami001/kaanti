<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.5rem; color: var(--text-main); margin-bottom: 0.25rem;">Sales & Product Performance</h1>
        <p class="text-sm text-muted">Track product sales, gross profit, and your best-selling items.</p>
    </div>
    <a href="<?= url('sales/create') ?>" class="btn btn-primary btn-sm">
        <i data-lucide="shopping-cart" style="width: 16px; height: 16px;"></i>
        <span>Record Sale</span>
    </a>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div>
            <div class="stat-title">Sales Revenue</div>
            <div class="stat-value" style="color: var(--primary);"><?= format_naira($summary['revenue']) ?></div>
            <div class="stat-subtext">From active product sales</div>
        </div>
        <div class="stat-icon-box icon-box-green"><i data-lucide="trending-up" style="width: 22px; height: 22px;"></i></div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-title">Gross Sales Profit</div>
            <div class="stat-value" style="color: <?= (float) $summary['gross_profit'] >= 0 ? 'var(--primary)' : 'var(--danger)' ?>;">
                <?= format_naira($summary['gross_profit']) ?>
            </div>
            <div class="stat-subtext">Revenue less sale-time product cost</div>
        </div>
        <div class="stat-icon-box icon-box-blue"><i data-lucide="badge-dollar-sign" style="width: 22px; height: 22px;"></i></div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-title">Products Sold</div>
            <div class="stat-value"><?= number_format((int) $summary['units_sold']) ?></div>
            <div class="stat-subtext">Units in active sales</div>
        </div>
        <div class="stat-icon-box icon-box-gold"><i data-lucide="package-check" style="width: 22px; height: 22px;"></i></div>
    </div>
    <div class="stat-card">
        <div>
            <div class="stat-title">Completed Sales</div>
            <div class="stat-value"><?= number_format((int) $summary['sale_count']) ?></div>
            <div class="stat-subtext">Voided sales excluded</div>
        </div>
        <div class="stat-icon-box icon-box-green"><i data-lucide="receipt" style="width: 22px; height: 22px;"></i></div>
    </div>
</div>

<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-header">
        <div class="card-title" style="display: flex; align-items: center; gap: 0.5rem;">
            <i data-lucide="trophy" style="width: 18px; height: 18px; color: var(--primary);"></i>
            <span>Best-Selling Products</span>
        </div>
        <span class="text-xs text-muted">Ranked by units sold</span>
    </div>
    <?php if (empty($topProducts)): ?>
        <div class="empty-state">
            <div class="empty-state-icon"><i data-lucide="shopping-bag" style="width: 30px; height: 30px;"></i></div>
            <div class="empty-state-title">No product sales yet</div>
            <div class="empty-state-desc">Record a sale to see your most popular products, sales revenue, and gross profit here.</div>
            <a href="<?= url('sales/create') ?>" class="btn btn-primary">Record your first sale</a>
        </div>
    <?php else: ?>
        <div class="table-container" style="border: none;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Product</th>
                        <th style="text-align: right;">Units Sold</th>
                        <th style="text-align: right;">Sales Revenue</th>
                        <th style="text-align: right;">Gross Profit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($topProducts as $index => $product): ?>
                        <tr>
                            <td><span class="badge <?= $index === 0 ? 'badge-success' : 'badge-secondary' ?>">#<?= $index + 1 ?></span></td>
                            <td class="font-medium">
                                <?= e($product['product_name']) ?>
                                <?php if (!empty($product['sku'])): ?><div class="text-xs text-muted"><?= e($product['sku']) ?></div><?php endif; ?>
                            </td>
                            <td style="text-align: right; font-weight: 700;"><?= number_format((int) $product['units_sold']) ?></td>
                            <td style="text-align: right;"><?= format_naira($product['revenue']) ?></td>
                            <td style="text-align: right; font-weight: 600; color: <?= (float) $product['gross_profit'] >= 0 ? 'var(--primary)' : 'var(--danger)' ?>;">
                                <?= format_naira($product['gross_profit']) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-header">
        <div class="card-title" style="display: flex; align-items: center; gap: 0.5rem;">
            <i data-lucide="clock-3" style="width: 18px; height: 18px; color: var(--primary);"></i>
            <span>Recent Sales</span>
        </div>
        <span class="text-xs text-muted">Latest 20</span>
    </div>
    <?php if (empty($recentSales)): ?>
        <div class="empty-state">
            <div class="empty-state-title">No sales recorded</div>
            <div class="empty-state-desc">Your completed product sales will appear here.</div>
        </div>
    <?php else: ?>
        <div class="table-container" style="border: none;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Date / Receipt</th>
                        <th>Customer</th>
                        <th style="text-align: right;">Units</th>
                        <th style="text-align: right;">Revenue</th>
                        <th style="text-align: right;">Gross Profit</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentSales as $sale): ?>
                        <tr>
                            <td>
                                <a href="<?= url('transactions/' . $sale['id']) ?>" class="font-medium text-primary"><?= e($sale['reference_number']) ?></a>
                                <div class="text-xs text-muted"><?= format_date($sale['transaction_date']) ?></div>
                            </td>
                            <td><?= e($sale['customer_name'] ?: 'Walk-in') ?></td>
                            <td style="text-align: right;"><?= number_format((int) $sale['units_sold']) ?></td>
                            <td style="text-align: right;"><?= format_naira($sale['amount']) ?></td>
                            <td style="text-align: right;"><?= format_naira($sale['gross_profit']) ?></td>
                            <td>
                                <span class="badge badge-<?= $sale['status'] === 'active' ? 'success' : 'danger' ?>">
                                    <?= e(ucfirst($sale['status'])) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
