<div style="max-width: 900px; margin: 0 auto;">
    <div style="margin-bottom: 1.5rem;">
        <a href="<?= url('sales') ?>" class="text-sm text-muted" style="display: inline-flex; align-items: center; gap: 0.35rem; margin-bottom: 0.5rem;">
            <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
            <span>Back to sales</span>
        </a>
        <h1 style="font-size: 1.6rem; color: var(--text-main);">Record a Product Sale</h1>
        <p class="text-sm text-muted">Stock will be checked and reduced when the sale is saved.</p>
    </div>

    <?php if (empty($products)): ?>
        <div class="card">
            <div class="empty-state">
                <div class="empty-state-icon"><i data-lucide="package-x" style="width: 30px; height: 30px;"></i></div>
                <div class="empty-state-title">No products available to sell</div>
                <div class="empty-state-desc">Add active inventory products with stock before recording a sale.</div>
                <a href="<?= url('inventory/create') ?>" class="btn btn-primary">Add a product</a>
            </div>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-body" style="padding: 1.5rem;">
                <form action="<?= url('sales') ?>" method="POST" id="saleForm">
                    <?= csrf_field() ?>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="transaction_date" class="form-label required">Sale Date</label>
                            <input type="date" name="transaction_date" id="transaction_date" class="form-control" value="<?= e(old('transaction_date', date('Y-m-d'))) ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="payment_method" class="form-label required">Payment Method</label>
                            <select name="payment_method" id="payment_method" class="form-control" required>
                                <?php foreach (['Cash', 'Bank Transfer', 'POS', 'Mobile Money', 'Cheque'] as $method): ?>
                                    <option value="<?= e($method) ?>"><?= e($method) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="customer_id" class="form-label">Customer (Optional)</label>
                            <select name="customer_id" id="customer_id" class="form-control">
                                <option value="">Walk-in customer</option>
                                <?php foreach ($customers as $customer): ?>
                                    <option value="<?= e($customer['id']) ?>"><?= e($customer['name']) ?><?= !empty($customer['phone']) ? ' (' . e($customer['phone']) . ')' : '' ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div style="display: flex; justify-content: space-between; align-items: center; gap: 1rem; margin: 1.5rem 0 0.75rem;">
                        <h2 class="text-lg font-semibold">Products</h2>
                        <button type="button" id="addSaleLine" class="btn btn-secondary btn-sm">
                            <i data-lucide="plus" style="width: 15px; height: 15px;"></i>
                            <span>Add Product</span>
                        </button>
                    </div>
                    <div id="saleLines" aria-live="polite"></div>
                    <div id="saleFormMessage" class="form-error" role="alert" style="display: none; margin-top: 0.5rem;"></div>

                    <div style="display: flex; justify-content: flex-end; padding: 1rem 0; border-top: 1px solid var(--border); margin-top: 1rem;">
                        <div style="text-align: right;">
                            <div class="text-xs text-muted uppercase">Sale Total</div>
                            <div id="saleTotal" class="text-lg font-bold" aria-live="polite"><?= format_naira(0) ?></div>
                        </div>
                    </div>

                    <div style="display: flex; justify-content: flex-end; gap: 0.75rem;">
                        <a href="<?= url('sales') ?>" class="btn btn-secondary">Cancel</a>
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i data-lucide="check-circle" style="width: 18px; height: 18px;"></i>
                            <span>Complete Sale</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <template id="saleLineTemplate">
            <div class="sale-line" style="display: grid; grid-template-columns: minmax(200px, 2fr) minmax(100px, 0.7fr) minmax(130px, 1fr) auto; gap: 0.75rem; align-items: end; padding: 0.9rem 0; border-bottom: 1px solid var(--border);">
                <div class="form-group sale-product-field" style="margin-bottom: 0;">
                    <label class="form-label" for="sale-product-__INDEX__">Product</label>
                    <select class="form-control sale-product" id="sale-product-__INDEX__" name="items[__INDEX__][product_id]" required>
                        <option value="">Choose product</option>
                        <?php foreach ($products as $product): ?>
                            <option value="<?= e($product['id']) ?>" data-price="<?= e($product['selling_price']) ?>" data-stock="<?= (int) $product['quantity'] ?>">
                                <?= e($product['name']) ?><?= !empty($product['sku']) ? ' (' . e($product['sku']) . ')' : '' ?> — <?= (int) $product['quantity'] ?> available
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text sale-stock"></div>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" for="sale-quantity-__INDEX__">Quantity</label>
                    <input type="number" class="form-control sale-quantity" id="sale-quantity-__INDEX__" name="items[__INDEX__][quantity]" min="1" value="1" required>
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" for="sale-price-__INDEX__">Unit Price (₦)</label>
                    <input type="number" class="form-control sale-price" id="sale-price-__INDEX__" name="items[__INDEX__][unit_price]" min="0" step="0.01" required>
                </div>
                <button type="button" class="btn btn-secondary sale-remove" aria-label="Remove this product line" title="Remove product">
                    <i data-lucide="trash-2" style="width: 16px; height: 16px;"></i>
                </button>
            </div>
        </template>

        <script>
        document.addEventListener('DOMContentLoaded', function () {
            const form = document.getElementById('saleForm');
            const lines = document.getElementById('saleLines');
            const template = document.getElementById('saleLineTemplate');
            const total = document.getElementById('saleTotal');
            const message = document.getElementById('saleFormMessage');
            let nextIndex = 0;

            function updateTotal() {
                let amount = 0;
                lines.querySelectorAll('.sale-line').forEach(function (line) {
                    amount += (Number(line.querySelector('.sale-quantity').value) || 0)
                        * (Number(line.querySelector('.sale-price').value) || 0);
                });
                total.textContent = new Intl.NumberFormat('en-NG', {
                    style: 'currency',
                    currency: 'NGN',
                    minimumFractionDigits: 2
                }).format(amount);
            }

            function addLine() {
                const fragment = template.content.cloneNode(true);
                const row = fragment.querySelector('.sale-line');
                row.querySelectorAll('[name]').forEach(function (field) {
                    field.name = field.name.replace('__INDEX__', String(nextIndex));
                });
                row.querySelectorAll('[id], label[for]').forEach(function (element) {
                    if (element.id) element.id = element.id.replace('__INDEX__', String(nextIndex));
                    if (element.htmlFor) element.htmlFor = element.htmlFor.replace('__INDEX__', String(nextIndex));
                });
                nextIndex += 1;
                lines.appendChild(fragment);
            }

            lines.addEventListener('change', function (event) {
                if (!event.target.classList.contains('sale-product')) return;
                const row = event.target.closest('.sale-line');
                const option = event.target.selectedOptions[0];
                const stock = option.dataset.stock || '';
                row.querySelector('.sale-price').value = option.dataset.price || '';
                row.querySelector('.sale-quantity').max = stock;
                row.querySelector('.sale-stock').textContent = stock ? stock + ' units available' : '';
                updateTotal();
            });
            lines.addEventListener('input', updateTotal);
            lines.addEventListener('click', function (event) {
                const button = event.target.closest('.sale-remove');
                if (button && lines.querySelectorAll('.sale-line').length > 1) {
                    button.closest('.sale-line').remove();
                    updateTotal();
                }
            });
            form.addEventListener('submit', function (event) {
                const selected = Array.from(lines.querySelectorAll('.sale-product'))
                    .map(function (select) { return select.value; })
                    .filter(Boolean);
                if (new Set(selected).size !== selected.length) {
                    event.preventDefault();
                    message.textContent = 'A product can only be listed once. Change its quantity on the existing line.';
                    message.style.display = 'block';
                    return;
                }
                message.style.display = 'none';
            });

            document.getElementById('addSaleLine').addEventListener('click', addLine);
            addLine();
            if (window.lucide) window.lucide.createIcons();
        });
        </script>
    <?php endif; ?>
</div>
