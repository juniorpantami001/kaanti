<div class="auth-header">
    <span class="badge badge-success" style="margin-bottom: 0.5rem;">Step 2 of 2: Onboarding</span>
    <h1>Set up your business</h1>
    <p>Tell us about your enterprise so we can calibrate your accounts and categories.</p>
</div>

<?php if (!empty($existing)): ?>
    <div class="card" style="margin-bottom: 1.5rem; background: var(--primary-subtle); border-color: rgba(46,125,50,0.25);">
        <div class="card-body" style="padding: 1rem;">
            <div class="text-sm font-semibold text-primary" style="margin-bottom: 0.5rem;">
                You already belong to an active business:
            </div>
            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                <?php foreach ($existing as $b): ?>
                    <div style="display: flex; justify-content: space-between; align-items: center; background: #fff; padding: 0.6rem 0.85rem; border-radius: var(--radius-sm); border: 1px solid var(--border);">
                        <div>
                            <strong><?= e($b['name']) ?></strong> 
                            <span class="text-xs text-muted">(<?= e(ucfirst($b['role'])) ?>)</span>
                        </div>
                        <a href="<?= url('dashboard') ?>" class="btn btn-primary btn-sm">
                            Open Dashboard
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<form action="<?= url('onboarding') ?>" method="POST" novalidate>
    <?= csrf_field() ?>

    <div class="form-group">
        <label for="name" class="form-label required">Business or Trading Name</label>
        <input 
            type="text" 
            name="name" 
            id="name" 
            class="form-control <?= has_error($errors, 'name') ? 'is-invalid' : '' ?>" 
            value="<?= e(old('name')) ?>" 
            placeholder="e.g. Al-Barakah Textile Stores" 
            required 
            autofocus
        >
        <?php foreach (field_errors($errors, 'name') as $err): ?>
            <div class="form-error"><?= e($err) ?></div>
        <?php endforeach; ?>
    </div>

    <div class="form-row">
        <div class="form-group">
            <label for="type" class="form-label required">Business Type</label>
            <select name="type" id="type" class="form-control <?= has_error($errors, 'type') ? 'is-invalid' : '' ?>" required>
                <option value="">Select enterprise type...</option>
                <option value="Market Trader" <?= old('type') === 'Market Trader' ? 'selected' : '' ?>>Market Trader / Mai Shago</option>
                <option value="Retail Store" <?= old('type') === 'Retail Store' ? 'selected' : '' ?>>Retail Store</option>
                <option value="Wholesale Distributor" <?= old('type') === 'Wholesale Distributor' ? 'selected' : '' ?>>Wholesale Distributor</option>
                <option value="Shop Owner" <?= old('type') === 'Shop Owner' ? 'selected' : '' ?>>Shop Owner</option>
                <option value="Agro-Allied & Grains" <?= old('type') === 'Agro-Allied & Grains' ? 'selected' : '' ?>>Agro-Allied & Grains Trading</option>
                <option value="Services & Artisans" <?= old('type') === 'Services & Artisans' ? 'selected' : '' ?>>Services & Artisans</option>
                <option value="Food & Restaurant" <?= old('type') === 'Food & Restaurant' ? 'selected' : '' ?>>Food & Restaurant</option>
                <option value="Fashion & Tailoring" <?= old('type') === 'Fashion & Tailoring' ? 'selected' : '' ?>>Fashion & Tailoring</option>
                <option value="Manufacturing & Crafts" <?= old('type') === 'Manufacturing & Crafts' ? 'selected' : '' ?>>Manufacturing & Crafts</option>
                <option value="Other" <?= old('type') === 'Other' ? 'selected' : '' ?>>Other SME</option>
            </select>
            <?php foreach (field_errors($errors, 'type') as $err): ?>
                <div class="form-error"><?= e($err) ?></div>
            <?php endforeach; ?>
        </div>

        <div class="form-group">
            <label for="category" class="form-label">Trade Sector / Category</label>
            <input 
                type="text" 
                name="category" 
                id="category" 
                class="form-control" 
                value="<?= e(old('category')) ?>" 
                placeholder="e.g. Textiles, Provisions, Grains"
            >
        </div>
    </div>

    <div class="form-row">
        <div class="form-group">
            <label for="state" class="form-label required">Operating State</label>
            <select name="state" id="state" class="form-control <?= has_error($errors, 'state') ? 'is-invalid' : '' ?>" required>
                <option value="">Choose state...</option>
                <optgroup label="Northern Nigeria">
                    <option value="Kano" <?= old('state') === 'Kano' ? 'selected' : '' ?>>Kano</option>
                    <option value="Kaduna" <?= old('state') === 'Kaduna' ? 'selected' : '' ?>>Kaduna</option>
                    <option value="Katsina" <?= old('state') === 'Katsina' ? 'selected' : '' ?>>Katsina</option>
                    <option value="Sokoto" <?= old('state') === 'Sokoto' ? 'selected' : '' ?>>Sokoto</option>
                    <option value="Borno" <?= old('state') === 'Borno' ? 'selected' : '' ?>>Borno</option>
                    <option value="Bauchi" <?= old('state') === 'Bauchi' ? 'selected' : '' ?>>Bauchi</option>
                    <option value="Jigawa" <?= old('state') === 'Jigawa' ? 'selected' : '' ?>>Jigawa</option>
                    <option value="Kebbi" <?= old('state') === 'Kebbi' ? 'selected' : '' ?>>Kebbi</option>
                    <option value="Niger" <?= old('state') === 'Niger' ? 'selected' : '' ?>>Niger</option>
                    <option value="Zamfara" <?= old('state') === 'Zamfara' ? 'selected' : '' ?>>Zamfara</option>
                    <option value="Gombe" <?= old('state') === 'Gombe' ? 'selected' : '' ?>>Gombe</option>
                    <option value="Adamawa" <?= old('state') === 'Adamawa' ? 'selected' : '' ?>>Adamawa</option>
                    <option value="Taraba" <?= old('state') === 'Taraba' ? 'selected' : '' ?>>Taraba</option>
                    <option value="Yobe" <?= old('state') === 'Yobe' ? 'selected' : '' ?>>Yobe</option>
                    <option value="Plateau" <?= old('state') === 'Plateau' ? 'selected' : '' ?>>Plateau</option>
                    <option value="Nasarawa" <?= old('state') === 'Nasarawa' ? 'selected' : '' ?>>Nasarawa</option>
                    <option value="Benue" <?= old('state') === 'Benue' ? 'selected' : '' ?>>Benue</option>
                    <option value="Abuja FCT" <?= old('state') === 'Abuja FCT' ? 'selected' : '' ?>>Abuja FCT</option>
                </optgroup>
                <optgroup label="Other States">
                    <option value="Lagos" <?= old('state') === 'Lagos' ? 'selected' : '' ?>>Lagos</option>
                    <option value="Oyo" <?= old('state') === 'Oyo' ? 'selected' : '' ?>>Oyo</option>
                    <option value="Rivers" <?= old('state') === 'Rivers' ? 'selected' : '' ?>>Rivers</option>
                    <option value="Enugu" <?= old('state') === 'Enugu' ? 'selected' : '' ?>>Enugu</option>
                    <option value="Other" <?= old('state') === 'Other' ? 'selected' : '' ?>>Other State</option>
                </optgroup>
            </select>
            <?php foreach (field_errors($errors, 'state') as $err): ?>
                <div class="form-error"><?= e($err) ?></div>
            <?php endforeach; ?>
        </div>

        <div class="form-group">
            <label for="phone" class="form-label required">Business Phone</label>
            <input 
                type="tel" 
                name="phone" 
                id="phone" 
                class="form-control <?= has_error($errors, 'phone') ? 'is-invalid' : '' ?>" 
                value="<?= e(old('phone', \App\Core\Session::get('user_phone', ''))) ?>" 
                placeholder="08031234567" 
                required
            >
            <?php foreach (field_errors($errors, 'phone') as $err): ?>
                <div class="form-error"><?= e($err) ?></div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="form-group">
        <label for="location" class="form-label required">Shop / Market Address</label>
        <input 
            type="text" 
            name="location" 
            id="location" 
            class="form-control <?= has_error($errors, 'location') ? 'is-invalid' : '' ?>" 
            value="<?= e(old('location')) ?>" 
            placeholder="e.g. Shop 42, Kurmi Market, Kano City" 
            required
        >
        <?php foreach (field_errors($errors, 'location') as $err): ?>
            <div class="form-error"><?= e($err) ?></div>
        <?php endforeach; ?>
    </div>

    <div class="form-row">
        <div class="form-group">
            <label for="currency" class="form-label required">Default Currency</label>
            <select name="currency" id="currency" class="form-control" required>
                <option value="NGN" selected>Nigerian Naira (₦)</option>
            </select>
        </div>

        <div class="form-group">
            <label for="language" class="form-label required">Preferred Language</label>
            <select name="language" id="language" class="form-control" required>
                <option value="en" <?= old('language') === 'en' ? 'selected' : '' ?>>English</option>
                <option value="ha" <?= old('language') === 'ha' ? 'selected' : '' ?>>Hausa (Harshen Hausa)</option>
            </select>
        </div>
    </div>

    <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 1.5rem;">
        <span>Launch My Business Dashboard</span>
        <i data-lucide="rocket" style="width: 18px; height: 18px;"></i>
    </button>
</form>
