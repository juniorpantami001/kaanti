<div class="auth-header">
    <h1>Create your account</h1>
    <p>Join thousands of growing SMEs managing operations with Kaanti.</p>
</div>

<form action="<?= url('register') ?>" method="POST" novalidate>
    <?= csrf_field() ?>

    <div class="form-row">
        <div class="form-group">
            <label for="first_name" class="form-label required">First Name</label>
            <input 
                type="text" 
                name="first_name" 
                id="first_name" 
                class="form-control <?= has_error($errors, 'first_name') ? 'is-invalid' : '' ?>" 
                value="<?= e(old('first_name')) ?>" 
                placeholder="Aminu" 
                required
            >
            <?php foreach (field_errors($errors, 'first_name') as $err): ?>
                <div class="form-error"><?= e($err) ?></div>
            <?php endforeach; ?>
        </div>

        <div class="form-group">
            <label for="last_name" class="form-label required">Last Name</label>
            <input 
                type="text" 
                name="last_name" 
                id="last_name" 
                class="form-control <?= has_error($errors, 'last_name') ? 'is-invalid' : '' ?>" 
                value="<?= e(old('last_name')) ?>" 
                placeholder="Bello" 
                required
            >
            <?php foreach (field_errors($errors, 'last_name') as $err): ?>
                <div class="form-error"><?= e($err) ?></div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="form-group">
        <label for="email" class="form-label required">Email Address</label>
        <input 
            type="email" 
            name="email" 
            id="email" 
            class="form-control <?= has_error($errors, 'email') ? 'is-invalid' : '' ?>" 
            value="<?= e(old('email')) ?>" 
            placeholder="aminu.bello@example.com" 
            required
        >
        <?php foreach (field_errors($errors, 'email') as $err): ?>
            <div class="form-error"><?= e($err) ?></div>
        <?php endforeach; ?>
    </div>

    <div class="form-group">
        <label for="phone" class="form-label required">Phone Number</label>
        <input 
            type="tel" 
            name="phone" 
            id="phone" 
            class="form-control <?= has_error($errors, 'phone') ? 'is-invalid' : '' ?>" 
            value="<?= e(old('phone')) ?>" 
            placeholder="08031234567" 
            required
        >
        <div class="form-text">Used for important notifications and two-factor verifications.</div>
        <?php foreach (field_errors($errors, 'phone') as $err): ?>
            <div class="form-error"><?= e($err) ?></div>
        <?php endforeach; ?>
    </div>

    <div class="form-group">
        <label for="reg_password" class="form-label required">Password</label>
        <div class="input-group">
            <input 
                type="password" 
                name="password" 
                id="reg_password" 
                class="form-control <?= has_error($errors, 'password') ? 'is-invalid' : '' ?>" 
                placeholder="Minimum 8 characters" 
                required
            >
            <button type="button" class="input-group-addon-btn toggle-password-btn" data-target="reg_password" aria-label="Toggle password view">
                <i data-lucide="eye" style="width: 18px; height: 18px;"></i>
            </button>
        </div>
        <div class="password-strength-bar">
            <div class="password-strength-fill" id="password_strength_fill"></div>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 0.25rem;">
            <span class="text-xs text-muted">Use uppercase, numbers & symbols</span>
            <span class="text-xs font-semibold" id="password_strength_text"></span>
        </div>
        <?php foreach (field_errors($errors, 'password') as $err): ?>
            <div class="form-error"><?= e($err) ?></div>
        <?php endforeach; ?>
    </div>

    <div class="form-group">
        <label for="password_confirmation" class="form-label required">Confirm Password</label>
        <div class="input-group">
            <input 
                type="password" 
                name="password_confirmation" 
                id="password_confirmation" 
                class="form-control" 
                placeholder="Re-enter password" 
                required
            >
            <button type="button" class="input-group-addon-btn toggle-password-btn" data-target="password_confirmation" aria-label="Toggle password view">
                <i data-lucide="eye" style="width: 18px; height: 18px;"></i>
            </button>
        </div>
    </div>

    <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1.25rem;">
        By creating an account, you agree to Kaanti's 
        <a href="#" style="text-decoration: underline;">Terms of Service</a> and 
        <a href="#" style="text-decoration: underline;">Privacy Policy</a>.
    </div>

    <button type="submit" class="btn btn-primary btn-block btn-lg">
        <span>Create My Free Account</span>
        <i data-lucide="arrow-right" style="width: 18px; height: 18px;"></i>
    </button>
</form>

<div class="auth-footer-links">
    Already registered on Kaanti?
    <a href="<?= url('login') ?>" style="font-weight: 600; color: var(--primary);">
        Sign in here
    </a>
</div>
