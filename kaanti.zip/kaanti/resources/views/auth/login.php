<div class="auth-header">
    <h1>Welcome back</h1>
    <p>Sign in to your Kaanti Manager account to manage your business.</p>
</div>

<form action="<?= url('login') ?>" method="POST" novalidate>
    <?= csrf_field() ?>

    <div class="form-group">
        <label for="email" class="form-label required">Email address</label>
        <input 
            type="email" 
            name="email" 
            id="email" 
            class="form-control <?= has_error($errors, 'email') ? 'is-invalid' : '' ?>" 
            value="<?= e(old('email')) ?>" 
            placeholder="trader@kaanti.com" 
            required 
            autofocus
        >
        <?php foreach (field_errors($errors, 'email') as $err): ?>
            <div class="form-error"><?= e($err) ?></div>
        <?php endforeach; ?>
    </div>

    <div class="form-group">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.35rem;">
            <label for="password" class="form-label required" style="margin-bottom: 0;">Password</label>
            <a href="<?= url('forgot-password') ?>" class="text-xs" style="color: var(--primary); font-weight: 500;">
                Forgot password?
            </a>
        </div>
        <div class="input-group">
            <input 
                type="password" 
                name="password" 
                id="password" 
                class="form-control <?= has_error($errors, 'password') ? 'is-invalid' : '' ?>" 
                placeholder="••••••••" 
                required
            >
            <button type="button" class="input-group-addon-btn toggle-password-btn" data-target="password" aria-label="Toggle password view">
                <i data-lucide="eye" style="width: 18px; height: 18px;"></i>
            </button>
        </div>
        <?php foreach (field_errors($errors, 'password') as $err): ?>
            <div class="form-error"><?= e($err) ?></div>
        <?php endforeach; ?>
    </div>

    <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 1.25rem;">
        <span>Sign in to Dashboard</span>
        <i data-lucide="arrow-right" style="width: 18px; height: 18px;"></i>
    </button>
</form>

<div class="auth-footer-links">
    Don't have a business account yet?
    <a href="<?= url('register') ?>" style="font-weight: 600; color: var(--primary);">
        Create account free
    </a>
</div>
