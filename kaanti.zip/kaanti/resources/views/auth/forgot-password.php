<div class="auth-header">
    <h1>Reset your password</h1>
    <p>Enter the email address registered with your business account.</p>
</div>

<form action="<?= url('forgot-password') ?>" method="POST" novalidate>
    <?= csrf_field() ?>

    <div class="form-group">
        <label for="email" class="form-label required">Email address</label>
        <input 
            type="email" 
            name="email" 
            id="email" 
            class="form-control <?= has_error($errors, 'email') ? 'is-invalid' : '' ?>" 
            value="<?= e(old('email')) ?>" 
            placeholder="trader@kaanti.com" 
            required 
            autofocus
        >
        <?php foreach (field_errors($errors, 'email') as $err): ?>
            <div class="form-error"><?= e($err) ?></div>
        <?php endforeach; ?>
    </div>

    <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 1.25rem;">
        <span>Send Reset Link</span>
        <i data-lucide="mail" style="width: 18px; height: 18px;"></i>
    </button>
</form>

<div class="auth-footer-links">
    Remember your password?
    <a href="<?= url('login') ?>" style="font-weight: 600; color: var(--primary);">
        Back to sign in
    </a>
</div>
