<div class="auth-header">
    <h1>Create new password</h1>
    <p>Please enter and confirm your new secure password.</p>
</div>

<form action="<?= url('reset-password') ?>" method="POST" novalidate>
    <?= csrf_field() ?>
    <input type="hidden" name="token" value="<?= e($token ?? '') ?>">

    <div class="form-group">
        <label for="password" class="form-label required">New Password</label>
        <div class="input-group">
            <input 
                type="password" 
                name="password" 
                id="password" 
                class="form-control <?= has_error($errors, 'password') ? 'is-invalid' : '' ?>" 
                placeholder="At least 8 characters" 
                required 
                autofocus
            >
            <button type="button" class="input-group-addon-btn toggle-password-btn" data-target="password" aria-label="Toggle password view">
                <i data-lucide="eye" style="width: 18px; height: 18px;"></i>
            </button>
        </div>
        <?php foreach (field_errors($errors, 'password') as $err): ?>
            <div class="form-error"><?= e($err) ?></div>
        <?php endforeach; ?>
    </div>

    <div class="form-group">
        <label for="password_confirmation" class="form-label required">Confirm New Password</label>
        <div class="input-group">
            <input 
                type="password" 
                name="password_confirmation" 
                id="password_confirmation" 
                class="form-control" 
                placeholder="Re-enter new password" 
                required
            >
            <button type="button" class="input-group-addon-btn toggle-password-btn" data-target="password_confirmation" aria-label="Toggle password view">
                <i data-lucide="eye" style="width: 18px; height: 18px;"></i>
            </button>
        </div>
    </div>

    <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 1.25rem;">
        <span>Update Password & Sign In</span>
        <i data-lucide="check" style="width: 18px; height: 18px;"></i>
    </button>
</form>

<div class="auth-footer-links">
    <a href="<?= url('login') ?>" style="font-weight: 600; color: var(--primary);">
        Back to sign in
    </a>
</div>
