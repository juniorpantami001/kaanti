<div style="max-width: 680px; margin: 0 auto;">
    <div style="margin-bottom: 1.5rem;">
        <a href="<?= url('inventory/' . $product['id']) ?>" class="text-sm text-muted" style="display: inline-flex; align-items: center; gap: 0.35rem; margin-bottom: 0.5rem;">
            <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
            <span>Back to product details</span>
        </a>
        <h1 style="font-size: 1.6rem; color: var(--text-main);">Edit Product: <?= e($product['name']) ?></h1>
        <p class="text-sm text-muted">Update catalog details, pricing, and reorder levels.</p>
    </div>

    <div class="card">
        <div class="card-body" style="padding: 1.75rem;">
            <form action="<?= url('inventory/' . $product['id'] . '/edit') ?>" method="POST" novalidate>
                <?= csrf_field() ?>

                <div class="form-group">
                    <label for="name" class="form-label required">Product / Item Name</label>
                    <input 
                        type="text" 
                        name="name" 
                        id="name" 
                        class="form-control <?= has_error($errors, 'name') ? 'is-invalid' : '' ?>" 
                        value="<?= e(old('name', $product['name'])) ?>" 
                        required 
                        autofocus
                    >
                    <?php foreach (field_errors($errors, 'name') as $err): ?>
                        <div class="form-error"><?= e($err) ?></div>
                    <?php endforeach; ?>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="sku" class="form-label">SKU / Item Code</label>
                        <input 
                            type="text" 
                            name="sku" 
                            id="sku" 
                            class="form-control" 
                            value="<?= e(old('sku', $product['sku'])) ?>"
                        >
                    </div>

                    <div class="form-group">
                        <label for="category" class="form-label">Category</label>
                        <input 
                            type="text" 
                            name="category" 
                            id="category" 
                            class="form-control" 
                            value="<?= e(old('category', $product['category'])) ?>"
                        >
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="cost_price" class="form-label required">Cost Price per Unit (₦)</label>
                        <input 
                            type="number" 
                            step="0.01" 
                            name="cost_price" 
                            id="cost_price" 
                            class="form-control <?= has_error($errors, 'cost_price') ? 'is-invalid' : '' ?>" 
                            value="<?= e(old('cost_price', $product['cost_price'])) ?>" 
                            required
                        >
                        <?php foreach (field_errors($errors, 'cost_price') as $err): ?>
                            <div class="form-error"><?= e($err) ?></div>
                        <?php endforeach; ?>
                    </div>

                    <div class="form-group">
                        <label for="selling_price" class="form-label required">Selling Price per Unit (₦)</label>
                        <input 
                            type="number" 
                            step="0.01" 
                            name="selling_price" 
                            id="selling_price" 
                            class="form-control <?= has_error($errors, 'selling_price') ? 'is-invalid' : '' ?>" 
                            value="<?= e(old('selling_price', $product['selling_price'])) ?>" 
                            required
                        >
                        <?php foreach (field_errors($errors, 'selling_price') as $err): ?>
                            <div class="form-error"><?= e($err) ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="min_stock_level" class="form-label required">Minimum Stock Alert Level</label>
                    <input 
                        type="number" 
                        name="min_stock_level" 
                        id="min_stock_level" 
                        class="form-control <?= has_error($errors, 'min_stock_level') ? 'is-invalid' : '' ?>" 
                        value="<?= e(old('min_stock_level', $product['min_stock_level'])) ?>" 
                        min="0" 
                        required
                    >
                    <?php foreach (field_errors($errors, 'min_stock_level') as $err): ?>
                        <div class="form-error"><?= e($err) ?></div>
                    <?php endforeach; ?>
                </div>

                <div class="form-group">
                    <label for="description" class="form-label">Notes / Description</label>
                    <textarea name="description" id="description" class="form-control" rows="3"><?= e(old('description', $product['description'])) ?></textarea>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1.5rem;">
                    <a href="<?= url('inventory/' . $product['id']) ?>" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i data-lucide="check" style="width: 18px; height: 18px;"></i>
                        <span>Update Product</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
