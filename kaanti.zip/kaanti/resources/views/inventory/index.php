<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
    <div>
        <h1 style="font-size: 1.5rem; color: var(--text-main); margin-bottom: 0.25rem;">
            Inventory Management
        </h1>
        <p class="text-sm text-muted">Track stock levels, monitor reorder thresholds, and value your store assets.</p>
    </div>

    <div style="display: flex; gap: 0.5rem;">
        <a href="<?= url('sales/create') ?>" class="btn btn-secondary btn-sm">
            <i data-lucide="shopping-cart" style="width: 16px; height: 16px;"></i>
            <span>New Sale</span>
        </a>
        <a href="<?= url('inventory/create') ?>" class="btn btn-primary btn-sm">
            <i data-lucide="package-plus" style="width: 16px; height: 16px;"></i>
            <span>Add New Product</span>
        </a>
    </div>
</div>

<!-- Inventory Summary KPI Cards -->
<div class="stats-grid">
    <div class="stat-card">
        <div>
            <div class="stat-title">Catalogued Products</div>
            <div class="stat-value"><?= number_format($summary['total_items']) ?></div>
            <div class="stat-subtext">Active SKUs / items</div>
        </div>
        <div class="stat-icon-box icon-box-green">
            <i data-lucide="package" style="width: 22px; height: 22px;"></i>
        </div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-title">Total Stock Units</div>
            <div class="stat-value"><?= number_format($summary['total_units']) ?></div>
            <div class="stat-subtext">Physical units on shelf</div>
        </div>
        <div class="stat-icon-box icon-box-blue">
            <i data-lucide="boxes" style="width: 22px; height: 22px;"></i>
        </div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-title">Stock Value (Cost)</div>
            <div class="stat-value" style="color: var(--primary);">
                <?= format_naira($summary['total_cost_valuation']) ?>
            </div>
            <div class="stat-subtext">Estimated acquisition value</div>
        </div>
        <div class="stat-icon-box icon-box-gold">
            <i data-lucide="landmark" style="width: 22px; height: 22px;"></i>
        </div>
    </div>

    <div class="stat-card">
        <div>
            <div class="stat-title">Low Stock Reorders</div>
            <div class="stat-value" style="color: <?= $summary['low_stock_count'] > 0 ? 'var(--danger)' : 'var(--text-main)' ?>;">
                <?= number_format($summary['low_stock_count']) ?>
            </div>
            <div class="stat-subtext">At or below reorder level</div>
        </div>
        <div class="stat-icon-box <?= $summary['low_stock_count'] > 0 ? 'icon-box-red' : 'icon-box-green' ?>">
            <i data-lucide="alert-triangle" style="width: 22px; height: 22px;"></i>
        </div>
    </div>
</div>

<!-- Search & Filters -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-body" style="padding: 1rem 1.25rem;">
        <form method="GET" action="<?= url('inventory') ?>" style="display: grid; grid-template-columns: 2fr 1.5fr auto 80px; gap: 0.85rem; align-items: end;">
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label text-xs">Search Item or SKU</label>
                <input type="text" name="search" class="form-control" value="<?= e($filters['search'] ?? '') ?>" placeholder="Product name, barcode, SKU...">
            </div>

            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label text-xs">Category</label>
                <input type="text" name="category" class="form-control" value="<?= e($filters['category'] ?? '') ?>" placeholder="Filter by category...">
            </div>

            <div style="display: flex; align-items: center; gap: 0.5rem; height: 38px;">
                <label style="display: flex; align-items: center; gap: 0.4rem; font-size: 0.85rem; cursor: pointer;">
                    <input type="checkbox" name="low_stock" value="1" <?= !empty($filters['low_stock']) ? 'checked' : '' ?>>
                    <span>Low Stock Only</span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary btn-block">
                <i data-lucide="search" style="width: 16px; height: 16px;"></i>
            </button>
        </form>
    </div>
</div>

<!-- Inventory Products Table -->
<div class="card">
    <?php if (empty($products)): ?>
        <div class="empty-state">
            <div class="empty-state-icon">
                <i data-lucide="package" style="width: 32px; height: 32px;"></i>
            </div>
            <div class="empty-state-title">No products found</div>
            <div class="empty-state-desc">You have not added any goods to this business catalogue yet or your search returned no matches.</div>
            <a href="<?= url('inventory/create') ?>" class="btn btn-primary">
                <i data-lucide="package-plus" style="width: 16px; height: 16px;"></i>
                <span>Add Your First Product</span>
            </a>
        </div>
    <?php else: ?>
        <div class="table-container" style="border: none;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>SKU</th>
                        <th>Category</th>
                        <th style="text-align: right;">Cost Price</th>
                        <th style="text-align: right;">Selling Price</th>
                        <th style="text-align: center;">Stock In Hand</th>
                        <th>Stock Status</th>
                        <th style="text-align: center;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $p): ?>
                        <?php 
                            $isLow = (int) $p['quantity'] <= (int) $p['min_stock_level'];
                            $isOut = (int) $p['quantity'] <= 0;
                        ?>
                        <tr>
                            <td class="font-medium">
                                <a href="<?= url('inventory/' . $p['id']) ?>" style="color: inherit; font-weight: 600;">
                                    <?= e($p['name']) ?>
                                </a>
                                <?php if (!empty($p['description'])): ?>
                                    <div class="text-xs text-muted truncate" style="max-width: 250px;">
                                        <?= e($p['description']) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <code style="font-size: 0.75rem; background: var(--surface-alt); padding: 0.15rem 0.4rem; border-radius: var(--radius-sm);">
                                    <?= e($p['sku'] ?: '—') ?>
                                </code>
                            </td>
                            <td>
                                <span class="text-xs text-muted">
                                    <?= e($p['category'] ?: 'General') ?>
                                </span>
                            </td>
                            <td style="text-align: right; color: var(--text-secondary);">
                                <?= format_naira($p['cost_price']) ?>
                            </td>
                            <td style="text-align: right; font-weight: 600; color: var(--text-main);">
                                <?= format_naira($p['selling_price']) ?>
                            </td>
                            <td style="text-align: center; font-weight: 700; font-size: 1rem;">
                                <?= number_format($p['quantity']) ?>
                            </td>
                            <td>
                                <?php if ($isOut): ?>
                                    <span class="badge badge-danger">Out of Stock</span>
                                <?php elseif ($isLow): ?>
                                    <span class="badge badge-warning">Low Stock (≤ <?= $p['min_stock_level'] ?>)</span>
                                <?php else: ?>
                                    <span class="badge badge-success">In Stock</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <div style="display: inline-flex; gap: 0.35rem;">
                                    <a href="<?= url('inventory/' . $p['id']) ?>" class="btn btn-secondary btn-sm" style="padding: 0.25rem 0.5rem;" title="View stock movements">
                                        <i data-lucide="eye" style="width: 14px; height: 14px;"></i>
                                    </a>
                                    <a href="<?= url('inventory/' . $p['id'] . '/edit') ?>" class="btn btn-secondary btn-sm" style="padding: 0.25rem 0.5rem;" title="Edit product">
                                        <i data-lucide="edit-2" style="width: 14px; height: 14px;"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
