<?php
$isLow = (int) $product['quantity'] <= (int) $product['min_stock_level'];
$isOut = (int) $product['quantity'] <= 0;
$margin = (float) $product['selling_price'] - (float) $product['cost_price'];
$marginPercent = (float) $product['cost_price'] > 0 ? ($margin / (float) $product['cost_price']) * 100 : 0;
?>

<div style="max-width: 900px; margin: 0 auto;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.75rem;">
        <a href="<?= url('inventory') ?>" class="text-sm text-muted" style="display: inline-flex; align-items: center; gap: 0.35rem;">
            <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
            <span>Back to inventory catalogue</span>
        </a>

        <div style="display: flex; gap: 0.5rem;">
            <?php if ((int) $product['quantity'] > 0 && $product['status'] === 'active'): ?>
                <a href="<?= url('sales/create') ?>" class="btn btn-primary btn-sm">
                    <i data-lucide="shopping-cart" style="width: 15px; height: 15px;"></i>
                    <span>Sell Product</span>
                </a>
            <?php endif; ?>
            <button type="button" onclick="openModal('adjustStockModal')" class="btn btn-primary btn-sm">
                <i data-lucide="sliders" style="width: 15px; height: 15px;"></i>
                <span>Adjust / Restock</span>
            </button>
            <a href="<?= url('inventory/' . $product['id'] . '/edit') ?>" class="btn btn-secondary btn-sm">
                <i data-lucide="edit-2" style="width: 15px; height: 15px;"></i>
                <span>Edit Product</span>
            </a>
            <form action="<?= url('inventory/' . $product['id'] . '/archive') ?>" method="POST" onsubmit="return confirm('Archive this product? It will be hidden from the active catalogue.');" style="display: inline;">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-secondary btn-sm" style="color: var(--danger);">
                    <i data-lucide="archive" style="width: 15px; height: 15px;"></i>
                    <span>Archive</span>
                </button>
            </form>
        </div>
    </div>

    <!-- Product Summary Card -->
    <div class="card" style="margin-bottom: 1.5rem;">
        <div class="card-header" style="background: var(--surface-alt);">
            <div>
                <span class="text-xs text-muted uppercase font-semibold">SKU: <?= e($product['sku']) ?> &bull; <?= e($product['category']) ?></span>
                <h1 style="font-size: 1.5rem; color: var(--text-main); margin-top: 0.2rem;"><?= e($product['name']) ?></h1>
            </div>
            <div>
                <?php if ($isOut): ?>
                    <span class="badge badge-danger" style="font-size: 0.85rem; padding: 0.35rem 0.75rem;">Out of Stock</span>
                <?php elseif ($isLow): ?>
                    <span class="badge badge-warning" style="font-size: 0.85rem; padding: 0.35rem 0.75rem;">Low Stock (Reorder)</span>
                <?php else: ?>
                    <span class="badge badge-success" style="font-size: 0.85rem; padding: 0.35rem 0.75rem;">In Stock</span>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-body" style="padding: 1.5rem;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1.25rem;">
                <div style="background: var(--bg-app); padding: 1rem; border-radius: var(--radius-md); text-align: center;">
                    <div class="text-xs text-muted uppercase font-medium">Quantity On Hand</div>
                    <div style="font-size: 2rem; font-weight: 800; color: <?= $isLow ? 'var(--warning)' : 'var(--text-main)' ?>; margin-top: 0.25rem;">
                        <?= number_format($product['quantity']) ?>
                    </div>
                    <div class="text-xs text-muted">Min Threshold: <?= $product['min_stock_level'] ?> units</div>
                </div>

                <div style="background: var(--bg-app); padding: 1rem; border-radius: var(--radius-md); text-align: center;">
                    <div class="text-xs text-muted uppercase font-medium">Cost Price</div>
                    <div style="font-size: 1.4rem; font-weight: 700; color: var(--text-secondary); margin-top: 0.25rem;">
                        <?= format_naira($product['cost_price']) ?>
                    </div>
                    <div class="text-xs text-muted">Per unit purchase cost</div>
                </div>

                <div style="background: var(--bg-app); padding: 1rem; border-radius: var(--radius-md); text-align: center;">
                    <div class="text-xs text-muted uppercase font-medium">Selling Price</div>
                    <div style="font-size: 1.4rem; font-weight: 700; color: var(--primary); margin-top: 0.25rem;">
                        <?= format_naira($product['selling_price']) ?>
                    </div>
                    <div class="text-xs text-muted">Per unit retail price</div>
                </div>

                <div style="background: var(--bg-app); padding: 1rem; border-radius: var(--radius-md); text-align: center;">
                    <div class="text-xs text-muted uppercase font-medium">Unit Profit Margin</div>
                    <div style="font-size: 1.4rem; font-weight: 700; color: <?= $margin >= 0 ? 'var(--primary)' : 'var(--danger)' ?>; margin-top: 0.25rem;">
                        <?= format_naira($margin) ?>
                    </div>
                    <div class="text-xs text-muted"><?= number_format($marginPercent, 1) ?>% markup</div>
                </div>
            </div>

            <?php if (!empty($product['description'])): ?>
                <div style="margin-top: 1.5rem; padding-top: 1.25rem; border-top: 1px solid var(--border);">
                    <div class="text-xs text-muted uppercase font-semibold">Notes / Specifications</div>
                    <div style="margin-top: 0.35rem; color: var(--text-secondary);">
                        <?= nl2br(e($product['description'])) ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Stock Movements Audit Trail -->
    <div class="card">
        <div class="card-header">
            <div class="card-title" style="display: flex; align-items: center; gap: 0.5rem;">
                <i data-lucide="history" style="width: 18px; height: 18px; color: var(--primary);"></i>
                <span>Stock Movements Audit Trail</span>
            </div>
            <button type="button" onclick="openModal('adjustStockModal')" class="btn btn-secondary btn-sm">
                <span>Record Stock Change</span>
            </button>
        </div>

        <?php if (empty($movements)): ?>
            <div class="empty-state">
                <div class="empty-state-icon">
                    <i data-lucide="boxes" style="width: 28px; height: 28px;"></i>
                </div>
                <div class="empty-state-title">No stock movements logged yet</div>
                <div class="empty-state-desc">Every restock, inventory removal, purchase, or adjustment is permanently audited here.</div>
            </div>
        <?php else: ?>
            <div class="table-container" style="border: none;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date & Time</th>
                            <th>Movement Type</th>
                            <th style="text-align: right;">Prev Qty</th>
                            <th style="text-align: right;">Change</th>
                            <th style="text-align: right;">New Qty</th>
                            <th>Reason / Narration</th>
                            <th>Logged By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($movements as $m): ?>
                            <tr>
                                <td class="text-sm text-muted">
                                    <?= format_date($m['created_at'], 'M j, Y H:i') ?>
                                </td>
                                <td>
                                    <?php 
                                        $badgeClass = in_array($m['type'], ['addition', 'purchase']) ? 'badge-success' : 'badge-warning';
                                    ?>
                                    <span class="badge <?= $badgeClass ?>">
                                        <?= e(ucfirst($m['type'])) ?>
                                    </span>
                                </td>
                                <td style="text-align: right;"><?= number_format($m['previous_quantity']) ?></td>
                                <td style="text-align: right; font-weight: 700; color: <?= in_array($m['type'], ['addition', 'purchase']) ? 'var(--primary)' : 'var(--danger)' ?>;">
                                    <?= in_array($m['type'], ['addition', 'purchase']) ? '+' : '-' ?><?= number_format($m['quantity']) ?>
                                </td>
                                <td style="text-align: right; font-weight: 700;"><?= number_format($m['new_quantity']) ?></td>
                                <td><?= e($m['reason'] ?: 'Stock adjustment') ?></td>
                                <td class="text-xs text-muted"><?= e(trim(($m['first_name'] ?? '') . ' ' . ($m['last_name'] ?? '')) ?: 'Staff') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Stock Adjustment Modal -->
<div id="adjustStockModal" class="modal-overlay" style="display: none; position: fixed; inset: 0; background: rgba(15,23,42,0.6); z-index: 50; align-items: center; justify-content: center; padding: 1rem;">
    <div class="card" style="max-width: 500px; width: 100%; box-shadow: var(--shadow-lg);">
        <div class="card-header">
            <div class="card-title" style="display: flex; align-items: center; gap: 0.5rem;">
                <i data-lucide="sliders" style="width: 20px; height: 20px; color: var(--primary);"></i>
                <span>Adjust Stock: <?= e($product['name']) ?></span>
            </div>
            <button type="button" onclick="closeModal('adjustStockModal')" style="background: none; border: none; cursor: pointer; color: var(--text-muted);">
                <i data-lucide="x" style="width: 18px; height: 18px;"></i>
            </button>
        </div>
        <div class="card-body">
            <form action="<?= url('inventory/' . $product['id'] . '/adjust') ?>" method="POST">
                <?= csrf_field() ?>

                <div class="form-group">
                    <label for="type" class="form-label required">Adjustment Type</label>
                    <select name="type" id="type" class="form-control" required>
                        <option value="addition">Addition / Restock (Siyo sabon kaya)</option>
                        <option value="removal">Removal / Damage / Expired</option>
                        <option value="purchase">Bulk Purchase Arrival</option>
                        <option value="adjustment">Set Absolute Count (Audited physical count)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="quantity" class="form-label required">Quantity</label>
                    <input type="number" name="quantity" id="quantity" class="form-control" min="1" placeholder="e.g. 10" required>
                    <div class="form-text">Current stock is <?= number_format($product['quantity']) ?> units.</div>
                </div>

                <div class="form-group">
                    <label for="reason" class="form-label required">Reason / Notes</label>
                    <input type="text" name="reason" id="reason" class="form-control" placeholder="e.g. New wholesale delivery / Broken bottles during handling" required>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1.5rem;">
                    <button type="button" onclick="closeModal('adjustStockModal')" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary">Apply Stock Adjustment</button>
                </div>
            </form>
        </div>
    </div>
</div>
