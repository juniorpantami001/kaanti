<div style="max-width: 680px; margin: 0 auto;">
    <div style="margin-bottom: 1.5rem;">
        <a href="<?= url('inventory') ?>" class="text-sm text-muted" style="display: inline-flex; align-items: center; gap: 0.35rem; margin-bottom: 0.5rem;">
            <i data-lucide="arrow-left" style="width: 15px; height: 15px;"></i>
            <span>Back to inventory</span>
        </a>
        <h1 style="font-size: 1.6rem; color: var(--text-main);">Add Product to Inventory</h1>
        <p class="text-sm text-muted">Register a new product, establish unit cost and selling price, and set reorder alerts.</p>
    </div>

    <div class="card">
        <div class="card-body" style="padding: 1.75rem;">
            <form action="<?= url('inventory') ?>" method="POST" novalidate>
                <?= csrf_field() ?>

                <div class="form-group">
                    <label for="name" class="form-label required">Product / Item Name</label>
                    <input 
                        type="text" 
                        name="name" 
                        id="name" 
                        class="form-control <?= has_error($errors, 'name') ? 'is-invalid' : '' ?>" 
                        value="<?= e(old('name')) ?>" 
                        placeholder="e.g. Dangote Sugar 50kg / Ankara Super Wax Fabric" 
                        required 
                        autofocus
                    >
                    <?php foreach (field_errors($errors, 'name') as $err): ?>
                        <div class="form-error"><?= e($err) ?></div>
                    <?php endforeach; ?>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="sku" class="form-label">SKU / Item Code</label>
                        <input 
                            type="text" 
                            name="sku" 
                            id="sku" 
                            class="form-control" 
                            value="<?= e(old('sku')) ?>" 
                            placeholder="Leave blank to auto-generate"
                        >
                    </div>

                    <div class="form-group">
                        <label for="category" class="form-label">Category</label>
                        <input 
                            type="text" 
                            name="category" 
                            id="category" 
                            class="form-control" 
                            value="<?= e(old('category')) ?>" 
                            placeholder="e.g. Provisions, Textiles, Hardware"
                        >
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="cost_price" class="form-label required">Cost Price per Unit (₦)</label>
                        <input 
                            type="number" 
                            step="0.01" 
                            name="cost_price" 
                            id="cost_price" 
                            class="form-control <?= has_error($errors, 'cost_price') ? 'is-invalid' : '' ?>" 
                            value="<?= e(old('cost_price')) ?>" 
                            placeholder="0.00" 
                            required
                        >
                        <div class="form-text">What you bought it for (wholesale/factory cost).</div>
                        <?php foreach (field_errors($errors, 'cost_price') as $err): ?>
                            <div class="form-error"><?= e($err) ?></div>
                        <?php endforeach; ?>
                    </div>

                    <div class="form-group">
                        <label for="selling_price" class="form-label required">Selling Price per Unit (₦)</label>
                        <input 
                            type="number" 
                            step="0.01" 
                            name="selling_price" 
                            id="selling_price" 
                            class="form-control <?= has_error($errors, 'selling_price') ? 'is-invalid' : '' ?>" 
                            value="<?= e(old('selling_price')) ?>" 
                            placeholder="0.00" 
                            required
                        >
                        <div class="form-text">Retail or counter selling price to customer.</div>
                        <?php foreach (field_errors($errors, 'selling_price') as $err): ?>
                            <div class="form-error"><?= e($err) ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="quantity" class="form-label required">Opening Stock Quantity</label>
                        <input 
                            type="number" 
                            name="quantity" 
                            id="quantity" 
                            class="form-control <?= has_error($errors, 'quantity') ? 'is-invalid' : '' ?>" 
                            value="<?= e(old('quantity', 0)) ?>" 
                            min="0" 
                            required
                        >
                        <div class="form-text">Current units on physical hand.</div>
                        <?php foreach (field_errors($errors, 'quantity') as $err): ?>
                            <div class="form-error"><?= e($err) ?></div>
                        <?php endforeach; ?>
                    </div>

                    <div class="form-group">
                        <label for="min_stock_level" class="form-label required">Minimum Stock Alert Level</label>
                        <input 
                            type="number" 
                            name="min_stock_level" 
                            id="min_stock_level" 
                            class="form-control <?= has_error($errors, 'min_stock_level') ? 'is-invalid' : '' ?>" 
                            value="<?= e(old('min_stock_level', 5)) ?>" 
                            min="0" 
                            required
                        >
                        <div class="form-text">Dashboard alerts you when units drop to this count.</div>
                        <?php foreach (field_errors($errors, 'min_stock_level') as $err): ?>
                            <div class="form-error"><?= e($err) ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="form-group">
                    <label for="description" class="form-label">Product Notes / Specifications</label>
                    <textarea name="description" id="description" class="form-control" rows="2" placeholder="e.g. Size, color variants, expiration details..."><?= e(old('description')) ?></textarea>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 0.75rem; margin-top: 1.5rem;">
                    <a href="<?= url('inventory') ?>" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i data-lucide="package-plus" style="width: 18px; height: 18px;"></i>
                        <span>Save to Inventory</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
