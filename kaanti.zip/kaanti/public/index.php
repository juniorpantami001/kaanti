<?php
/**
 * Kaanti Manager — Application Entry Point
 * 
 * All HTTP requests are routed through this file.
 * Only the /public directory is web-accessible.
 */

// Define root path
define('ROOT_PATH', dirname(__DIR__));

// Composer autoloader
require ROOT_PATH . '/vendor/autoload.php';

use App\Core\{Env, Session, Router, CSRF};

// ── Bootstrap ──────────────────────────────────────────
try {
    // Load environment
    Env::load(ROOT_PATH . '/.env');

    // Set timezone
    date_default_timezone_set('Africa/Lagos');

    // Error reporting based on environment
    if (env('APP_DEBUG')) {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
    } else {
        error_reporting(0);
        ini_set('display_errors', '0');
    }

    // Error log
    ini_set('log_errors', '1');
    ini_set('error_log', ROOT_PATH . '/storage/logs/error.log');

    // Start session
    Session::start();

    // Generate CSRF token if none exists
    CSRF::token();

    // Security headers
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');

    // ── Routing ────────────────────────────────────────
    $router = new Router();

    // Load web routes
    require ROOT_PATH . '/routes/web.php';

    // Dispatch the request
    $router->dispatch();

} catch (\Throwable $e) {
    // Log the error
    error_log(sprintf(
        "[%s] %s in %s:%d\n%s",
        date('Y-m-d H:i:s'),
        $e->getMessage(),
        $e->getFile(),
        $e->getLine(),
        $e->getTraceAsString()
    ));

    if (env('APP_DEBUG')) {
        http_response_code(500);
        echo '<div style="font-family:monospace;padding:2rem;">';
        echo '<h1 style="color:#DC2626;">Error</h1>';
        echo '<p><strong>' . htmlspecialchars($e->getMessage()) . '</strong></p>';
        echo '<p>' . htmlspecialchars($e->getFile()) . ':' . $e->getLine() . '</p>';
        echo '<pre>' . htmlspecialchars($e->getTraceAsString()) . '</pre>';
        echo '</div>';
    } else {
        http_response_code(500);
        echo '<h1>Something went wrong</h1>';
        echo '<p>We are working to fix this. Please try again later.</p>';
    }
}
