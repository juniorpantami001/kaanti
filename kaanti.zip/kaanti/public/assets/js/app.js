/**
 * ====================================================================
 * KAANTI MANAGER — FRONTEND CLIENT JAVASCRIPT
 * Vanilla JS ES6+ (No jQuery, No bloated libraries)
 * ====================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialize Lucide Icons
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
        window.lucide.createIcons();
    }

    // 2. Mobile Sidebar Navigation Toggle
    const sidebar = document.getElementById('appSidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    const closeSidebarBtn = document.getElementById('closeSidebarBtn');

    function openSidebar() {
        if (sidebar && sidebarOverlay) {
            sidebar.classList.add('open');
            sidebarOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeSidebar() {
        if (sidebar && sidebarOverlay) {
            sidebar.classList.remove('open');
            sidebarOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    if (hamburgerBtn) hamburgerBtn.addEventListener('click', openSidebar);
    if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);
    if (closeSidebarBtn) closeSidebarBtn.addEventListener('click', closeSidebar);

    // 3. Auto-Dismiss Flash Alerts
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        // Close button click
        const dismissBtn = alert.querySelector('.alert-dismiss');
        if (dismissBtn) {
            dismissBtn.addEventListener('click', () => {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 250);
            });
        }

        // Auto hide after 6 seconds
        setTimeout(() => {
            alert.style.transition = 'opacity 0.4s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 400);
        }, 6000);
    });

    // 4. Password Show / Hide Toggles
    const togglePasswordButtons = document.querySelectorAll('.toggle-password-btn');
    togglePasswordButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = btn.getAttribute('data-target');
            const input = document.getElementById(targetId);
            if (!input) return;

            if (input.type === 'password') {
                input.type = 'text';
                btn.innerHTML = '<i data-lucide="eye-off" style="width:18px;height:18px;"></i>';
            } else {
                input.type = 'password';
                btn.innerHTML = '<i data-lucide="eye" style="width:18px;height:18px;"></i>';
            }
            if (window.lucide) window.lucide.createIcons();
        });
    });

    // 5. Password Strength Meter
    const passwordInput = document.getElementById('reg_password');
    const strengthFill = document.getElementById('password_strength_fill');
    const strengthText = document.getElementById('password_strength_text');

    if (passwordInput && strengthFill) {
        passwordInput.addEventListener('input', () => {
            const val = passwordInput.value;
            let score = 0;

            if (val.length >= 8) score++;
            if (/[a-z]/.test(val) && /[A-Z]/.test(val)) score++;
            if (/\d/.test(val)) score++;
            if (/[^a-zA-Z\d]/.test(val)) score++;

            if (val.length === 0) {
                strengthFill.style.width = '0%';
                if (strengthText) strengthText.textContent = '';
            } else if (score <= 1) {
                strengthFill.style.width = '25%';
                strengthFill.style.backgroundColor = 'var(--danger)';
                if (strengthText) strengthText.textContent = 'Weak';
            } else if (score === 2) {
                strengthFill.style.width = '50%';
                strengthFill.style.backgroundColor = 'var(--warning)';
                if (strengthText) strengthText.textContent = 'Fair';
            } else if (score === 3) {
                strengthFill.style.width = '75%';
                strengthFill.style.backgroundColor = '#3B82F6';
                if (strengthText) strengthText.textContent = 'Good';
            } else {
                strengthFill.style.width = '100%';
                strengthFill.style.backgroundColor = 'var(--primary)';
                if (strengthText) strengthText.textContent = 'Strong';
            }
        });
    }

    // 6. Generic Modal Controls
    window.openModal = function (modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            if (window.lucide) window.lucide.createIcons();
        }
    };

    window.closeModal = function (modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
    };

    // Close modal on escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeSidebar();
            document.querySelectorAll('.modal-overlay').forEach(m => m.style.display = 'none');
            document.body.style.overflow = '';
        }
    });

    // 7. Naira Currency Formatter Utility
    window.formatNaira = function (amount) {
        return '₦' + Number(amount || 0).toLocaleString('en-NG', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    };
});

/**
 * Chart Initialization Helper: Cash Flow Chart
 */
window.initCashFlowChart = function (canvasId, labels, incomeData, expenseData) {
    const ctx = document.getElementById(canvasId);
    if (!ctx || typeof Chart === 'undefined') return;

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels && labels.length ? labels : ['Current Period'],
            datasets: [
                {
                    label: 'Income (₦)',
                    data: incomeData && incomeData.length ? incomeData : [0],
                    backgroundColor: '#2E7D32',
                    borderRadius: 4,
                    barPercentage: 0.6,
                },
                {
                    label: 'Expenses (₦)',
                    data: expenseData && expenseData.length ? expenseData : [0],
                    backgroundColor: '#DC2626',
                    borderRadius: 4,
                    barPercentage: 0.6,
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        boxWidth: 12,
                        font: { family: 'inherit', size: 12 }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function (context) {
                            return context.dataset.label + ': ' + window.formatNaira(context.parsed.y);
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: '#F1F5F9' },
                    ticks: {
                        callback: function (val) {
                            return '₦' + (val >= 1000 ? (val / 1000).toFixed(0) + 'k' : val);
                        }
                    }
                },
                x: {
                    grid: { display: false }
                }
            }
        }
    });
};

/**
 * Chart Initialization Helper: Expense Breakdown Doughnut
 */
window.initExpenseChart = function (canvasId, categories, amounts) {
    const ctx = document.getElementById(canvasId);
    if (!ctx || typeof Chart === 'undefined') return;

    if (!categories || categories.length === 0) {
        categories = ['No Expenses Recorded'];
        amounts = [1];
    }

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: categories,
            datasets: [{
                data: amounts,
                backgroundColor: [
                    '#DC2626',
                    '#F9A825',
                    '#2E7D32',
                    '#0284C7',
                    '#8B5CF6',
                    '#64748B'
                ],
                borderWidth: 2,
                borderColor: '#FFFFFF'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 10,
                        font: { family: 'inherit', size: 11 }
                    }
                }
            },
            cutout: '68%'
        }
    });
};
