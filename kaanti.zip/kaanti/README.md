# Kaanti Manager (SME Financial Management SaaS)

> **Manage. Grow. Prosper.**  
> SME Financial Management and Business Management SaaS platform specifically designed for Nigerian enterprises, shop owners, market traders, and growing businesses.

---

## 1. Brand Identity & Official Palette

The application design is established from the official **Kaanti** brand identity (shopping bag with leaf and golden orbital swoosh):

| Color Role | CSS Variable | Hex Code | Visual Reference |
|---|---|---|---|
| **Primary Green** | `--primary` | `#2E7D32` | Main logo brand color |
| **Dark Forest Green** | `--primary-dark` | `#1B5E20` | Outer logo badge ring & navigation |
| **Accent Gold** | `--accent` | `#F9A825` | Golden energy orbit / swoosh |
| **Light Green Subtle** | `--primary-subtle` | `#E8F5E9` | Cards, pill backgrounds & badges |
| **App Background** | `--bg-app` | `#F8FAFC` | Clean modern slate canvas |
| **Surface Card** | `--surface` | `#FFFFFF` | Elevated cards and data tables |

---

## 2. Technology Stack

- **Backend**: Plain PHP 8.2+ with PDO
- **Database Engine**: MySQL 8.0.16+ (UUID primary keys, `DECIMAL(15,2)` for monetary accuracy, JSON audit diffs)
- **Frontend**: Semantic HTML5, Custom Crafted CSS3 Design System, Vanilla JavaScript (ES6+)
- **Icons & Visuals**: Lucide Icons, Chart.js
- **Architecture**: Modular MVC Monolith with Centralized Routing, Middleware, and PSR-4 Autoloading

---

## 3. Directory Structure

```text
kaanti/
├── app/
│   ├── Core/                     # Application, Database (PDO), Router, Controller, Session, CSRF, Validator, View
│   ├── Middleware/               # AuthMiddleware, GuestMiddleware, BusinessMiddleware, AdminMiddleware
│   ├── Modules/
│   │   ├── Auth/                 # Registration, Login, Password Reset, Rate Limiting
│   │   ├── Business/             # Tenant Creation, Member Roles, Onboarding Flow
│   │   ├── Dashboard/            # Real Live Tenant Calculations, Charts, Summaries
│   │   ├── Transactions/         # Financial Inflows & Outflows Ledger, Reversals/Voiding
│   │   ├── Income/               # Record Non-Inventory Income, Customer Linking
│   │   ├── Expenses/             # Operational Expenditures, Category Classifications
│   │   ├── Inventory/            # Product Catalogue, Valuations, Stock Movement Audit
│   │   ├── Sales/                # Inventory Sales, Stock Deduction, Profit & Best Sellers
│   │   ├── Customers/            # Buyer Directory, Transaction History, Lifetime Spend
│   │   ├── Reports/              # Bookkeeping Statements, Monthly Summaries, Printable Vouchers
│   │   ├── Financing/            # Murabaha, Ijarah, Salam Non-Interest Discovery
│   │   ├── Investments/          # Sukuk & Shariah Fund Ethical Discovery
│   │   ├── Learning/             # Kaanti Learn (Bilingual English & Hausa Guides)
│   │   ├── Admin/                # Super Admin Controls, Tenant Suspension, Audit Trail
│   │   └── Subscription/         # Owner billing, Paystack checkout and webhook handling
│   ├── Services/                 # AuditService, Security Logging
│   └── Helpers/                  # Global Utilities (format_naira, slugify, csrf_field)
├── config/                       # app.php, database.php
├── database/
│   ├── schema.sql                # Complete MySQL Schema
│   ├── seeders/seed.sql          # Seed Categories, Partners, Articles, Demo Products
│   └── migrate.php               # One-click CLI Database Migrator & Seeder
├── public/                       # ONLY Publicly Accessible Web Root
│   ├── index.php                 # Front Controller Entry Point
│   ├── .htaccess                 # URL Rewriting & Security Headers
│   └── assets/                   # css/app.css, js/app.js, images/logo.jpeg
├── resources/
│   ├── views/                    # Layouts, Components, Auth, Dashboard, Modules
│   └── languages/                # en.php (English), ha.php (Hausa)
├── routes/                       # web.php, api.php
├── storage/                      # logs, uploads, exports
├── tests/                        # functional_test.php (Automated Test Suite)
├── .env.example
├── composer.json
└── README.md
```

Inventory product sales are recorded from the Sales module. Each sale stores the
product name, SKU, selling price, and cost snapshots, updates stock atomically,
and contributes to gross-profit and best-selling-product reports. Voiding a sale
restores its stock and removes it from active sales metrics.

---

## 4. Setup & Installation Instructions

### Step 1: Clone or Copy Project
Place the project inside your web server directory:
```bash
c:\xampp\htdocs\kaanti
```

### Step 2: Environment Configuration
Copy `.env.example` to `.env` and fill in your MySQL database credentials. If `.env` already exists, update its database settings; copying the example does not overwrite it:
```env
APP_NAME=KaantiManager
APP_ENV=development
APP_URL=http://localhost/kaanti/public
APP_DEBUG=true

DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=kaanti_manager
DB_USERNAME=root
DB_PASSWORD=
```

### Step 3: Run Database Migrations
Ensure MySQL 8.0.16 or later is running and create the database with UTF-8 support:
```sql
CREATE DATABASE kaanti_manager CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
Then run:
```bash
php database/migrate.php
```
This automatically sets up the relational tables, indexes, default categories, educational articles, and creates the Super Admin if it does not already exist. Set `ADMIN_EMAIL` and a unique `ADMIN_PASSWORD` of at least 12 characters in `.env` before the first run; the password is never printed by the migrator.

The migration creates the MySQL schema and seed data; it does not transfer existing PostgreSQL records.

### Super Admin Control Center

Sign in with the super-admin account and open `/admin` to review platform totals, active and suspended businesses, subscription collections (all-time and this month), subscription attention items, and recent audit activity. Collection totals are gross successful payments and do not deduct Paystack fees or refunds. The dashboard provides direct suspend/reactivate controls for recent businesses; **Manage All Businesses** opens the searchable directory for every business, owner, and subscription status. User accounts and the audit trail are available from the super-admin navigation.

### Monthly Owner Subscription

Business owners are billed ₦5,000 monthly per owner account through Paystack. There are no free trials or grace periods: owners must complete payment before accessing business features. The monthly period starts when payment succeeds. Existing trial, pending, and past-due owner accounts are suspended until payment succeeds; already-paid subscription periods remain available through their recorded end date.

Set `PAYSTACK_SECRET_KEY` in `.env`. The app creates and stores a monthly ₦5,000 Paystack plan automatically on first checkout; optionally set `PAYSTACK_PLAN_CODE` to use a plan created in your Paystack dashboard. In the Paystack dashboard, configure the webhook URL as `https://your-public-domain/kaanti/public/paystack/webhook`. `APP_URL` must be a publicly reachable HTTPS URL for Paystack callbacks and webhooks; `localhost` is not reachable by Paystack.

### Step 4: Run Functional Verification Tests
Verify all system components, validators, token generators, and localization files:
```bash
php tests/functional_test.php
```

### Step 5: Access the Application
Open your browser and navigate to:
```
http://localhost/kaanti/public
```
Or start PHP's built-in server:
```bash
php -S localhost:8000 -t public
```
And access `http://localhost:8000`.

---

## 5. Security & Multi-Tenant Integrity

- **Tenant Isolation**: Every financial and business query is scoped by `business_id` verified via `BusinessMiddleware`. Browser-supplied business IDs are never trusted.
- **Financial Immutability**: Critical transaction entries are voided with mandatory reasons and timestamps rather than silently deleted.
- **Input Sanitization**: Prepared PDO statements protect against SQL injection; HTML outputs are escaped using `e()` helper.
- **CSRF Token Guard**: Single-use cryptographic tokens protect all POST state modifications.
- **Rate Limiting**: Brute-force protection limits failed login attempts (5 attempts per 15 minutes per IP/email).
- **Session Protection**: Strict session cookies (`HttpOnly`, `SameSite=Lax`, fixation prevention via regeneration).
