<?php
/**
 * Kaanti Manager — Functional & Unit Verification Test Suite
 * 
 * Usage: php tests/functional_test.php
 */

define('ROOT_PATH', dirname(__DIR__));
require ROOT_PATH . '/vendor/autoload.php';

use App\Core\{Env, Session, CSRF, Validator, Router};

// Load env
Env::load(ROOT_PATH . '/.env');

echo "========================================================\n";
echo "   KAANTI MANAGER — FUNCTIONAL TEST SUITE               \n";
echo "========================================================\n\n";

$passed = 0;
$failed = 0;

function assertTest(string $description, bool $condition): void {
    global $passed, $failed;
    if ($condition) {
        echo "  [PASS] {$description}\n";
        $passed++;
    } else {
        echo "  [FAIL] {$description}\n";
        $failed++;
    }
}

// 1. Environment & Configuration
echo "1. Testing Configuration & Environment:\n";
assertTest("Env parser loads .env values", Env::get('APP_NAME') === 'KaantiManager');
assertTest("App URL configured", str_contains(Env::get('APP_URL'), 'kaanti'));
assertTest("Timezone is Africa/Lagos", date_default_timezone_get() !== false);
$uuid = App\Core\Database::generateUuid();
assertTest("Database UUID generator creates version 4 UUIDs", preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/', $uuid) === 1);

// 2. CSRF Security Tokens
echo "\n2. Testing CSRF Protection:\n";
Session::start();
$token = CSRF::generate();
assertTest("CSRF token is 64 hex characters", strlen($token) === 64);
assertTest("CSRF token matches session", CSRF::token() !== null);
assertTest("CSRF field renders hidden HTML input", str_contains(CSRF::field(), 'type="hidden" name="_csrf_token"'));

// 3. Input Validator
echo "\n3. Testing Server-Side Validator:\n";
// Valid case
$validData = [
    'first_name'            => 'Aminu',
    'last_name'             => 'Bello',
    'email'                 => 'aminu@kaanti.ng',
    'phone'                 => '08031234567',
    'password'              => 'Secret123!',
    'password_confirmation' => 'Secret123!',
    'amount'                => '25000.50'
];
$rules = [
    'first_name' => 'required|min:2',
    'email'      => 'required|email',
    'phone'      => 'required|phone',
    'password'   => 'required|min:8|confirmed',
    'amount'     => 'required|numeric'
];
$errors = Validator::validate($validData, $rules);
assertTest("Validator approves clean user data", empty($errors));

// Invalid case
$invalidData = [
    'first_name'            => '',
    'email'                 => 'not-an-email',
    'phone'                 => '123',
    'password'              => 'short',
    'password_confirmation' => 'mismatch',
    'amount'                => 'ten-thousand'
];
$errors = Validator::validate($invalidData, $rules);
assertTest("Validator catches missing required first name", isset($errors['first_name']));
assertTest("Validator catches invalid email", isset($errors['email']));
assertTest("Validator catches invalid phone number", isset($errors['phone']));
assertTest("Validator catches short password", isset($errors['password']));
assertTest("Validator catches non-numeric monetary input", isset($errors['amount']));

// 4. Helper Functions
echo "\n4. Testing Helper Utilities:\n";
assertTest("Naira currency formatter formats decimals", format_naira(1500000.50) === '₦1,500,000.50');
assertTest("Naira formatter handles null/zero cleanly", format_naira(0) === '₦0.00');
assertTest("Slugify generates url-safe slugs", slugify("Al-Barakah Textile & Grains Store!") === 'al-barakah-textile-grains-store');

// 5. Localization Consistency
echo "\n5. Testing Localization (English & Hausa):\n";
$en = require ROOT_PATH . '/resources/languages/en.php';
$ha = require ROOT_PATH . '/resources/languages/ha.php';
assertTest("English language array exists", is_array($en) && isset($en['nav']['dashboard']));
assertTest("Hausa language array exists", is_array($ha) && isset($ha['nav']['dashboard']));
assertTest("Taglines match brand identity", $en['app']['tagline'] === 'Manage. Grow. Prosper.');
assertTest("Hausa navigation translated", $ha['nav']['dashboard'] === 'Babban Shafi');

// 6. Router Pattern Matching
echo "\n6. Testing Centralized Router:\n";
$router = new Router();
$router->get('/transactions/{id}', 'Transactions\Controllers\TransactionController@show');
assertTest("Router class instantiated cleanly", $router instanceof Router);

echo "\n========================================================\n";
echo "   TEST SUMMARY: {$passed} Passed, {$failed} Failed    \n";
echo "========================================================\n\n";

if ($failed > 0) {
    exit(1);
}
