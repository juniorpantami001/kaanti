<?php
/**
 * Application Configuration
 */
return [
    'name'  => env('APP_NAME', 'KaantiManager'),
    'env'   => env('APP_ENV', 'development'),
    'debug' => env('APP_DEBUG', false),
    'url'   => env('APP_URL', 'http://localhost/kaanti/public'),
    'key'   => env('APP_KEY', ''),

    'timezone' => 'Africa/Lagos',
    'locale'   => 'en',
    'currency' => 'NGN',

    'session_lifetime' => (int) env('SESSION_LIFETIME', 120),
];
