<?php
/**
 * Root Migration Shortcut
 * 
 * Allows running `php migrate.php` directly from the project root.
 */
require __DIR__ . '/database/migrate.php';
